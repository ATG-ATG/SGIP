<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Profesores</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    <!-- Font Awesome CSS (corregido) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

</head>
<body>
    

<?php
include('../conexion/conexion.php');
include('../conexion/key.php');
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script>
    $(document).ready(function () {
        $('#resultados-internos').DataTable();
        $('#resutados-externos').DataTable();
    });
</script>

<!--ONE<script>
    $(document).ready(function() {
        $('#search').on('input', function() {
            var keyword = $(this).val();
            $.ajax({
                url: '../busquedas/buscarProfesor.php',
                type: 'POST',
                data: {
                    keyword: keyword
                },
                success: function(response) {
                    $('#search-results').html(response);
                }
            });
        });
    });    
</script>-->

<script>
    //funcion para confirmar la eliminacion de registro
    function confirmacion(){
        var respuesta=confirm("¿Desea realmente borrar al profesor?");
        if (respuesta==true){
            return true;
        }else{
            return false;
        }
        
    }
</script>

<?php
$sql = "SELECT * FROM `profesores` WHERE NOT sede = 'externo' ";
$res = mysqli_query($conexion, $sql);
$contador = mysqli_num_rows($res);

?>

<?php include_once('../menu.php');?>
<div style="width: 70%; margin: auto;">
    <div>
        <!-- boton para agregar -->
        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#myModal1">
            <!-- Icono de agregar -->
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill-add" viewBox="0 0 16 16">
                <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path>
                <path d="M2 13c0 1 1 1 1 1h5.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.544-3.393C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4Z"></path>
            </svg>
            <h6>Agregar Profesor</h6>
        </button>

        <a href="../modalProfesor/agregarProfesorExterno.php" class="btn btn-primary">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill-add" viewBox="0 0 16 16">
                <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path>
                <path d="M2 13c0 1 1 1 1 1h5.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.544-3.393C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4Z"></path>
            </svg>
            <h6>Agregar Profesor<br>Externo</h6>
        </a>
    </div>

    <!-- barra de busqueda -->
    <br>
    <div>
        <input type="text" id="search" placeholder="Buscar...">
    </div>
    <!--  -->

    <br>

    <div id='search-results'  class="table-responsive">
        <table class="table table-bordered table-striped table-hover" id="resultados-internos">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Primer Apellido</th>
                    <th scope="col">Email</th>
                    <th scope="col">Teléfono</th>
                    <th scope="col">Agrega posgrados</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Eliminar</th>
                    <th scope="col">Detalles</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if($res){
                    while ($row = mysqli_fetch_assoc($res)) { ?>
                    <tr>
                        <td><?php echo $row['profid']; ?></td>
                        <td><?php echo $row['nombre']; ?></td>            
                        <td><?php echo $row['apellidoPaterno']; ?></td>
                        <td><?php echo $row['correo']; ?></td>
                        <td><?php echo $row['telefono']; ?></td>

                        <td style="text-align: center;">
                            <?php
                            echo '<a href="../modalProfesor/masPosgrados.php?id=' . $row['profid'] . '"><button class="btn btn-info">Posgrados</button></a>';
                            ?>
                        </td>

                        <td style="text-align: center;">
                            <?php
                            echo '<a href="../modalProfesor/editarProfesor.php?id=' . $row['profid'] . '"><button class="btn btn-outline-success">Editar</button></a>';
                            ?>
                        </td>

                        <td style="text-align: center;">
                            <?php
                            echo '<a href="../crudProfesor/eliminar.php?id=' . $row['profid'] . '"><button class="btn btn-outline-danger"  onclick="return confirmacion()">Eliminar</button></a>';
                            ?>
                        </td>
                     
                        <td style="text-align: center;">
                            <div class="btn-group">
                                <a href="../modalProfesor/detalles.php?id=<?php echo $row['profid']; ?>&token=<?php echo hash_hmac('sha256', $row['profid'], KEY_TOKEN);?>" class="btn btn-primary">
                                    Detalles
                                </a>
                            </div>
                        </td>

                    </tr>
                
                
                <?php 
                    }
                }else{
                    echo "<td>"."No hay datos del profesor"."</td>";
                } ?>
        </table>


        <?php
        $sqlExterno = "SELECT * FROM `profesores` WHERE sede = 'externo'";
        $resExterno = mysqli_query($conexion, $sqlExterno);
        $contadorExterno = mysqli_num_rows($resExterno);
        ?>

        <!-- Agrega una nueva tabla para mostrar los profesores con sede "Externo" -->
        
        <h4>Profesores Externos</h4>
        <table class="table table-bordered table-striped table-hover" id="resultados-externos">
            <thead>
                <tr>
                    <!-- Define las columnas de la tabla -->
                    <th scope="col">Id</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Primer Apellido</th>
                    <th scope="col">Email</th>
                    <th scope="col">Telefono</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Eliminar</th>
                    <th scope="col">Detalles</th>
                    
                    
                    <!-- Agrega más columnas según tus necesidades -->
                </tr>
            </thead>
            <tbody>
                <?php
                if ($resExterno) {
                    while ($rowExterno = mysqli_fetch_assoc($resExterno)) { ?>
                        <tr>
                            <!-- Muestra los datos correspondientes en cada columna -->
                            <td><?php echo $rowExterno['profid']; ?></td>
                            <td><?php echo $rowExterno['nombre']; ?></td>
                            <td><?php echo $rowExterno['apellidoPaterno']; ?></td>
                            <td><?php echo $rowExterno['correo']; ?></td>
                            <td><?php echo $rowExterno['telefono']; ?></td>

                            <td style="text-align: center;">
                                <?php
                                echo '<a href="../modalProfesorExterno/editarExterno.php?id=' . $rowExterno['profid'] . '"><button class="btn btn-outline-success">Editar</button></a>';
                                ?>
                            </td>

                            <td style="text-align: center;">
                                <?php
                                echo '<a href="../crudProfesor/eliminar.php?id=' . $rowExterno['profid'] . '"><button class="btn btn-outline-danger"  onclick="return confirmacion()">Eliminar</button></a>';
                                ?>
                            </td>

                        
                            
                            <td style="text-align: center;">
                                <div class="btn-group">
                                    <a href="../modalProfesorExterno/detalles.php?id=<?php echo $rowExterno['profid']; ?>&token=<?php echo hash_hmac('sha256', $rowExterno['profid'], KEY_TOKEN);?>" class="btn btn-primary">
                                        Detalles
                                    </a>
                                </div>
                            </td>
                        </tr>
                    <?php
                    }
                } else {
                    echo "<td>" . "No hay datos de profesores con sede 'Externo'" . "</td>";
                }
                ?>
            </tbody>
        </table>
        <footer class="container-fluid text-center">
        <p>Profesores UAGro</p>
      </footer>
    </div>
</div>

<?php
include('../modalProfesor/agregarProfesor.php');
?>

<script src="https://code.jquery.com/jquery-3.4.1.js"
integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
<!-- DATATABLES -->
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function () {
        $('#resultados-internos').DataTable();
        $('#resultados-externos').DataTable();
    });

</script>

</script>

<script> 
 
$(document).ready(function(){
  $("#claveTrabajador").blur(function(){
	  var num = $("#claveTrabajador").val();
     // alert("Campo perdio el foco: " + num);
    
	if(num.trim() == '' ){
		alert('Por favor introduzca un numero de prof.');
		// $('#idnoempl').focus();
		return false;
	}
	else{
		
		// alert(num);
		
		$.ajax({url: "obtenerptc.php", 
			method: "GET", 
            data: {"noempl": num},
			success: function(result){
				var datos = JSON.parse(result);
				if (datos.status=='OK'){
					$('#nombre').val(datos.info.nombre);
                    $('#apellidoPaterno').val(datos.info.paterno);
                    $('#apellidoMaterno').val(datos.info.materno);
				}
				else{
					alert (datos.info);
				}
			}
		});
		
    
		
	}	
  });
});

</script>


</body>


</html>
