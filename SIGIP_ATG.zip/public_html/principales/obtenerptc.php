<?php

include_once '../dao/daoptc.php';

if (isset($_GET['noempl'])){
    $noempl = $_GET['noempl'];

}
else {
	print ' No se recibio el parametro noempl';
}

$emp = new Ptc();

$RegEmp = $emp->obtenerPtcporNum($noempl);
if ($RegEmp->num_rows > 0){
    $registro= $RegEmp->fetch_assoc();
    $ptcdato['num'] = $registro['numero'];
    $ptcdato['paterno'] = $registro['apaterno'];
    $ptcdato['materno'] = $registro['amaterno'];
    $ptcdato['nombre'] = $registro['nombre'];
    $ptcdato['sexo'] = $registro['sexo'];
    $dato['status']= 'OK';
    $dato['info']= ($ptcdato);
	
     print (json_encode($dato, JSON_UNESCAPED_UNICODE));
	// print ($nomtotal);
     
 }
 else {
	$dato['status'] = 'ERROR';
    $dato['info']   = 'El numero de empleado no existe';
    print(json_encode($dato));
 }

?>
