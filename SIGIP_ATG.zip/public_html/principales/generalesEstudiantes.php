<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listado de Estudiantes</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
    <!-- DataTables CSS -->
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
    <!-- Font Awesome CSS (corregido) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

</head>
<body>
<?php
include('../conexion/conexion.php');//contiene configuraciones relacionadas con la conexión a una base de datos
//lo cual esta en un archivo llamado "config.php" en la carpeta conexion
include('../conexion/key.php');//archivo "key.php" de la carpeta conexion, este archivo contiene claves y/o tokens de autenticación
//para el funcionamiento del boton detalles, esto sirve como un link de youtube o de facebook, que sale al final del url como "?5e88t4e56y84u5" coo metodo de seguridad
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script><!--LIBRERIA JQUERY-->
<script>
    $(document).ready(function () {
        $('#resultados-estudiantes').DataTable();
    });
</script>
<!--ONE<script>
    //funcion para hacer recorrido y busqueda de datos especificos(nombre de los Posgrados)
    $(document).ready(function() {
        $('#search').on('input', function() {
            var keyword = $(this).val();
            $.ajax({
                url: '../busquedas/buscarEstudiante.php',
                type: 'POST',
                data: {
                    keyword: keyword
                },
                success: function(response) {
                    $('#search-results').html(response);
                }
            });
        });
    });    
</script>-->

<script>
        //funcion para confirmar la eliminacion de registro
    function confirmacion(){
        var respuesta=confirm("¿Desea realmente borrar al estudiante?");
        if (respuesta==true){
            return true;
        }else{
            return false;
        }
        
    }
</script>

<?php
$sql = "SELECT * FROM `ingresoestudiante`";//consulta de la tabla generalPosgrados
try {
    $res = $conexion->query($sql);//guardar consulta

    $contador = mysqli_num_rows($res);//guardar en una variable el total de datos guardados en la tabla
}
catch (Exception $e) {
    echo "Ocurrio un error: ".$e->getMessage(), "\n";
    exit();
}

?>


<?php include_once('../menu.php');?><!--INCLUIR EL MENU-->

<div style="width: 70%; margin: auto;">
    <div>
        <!-- boton para agregar, el modal esta en el archivo "agregarEstudiante.php" en la carpeta modalEstudiantes -->
        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#myModal1">
            <!-- Icono de agregar -->
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill-add" viewBox="0 0 16 16">
                <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path>
                <path d="M2 13c0 1 1 1 1 1h5.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.544-3.393C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4Z"></path>
            </svg>
            <h6>Agregar Estudiante</h6>
        </button>
    </div>

    <!-- barra de busqueda -->
    <br>
    <div>
        <input type="text" id="search" placeholder="Buscar Estudiante...">
    </div>
    <!--FIN de la barra de busqueda-->

    <br>

    <div id='search-results'>
        <table class="table table-bordered table-striped table-hover" id="resultados-estudiantes">
            <thead>
                <tr style="text-align: center;" >
                    <th scope="col">Id</th>
                    <th scope="col">Matr&iacute;cula</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">N&uacute;mero de CVU CONACyT</th>
                    <th scope="col">Generaci&oacute;n</th>
                    <th scope="col">Posgrado al que pertenece</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Eliminar</th>
                    <th scope="col">Detalles</th>

                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($res)) { ?>
                    <tr>
                        <td><?php echo $row['idEstudiante']; ?></td>
                        <td><?php echo $row['matricula']; ?></td>           
                        <td><?php echo $row['nombreEst']; ?></td>           
                        <td><?php echo $row['numCVU']; ?></td>
                        <td><?php echo $row['generacion']; ?></td>
                        <td><?php echo $row['nombre']; ?></td>


                        <!--BOTON PARA EDITAR ESTUDIANTES-->
                        <td style="text-align: center;">
                            <?php
                                echo '<a href="../modalEstudiantes/editarEstudiante.php?id=' . $row['idEstudiante'] . '"><button class="btn btn-outline-success">Editar</button></a>';
                            ?>
                        </td>

                        <!--BOTON DE ELIMINAR ESTUDIANTES-->
                        <td style="text-align: center;">
                            <?php
                            echo '<a href="../crudEstudiantes/eliminarEst.php?id=' . $row['idEstudiante'] . '"><button class="btn btn-outline-danger"  onclick="return confirmacion()">Eliminar</button></a>';
                            ?>
                        </td>

                    
                        <!--BOTON DE DETALLES-->
                        <td style="text-align: center;">
                            <div class="btn-group">
                                <a href="../modalEstudiantes/detallesEstudiante.php?id=<?php echo $row['idEstudiante']; ?>&token=<?php echo hash_hmac('sha256', $row['idEstudiante'], KEY_TOKEN);?>" class="btn btn-primary">
                                    Detalles
                                </a>
                            </div>
                        </td>
                        

                    </tr>
                <?php } ?>

        </table>
    </div>
    
</div>
<?php
include('../modalEstudiantes/agregarEstudiante.php');
?>
<script src="https://code.jquery.com/jquery-3.4.1.js"
integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU=" crossorigin="anonymous"></script>
<!-- DATATABLES -->
<script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
<script>
    $(document).ready(function () {
        $('#resultados-estudiantes').DataTable();
    });

</script>
</body>
<footer class="container-fluid text-center">
        <p>Estudiantes UAGro</p>
      </footer>
</html>
