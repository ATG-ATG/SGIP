<?php

define("KEY_TOKEN", "UAGro-MIIDT-2023*");

?>