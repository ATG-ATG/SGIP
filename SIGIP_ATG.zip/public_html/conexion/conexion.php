<?php
$usuario  = "usrsgi-posgrado";
$password = "VGuc8IbDdYC";
$servidor = "localhost";
$basededatos = "dbdbsgiposgrado";
/*
$conexion = mysqli_connect($servidor, $usuario, $password) or die("No se ha podido conectar al Servidor");
mysqli_query($conexion,"SET SESSION collation_connection ='utf8_unicode_ci'");
$db = mysqli_select_db($conexion, $basededatos) or die("Upps! Error en conectar a la Base de Datos");
*/
$conexion = mysqli_connect($servidor, $usuario, $password, $basededatos);
if (!$conexion) {
    die("La conexion fallo: " . mysqli_connect_error());
  }
?>
