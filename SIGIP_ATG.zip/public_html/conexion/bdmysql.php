<?php

    class bdmysql {
        private $con;
        public function getConexion() {
            if(!isset($this->con)){
                $this->con=new mysqli("localhost","usrsgi-posgrado", "VGuc8IbDdYC", "dbdbsgiposgrado");
                if ($this->con->connect_error) {
                    die("Error al conectarse a la base de datos: . $this->con->connect_error" );
                  }
            }
		     mysqli_set_charset($this->con, "utf8");
            return $this->con;
        }
    }

?>