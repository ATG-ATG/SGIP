<?php
include('../conexion/conexion.php');
//-----------------------------Obtencion de Datos Generales del Profesor--------------------->
$nombre =  mysqli_real_escape_string($conexion, $_POST['nombre']);
$apellidoPaterno =  mysqli_real_escape_string($conexion, $_POST['apellidoPaterno']);
$apellidoMaterno =  mysqli_real_escape_string($conexion, $_POST['apellidoMaterno']);
$claveTrabajador =  mysqli_real_escape_string($conexion, $_POST['claveTrabajador']);
$correo =  mysqli_real_escape_string($conexion, $_POST['correo']);
$telefono =  mysqli_real_escape_string($conexion, $_POST['telefono']);
$sexo =  mysqli_real_escape_string($conexion, $_POST['sexo']);
//----------------------------Obtencion de Datos Academicos--------------------------->
$gradoAcademico =  mysqli_real_escape_string($conexion, $_POST['gradoAcademico']);
$instGrado = mysqli_real_escape_string($conexion, $_POST['instGrado']);
$anioObtGrado = mysqli_real_escape_string($conexion, $_POST['anioObtGrado']);
$url = mysqli_real_escape_string($conexion, $_POST['url']);
$cvun = mysqli_real_escape_string($conexion, $_POST['cvun']);//agregar en bd
$cvu = $_FILES['cvu']['name'];
$vigenciaSNI = mysqli_real_escape_string($conexion, $_POST['vigenciaSNI']);
$areaEstudios = mysqli_real_escape_string($conexion, $_POST['areaEstudios']);
$sni = mysqli_real_escape_string($conexion, $_POST['sni']);
$nacionalidad = mysqli_real_escape_string($conexion, $_POST['nacionalidad']);
$nacionalidad2 = mysqli_real_escape_string($conexion, $_POST['nacionalidad2']);//obtiene la nacionalidad2
//-----------------------------obtencion de Datos Laborales----------------------------->
$adscripcion = mysqli_real_escape_string($conexion, $_POST['adscripcion']);
$posgrados = mysqli_real_escape_string($conexion, $_POST['posgrados']);
$tiempoPosgrado = mysqli_real_escape_string($conexion, $_POST['tiempoPosgrado']);



$agregar = "";
$agregar2 = "";
$agregar3 = "";


//----------------------------------------------------------VALIDACIONES-----------------------------------------------------------
// Convertir la primera letra de cada palabra a mayúscula
$nombre = ucwords(strtolower($nombre));
$apellidoPaterno = ucwords(strtolower($apellidoPaterno));
$apellidoMaterno = ucwords(strtolower($apellidoMaterno));//ucwords(primera letra en mayusculas), strtolower(las demas letras en minusculas)


//Validacion de la primera nacionalidad
if ($nacionalidad === 'Mexicana') {//si nacionalidad 1 es mexicana
        $estado = mysqli_real_escape_string($conexion, $_POST['estado']);//Se obtiene el dato que tiene estado 1
//-----no mover
                $agregar = "INSERT INTO profesores (nombre, apellidoPaterno, apellidoMaterno, claveTrabajador, correo, telefono, nacionalidad, sexo, estado, sede)
                VALUES ('$nombre', '$apellidoPaterno', '$apellidoMaterno', '$claveTrabajador', '$correo', '$telefono', '$nacionalidad', '$sexo', '$estado', 'externo')";
//-----arriba no mover
} else if ($nacionalidad === 'Extranjera') { //Si es extranjera
        $pais = mysqli_real_escape_string($conexion, $_POST['pais']);//obtener dato pais
        if ($pais === 'otro') {//si se eligio otro como pais
            $otroPais = mysqli_real_escape_string($conexion, $_POST['otroPais']);//obtener dato escrito en la casilla
            $agregar = "INSERT INTO profesores (nombre,apellidoPaterno,apellidoMaterno,claveTrabajador,correo,telefono,nacionalidad,sexo,pais, sede)
                VALUES ('$nombre','$apellidoPaterno','$apellidoMaterno','$claveTrabajador','$correo','$telefono','$nacionalidad','$sexo','$otroPais', 'externo')";
        } else {//si se eligio un pais de la lista...
                $agregar = "INSERT INTO profesores (nombre, apellidoPaterno, apellidoMaterno, claveTrabajador, correo, telefono, nacionalidad, sexo, pais, sede)
                VALUES ('$nombre', '$apellidoPaterno', '$apellidoMaterno', '$claveTrabajador', '$correo', '$telefono', '$nacionalidad', '$sexo', '$pais', 'externo')";
        }
}
//Esta dividido en dos por que da problemas al separarlos, y que flojera la verdad(validacion de la nacionalidad 2)
if($nacionalidad2 === 'Mexicana') {//si nacionalidad 2 es mexicana
        $estado2 = mysqli_real_escape_string($conexion, $_POST['estado2']);//Se obtiene el dato que tiene estado 2
        if($instGrado === 'UAGro'){
                if($sni == 'Ninguno'){
                        $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                        VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', '$estado2', null, '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', null, '$url', 'externo')";
                }else{
                        $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                        VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', '$estado2', null, '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'externo')";
                }  
        }else{
                $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);//Se obtiene el dato que escribio en otra institucion
                if($sni == 'Ninguno'){
                        $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun,  cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                        VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', '$estado2', null, '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', null, '$url', 'externo')";
                }else{
                        $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun,  cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                        VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', '$estado2', null, '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'externo')";
                }
                
                 
        }
        
}else if($nacionalidad2 === 'Extranjera'){//Si nacionalidad 2 es extranjera
        $pais2 = mysqli_real_escape_string($conexion, $_POST['pais2']);//se obtiene el valor de pais 2
        if ($pais2 === 'otro') {//si se ha seleccionando en la opcion de otro
                $otroPais2 = mysqli_real_escape_string($conexion, $_POST['otroPais2']);//obtiene el dato del pais escrito en el input
                //Aqui es para insertar los datos academicos-------------->
                if($instGrado === 'UAGro'){
                        if($sni == 'Ninguno'){
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', null, '$otroPais2', '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', null, '$url', 'externo')";  
                        }else{
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', null, '$otroPais2', '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'externo')";  
                        }
                }else{
                        $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);//Se obtiene el dato que escribio en otra institucion
                        if($sni == 'Ninguno'){
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', null, '$otroPais2', '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', null, '$url', 'externo')";  
                        }else{
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', null, '$otroPais2', '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'externo')";  
                        }
                        
                        //-----------------------------<
                }
        }else{
                //Aqui es para insertar los datos academicos-------------->
                //se ingresa el pais2
                if($instGrado === 'UAGro'){
                        if($sni == 'Ninguno'){
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', null, '$pais2', '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', null, '$url', 'externo')";  
                        }else{
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                        VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', null, '$pais2', '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'externo')";  
                        }
                        
                }else{
                        $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);//Se obtiene el dato que escribio en otra institucion
                        if($sni == 'Ninguno'){
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', null, '$pais2', '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', null, '$url', 'externo')"; 
                        }else{
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', null, '$pais2', '$anioObtGrado', '$cvun', '$cvu', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'externo')"; 
                        }
                         
                        //-----------------------------<
                }
                
        }
}

$agregar3 = "INSERT INTO laboralesprofesor (posgrados, adscripcion, tiempoPosgrado, sede)
VALUES ('$posgrados', '$adscripcion', '$tiempoPosgrado', 'externo')"; 


$inserInmueble = mysqli_query($conexion, $agregar);
$inserInmueble2 = mysqli_query($conexion, $agregar2);
$inserInmueble3 = mysqli_query($conexion, $agregar3);

//-----------------------------Obtencion de Datos Academicos del Profesor--------------------->



header("Location: ../principales/generalesProfesor.php");
?>
