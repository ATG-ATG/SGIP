<?php
include('../conexion/conexion.php');
$id = $_POST['id'];

$nombre = mysqli_real_escape_string($conexion, $_POST['nombre']);
$apellidoPaterno = mysqli_real_escape_string($conexion, $_POST['apellidoPaterno']);
$apellidoMaterno = mysqli_real_escape_string($conexion, $_POST['apellidoMaterno']);
$claveTrabajador = mysqli_real_escape_string($conexion, $_POST['claveTrabajador']);
$correo = mysqli_real_escape_string($conexion, $_POST['correo']);
$telefono = mysqli_real_escape_string($conexion, $_POST['telefono']);
$sexo = mysqli_real_escape_string($conexion, $_POST['sexo']);
$nacionalidad = mysqli_real_escape_string($conexion, $_POST['nacionalidad']);

$gradoAcademico = mysqli_real_escape_string($conexion, $_POST['gradoAcademico']);
$instGrado = mysqli_real_escape_string($conexion, $_POST['instGrado']);
$anioObtGrado = mysqli_real_escape_string($conexion, $_POST['anioObtGrado']);
$url = mysqli_real_escape_string($conexion, $_POST['url']);
$cvun = mysqli_real_escape_string($conexion, $_POST['cvun']);
$cvu = mysqli_real_escape_string($conexion, $_POST['cvu']);
$vigenciaSNI = mysqli_real_escape_string($conexion, $_POST['vigenciaSNI']);
$areaEstudios = mysqli_real_escape_string($conexion, $_POST['areaEstudios']);
$sni = mysqli_real_escape_string($conexion, $_POST['sni']);
$nacionalidad2 = mysqli_real_escape_string($conexion, $_POST['nacionalidad2']);

$adscripcion = mysqli_real_escape_string($conexion, $_POST['adscripcion']);
$posgrados = mysqli_real_escape_string($conexion, $_POST['posgrados']);
$tiempoPosgrado = mysqli_real_escape_string($conexion, $_POST[  'tiempoPosgrado']);

$nombre = ucwords(strtolower($nombre));
$apellidoPaterno = ucwords(strtolower($apellidoPaterno));
$apellidoMaterno = ucwords(strtolower($apellidoMaterno));

$agregar = "";
$agregar2 = ""; // Inicializar la variable
$agregar3 = "";

if ($nacionalidad === 'Mexicana') {
    $estado = mysqli_real_escape_string($conexion, $_POST['estado']);
    $agregar = "UPDATE profesores SET nombre='" . $nombre . "', 
                apellidoPaterno='" . $apellidoPaterno . "', 
                apellidoMaterno='" . $apellidoMaterno . "', 
                claveTrabajador='" . $claveTrabajador . "', 
                correo='" . $correo . "',
                telefono='" . $telefono . "', 
                nacionalidad='" . $nacionalidad . "',
                estado='" . $estado . "',
                sexo='" . $sexo . "',
                sede='externo',
                pais=NULL WHERE profid='" . $id . "'";
} else if ($nacionalidad === 'Extranjera') {
    $pais = mysqli_real_escape_string($conexion, $_POST['pais']);
    if ($pais === 'otro') {
        $otroPais = mysqli_real_escape_string($conexion, $_POST['otroPais']);
        $agregar = "UPDATE profesores SET nombre='" . $nombre . "', 
                    apellidoPaterno='" . $apellidoPaterno . "', 
                    apellidoMaterno='" . $apellidoMaterno . "', 
                    claveTrabajador='" . $claveTrabajador . "', 
                    correo='" . $correo . "',
                    telefono='" . $telefono . "', 
                    nacionalidad='" . $nacionalidad . "',
                    pais='" . $otroPais . "',
                    sexo='" . $sexo . "',
                    sede='externo',
                    estado=NULL WHERE profid='" . $id . "'";
    } else {
        $agregar = "UPDATE profesores SET nombre='" . $nombre . "', 
                    apellidoPaterno='" . $apellidoPaterno . "', 
                    apellidoMaterno='" . $apellidoMaterno . "', 
                    claveTrabajador='" . $claveTrabajador . "', 
                    correo='" . $correo . "',
                    telefono='" . $telefono . "', 
                    nacionalidad='" . $nacionalidad . "',
                    pais='" . $pais . "',
                    sexo='" . $sexo . "',
                    sede='externo',
                    estado=NULL WHERE profid='" . $id . "'";
    }
}

if ($nacionalidad2 === 'Mexicana') {
    $estado2 = mysqli_real_escape_string($conexion, $_POST['estado2']);
    if ($instGrado === 'UAGro') {
        $agregar2 = "UPDATE academicosprofesor SET gradoAcademico='" . $gradoAcademico . "', 
                    insUltimoGrado='" . $instGrado . "',
                    nacionalidad2='" . $nacionalidad2 . "',
                    estado2='" . $estado2 . "',
                    anioObtGrado='" . $anioObtGrado . "',
                    cvun='" . $cvun . "',
                    cvu='" . $cvu . "',
                    areaEstudios='" . $areaEstudios . "',
                    sni='" . $sni . "',
                    vigenciaSNI='" . $vigenciaSNI . "',
                    urlProductividad='" . $url . "',
                    sede='externo',
                    pais2=NULL WHERE profid='" . $id . "'";
    } else if ($instGrado === 'otro') {
        $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);
        $agregar2 = "UPDATE academicosprofesor SET gradoAcademico='" . $gradoAcademico . "', 
                    insUltimoGrado='" . $otraInst . "',
                    nacionalidad2='" . $nacionalidad2 . "',
                    estado2='" . $estado2 . "',
                    anioObtGrado='" . $anioObtGrado . "',
                    cvun='" . $cvun . "',
                    cvu='" . $cvu . "',
                    areaEstudios='" . $areaEstudios . "',
                    sni='" . $sni . "',
                    vigenciaSNI='" . $vigenciaSNI . "',
                    urlProductividad='" . $url . "',
                    sede='externo',
                    pais2=NULL WHERE profid='" . $id . "'";
    }
} else if ($nacionalidad2 === 'Extranjera') {
    $pais2 = mysqli_real_escape_string($conexion, $_POST['pais2']);
    if ($pais2 === 'otro') {
        $otroPais2 = mysqli_real_escape_string($conexion, $_POST['otroPais2']);
        if ($instGrado === 'UAGro') {
            $agregar2 = "UPDATE academicosprofesor SET gradoAcademico='" . $gradoAcademico . "', 
                        insUltimoGrado='" . $instGrado . "',
                        nacionalidad2='" . $nacionalidad2 . "',
                        pais2='" . $otroPais2 . "',
                        anioObtGrado='" . $anioObtGrado . "',
                        cvun='" . $cvun . "',
                        cvu='" . $cvu . "',
                        areaEstudios='" . $areaEstudios . "',
                        sni='" . $sni . "',
                        vigenciaSNI='" . $vigenciaSNI . "',
                        urlProductividad='" . $url . "',
                        sede='externo',
                        estado2=NULL WHERE profid='" . $id . "'";
        } else if ($instGrado === 'otro') {
            $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);
            $agregar2 = "UPDATE academicosprofesor SET gradoAcademico='" . $gradoAcademico . "', 
                        insUltimoGrado='" . $otraInst . "',
                        nacionalidad2='" . $nacionalidad2 . "',
                        pais2='" . $otroPais2 . "',
                        anioObtGrado='" . $anioObtGrado . "',
                        cvun='" . $cvun . "',
                        cvu='" . $cvu . "',
                        areaEstudios='" . $areaEstudios . "',
                        sni='" . $sni . "',
                        vigenciaSNI='" . $vigenciaSNI . "',
                        urlProductividad='" . $url . "',
                        sede='externo',
                        estado2=NULL WHERE profid='" . $id . "'";
        }
    } else {
        if ($instGrado === 'UAGro') {
            $agregar2 = "UPDATE academicosprofesor SET gradoAcademico='" . $gradoAcademico . "', 
                        insUltimoGrado='" . $instGrado . "',
                        nacionalidad2='" . $nacionalidad2 . "',
                        pais2='" . $pais2 . "',
                        anioObtGrado='" . $anioObtGrado . "',
                        cvun='" . $cvun . "',
                        cvu='" . $cvu . "',
                        areaEstudios='" . $areaEstudios . "',
                        sni='" . $sni . "',
                        vigenciaSNI='" . $vigenciaSNI . "',
                        urlProductividad='" . $url . "',
                        sede='externo',
                        estado2=NULL WHERE profid='" . $id . "'";
        } else if ($instGrado === 'otro') {
            $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);
            $agregar2 = "UPDATE academicosprofesor SET gradoAcademico='" . $gradoAcademico . "', 
                        insUltimoGrado='" . $otraInst . "',
                        nacionalidad2='" . $nacionalidad2 . "',
                        pais2='" . $pais2 . "',
                        anioObtGrado='" . $anioObtGrado . "',
                        cvun='" . $cvun . "',
                        cvu='" . $cvu . "',
                        areaEstudios='" . $areaEstudios . "',
                        sni='" . $sni . "',
                        vigenciaSNI='" . $vigenciaSNI . "',
                        urlProductividad='" . $url . "',
                        sede='externo',
                        estado2=NULL WHERE profid='" . $id . "'";
        }
    }
}

if (empty($agregar2)) {
    echo "Error: No se pudo determinar la consulta para actualizar los datos académicos.";
    exit; // Otra opción: redirigir o manejar el error de otra manera
}


$agregar3 = "UPDATE laboralesprofesor SET 
            adscripcion='" . $adscripcion . "',
            posgrados='" . $posgrados . "',
            tiempoPosgrado='" . $tiempoPosgrado . "',
            sede='externo' WHERE profid='" . $id . "'";

            
$res = mysqli_query($conexion, $agregar);
$res2 = mysqli_query($conexion, $agregar2); // Aquí deberías verificar si $agregar2 está vacío antes de ejecutar la consulta
$res3 = mysqli_query($conexion, $agregar3);

// Si hay un error al ejecutar la consulta, puedes manejarlo de esta manera
if (!$res || !$res2 || !$res3) {
    echo "Error al actualizar los datos.";
} else {
    header('Location: ../principales/generalesProfesor.php');
    exit;
}
?>
