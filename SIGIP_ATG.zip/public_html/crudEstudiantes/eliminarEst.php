<?php
include('../conexion/conexion.php');
$id = $_REQUEST['id'];

$DeleteRegistro = "DELETE FROM ingresoestudiante WHERE idEstudiante='" . $id . "'";
mysqli_query($conexion, $DeleteRegistro);

$DeleteRegistro1 = "DELETE FROM seguimientoestudiante WHERE idEstudiante='" . $id . "'";
mysqli_query($conexion, $DeleteRegistro1);

$DeleteRegistro2 = "DELETE FROM egeresoestudiante WHERE idEstudiante='" . $id . "'";
mysqli_query($conexion, $DeleteRegistro2);

header("Location: ../principales/generalEstudiantes.php");

?>