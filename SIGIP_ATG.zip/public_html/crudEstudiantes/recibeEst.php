<?php
include('../conexion/conexion.php');
$idEstudiante= mysqli_real_escape_string($conexion, $_POST['idEstudiante']);//tipo numerico

//--------------------------Datos del Primer Acordeon (Ingreso)----------------------------------------------->
$expediente_estudiante = $_FILES['expediente_estudiante']['name'];
$nombreEst =  mysqli_real_escape_string($conexion, $_POST['nombreEst']);
$apellidoPEstudiante =  mysqli_real_escape_string($conexion, $_POST['apellidoPEstudiante']);
$apellidoMEstudiante =  mysqli_real_escape_string($conexion, $_POST['apellidoMEstudiante']);
$sexo =  mysqli_real_escape_string($conexion, $_POST['sexo']);
$grupoVulnerable =  mysqli_real_escape_string($conexion, $_POST['grupoVulnerable']);
$matricula = mysqli_real_escape_string($conexion, $_POST['matricula']);//tipo num
$numCVU = mysqli_real_escape_string($conexion, $_POST['numCVU']);//tipo numerico
$posgrado = mysqli_real_escape_string($conexion, $_POST['nombre']);//tipo texto
$generacion =  mysqli_real_escape_string($conexion, $_POST['generacion']);
#$iniciogen =  mysqli_real_escape_string($conexion, $_POST['iniciogen']);
#$posgrado =  mysqli_real_escape_string($conexion, $_POST['nombre']);
$nacionalidad = mysqli_real_escape_string($conexion, $_POST['nacionalidad']);

if (isset ($_POST['archiante'])){
        $archiante=$_POST['archiante'];
}
else {
        $archiante='';

}
//--------------------------PARA INGRESAR DATOS-------------------------
$agregarIngreso = "";
$actualizarIngreso = "";

if ($expediente_estudiante!=''){

$resultguarda = guardarArchivo($matricula);
if ($resultguarda!='OK'){
        print ('ocurrio un error al guardar archivo: ');
        print ($resultguarda);
}

$expediente_estudiante=$matricula.'_'.$expediente_estudiante;
}
else {
        $expediente_estudiante=$archiante;
}
//print ('idEstudiante: ' . $matricula);
//exit();

//----------------------------------------------------------VALIDACIONES-----------------------------------------------------------
// Convertir la primera letra de cada palabra a mayúscula
$nombreEst = ucwords(strtolower($nombreEst));
    
// Validar que la clave de trabajador sea de 6 dígitos
    
// Validar que el sexo sea uno de los valores permitidos (Masculino o Femenino)
if ($sexo !== 'Masculino' && $sexo !== 'Femenino') {
        echo "Selecciona una opción válida para el sexo.";
        exit;
}

$sql = "SELECT * FROM ingresoestudiante WHERE idEstudiante='" . $idEstudiante . "'"; 
$res = $conexion->query($sql);

if ($res->num_rows > 0) {
        //actualizar
        //Validacion de la primera nacionalidad
        if ($nacionalidad === 'Mexicana') {//si nacionalidad 1 es mexicana
                $estado = mysqli_real_escape_string($conexion, $_POST['estado']);//Se obtiene el dato que tiene estado 1
        //-----no mover
        $actualizarIngreso = "UPDATE ingresoestudiante SET 
        expediente_estudiante = '". $expediente_estudiante ."', 
        nombreEst = '". $nombreEst ."', 
        apellidoPEstudiante = '". $apellidoPEstudiante ."', 
        apellidoMEstudiante = '". $apellidoMEstudiante ."', 
        sexo = '". $sexo ."', 
        nacionalidad = '". $nacionalidad ."',
        estado = '". $estado ."',  
        grupoVulnerable = '". $grupoVulnerable ."', 
        matricula = '". $matricula ."', 
        numCVU = '". $numCVU ."', 
        nombre = '". $posgrado ."', 
        generacion = '". $generacion ."'
        WHERE idEstudiante = '" . $idEstudiante . "'";

        //-----arriba no mover
} else if ($nacionalidad === 'Extranjera') { //Si es extranjera
        $pais = mysqli_real_escape_string($conexion, $_POST['pais']);//obtener dato pais
        if ($pais === 'otro') {//si se eligio otro como pais
        $otroPais = mysqli_real_escape_string($conexion, $_POST['otroPais']);//obtener dato escrito en la casilla
                $actualizarIngreso = "UPDATE ingresoestudiante SET 
                expediente_estudiante = '". $expediente_estudiante ."', 
                nombreEst = '". $nombreEst ."', 
                apellidoPEstudiante = '". $apellidoPEstudiante ."', 
                apellidoMEstudiante = '". $apellidoMEstudiante ."', 
                sexo = '". $sexo ."', 
                nacionalidad = '". $nacionalidad ."',
                pais = '". $otroPais ."',  
                grupoVulnerable = '". $grupoVulnerable ."', 
                matricula = '". $matricula ."', 
                numCVU = '". $numCVU ."', 
                nombre = '". $posgrado ."', 
                generacion = '". $generacion ."'

                WHERE idEstudiante = '" . $idEstudiante . "'";
        } else {//si se eligio un pais de la lista...
                $actualizarIngreso = "UPDATE ingresoestudiante SET 
                expediente_estudiante = '". $expediente_estudiante ."', 
                nombreEst = '". $nombreEst ."', 
                apellidoPEstudiante = '". $apellidoPEstudiante ."', 
                apellidoMEstudiante = '". $apellidoMEstudiante ."', 
                sexo = '". $sexo ."', 
                nacionalidad = '". $nacionalidad ."',
                pais = '". $pais ."',  
                grupoVulnerable = '". $grupoVulnerable ."', 
                matricula = '". $matricula ."', 
                numCVU = '". $numCVU ."', 
                nombre = '". $posgrado ."', 
                generacion = '". $generacion ."'

                WHERE idEstudiante = '" . $idEstudiante . "'";
        }
}

//print ("actualizar: ".$actualizar);
//exit ();
$actualizar = mysqli_query($conexion, $actualizarIngreso);

} else {
//ingresar
//Validacion de la primera nacionalidad
if ($nacionalidad === 'Mexicana') {//si nacionalidad 1 es mexicana
        $estado = mysqli_real_escape_string($conexion, $_POST['estado']);//Se obtiene el dato que tiene estado 1
//-----no mover
        $agregarIngreso = "INSERT INTO ingresoestudiante (expediente_estudiante, nombreEst, apellidoPEstudiante, apellidoMEstudiante, sexo, nacionalidad, estado, grupoVulnerable, matricula, numCVU, nombre, generacion)
        VALUES ('$expediente_estudiante', '$nombreEst', '$apellidoPEstudiante', '$apellidoMEstudiante','$sexo', '$nacionalidad', '$estado','$grupoVulnerable', '$matricula', '$numCVU', '$posgrado','$generacion')";        
        //-----arriba no mover
} else if ($nacionalidad === 'Extranjera') { //Si es extranjera
        $pais = mysqli_real_escape_string($conexion, $_POST['pais']);//obtener dato pais
        if ($pais === 'otro') {//si se eligio otro como pais
        $otroPais = mysqli_real_escape_string($conexion, $_POST['otroPais']);//obtener dato escrito en la casilla
                $agregarIngreso = "INSERT INTO ingresoestudiante (expediente_estudiante, nombreEst, apellidoPEstudiante, apellidoMEstudiante, sexo, nacionalidad, pais, grupoVulnerable, matricula, numCVU, nombre, generacion)
                VALUES ('$expediente_estudiante', '$nombreEst', '$sexo', '$apellidoPEstudiante', '$apellidoMEstudiante' , '$nacionalidad', '$otroPais','$grupoVulnerable', '$matricula', '$numCVU', '$posgrado','$generacion')";        
        } else {//si se eligio un pais de la lista...
                $agregarIngreso = "INSERT INTO ingresoestudiante (expediente_estudiante, nombreEst, apellidoPEstudiante, apellidoMEstudiante, sexo, nacionalidad, pais, grupoVulnerable, matricula, numCVU, nombre, generacion)
                VALUES ('$expediente_estudiante', '$nombreEst', '$apellidoPEstudiante', '$apellidoMEstudiante' ,'$sexo', '$nacionalidad', '$pais','$grupoVulnerable', '$matricula', '$numCVU', '$posgrado','$generacion')";        
        }
}

//print ("sqlingreso: ".$agregarIngreso);
//exit ();
$sqlIngreso = mysqli_query($conexion, $agregarIngreso);


}



//-----------------------------Obtencion de Datos Academicos del Profesor--------------------->



header("Location: ../principales/generalesEstudiantes.php");
function guardarArchivo($idestu)
{
        //  ***   Codigo para guardar archivo
        $target_dir = "filesestudiantes/";
        $carpeta=$target_dir;
        if (!file_exists($carpeta)) {
            mkdir($carpeta, 0777, true);
        }
        $target_file = $carpeta . $idestu.'_'. basename($_FILES['expediente_estudiante']['name']);
        $archiExpe = $idestu.'_'.$_FILES['expediente_estudiante']['name'];
        $tamaExpe = $_FILES['expediente_estudiante']['size'];
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        // Check if image file is a actual image or fake image
        /*
        $check = getimagesize($_FILES["archivo"]["tmp_name"]);
        if($check !== false) {
            $messages[]= "OK: El archivo es una imagen - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            $errors[]= "Error: El archivo no es una imagen.";
            $uploadOk = 0;
        }
   
         */
        // Check if file already exists
        if (file_exists($target_file)) {
            $errors[]="Error: El archivo ya existe.";
            $uploadOk = 0;
        }
		
		if ($tamaExpe ==0){
			$errors[]="Error: el archivo es demasiado grande.  Tama&ntilde;o m&aacute;ximo admitido: 1.2 MB";
            $uploadOk = 0;
		}
        // Check file size //se obtiene la cant 5MB * 1048576 bytes
        if ($_FILES["expediente_estudiante"]["size"] > 5242880) {
            $errors[]= "Error: el archivo es demasiado grande. Tama&ntilde;o m&aacute;ximo admitido: 5 MB";
            $uploadOk = 0;
        }
        // Allow certain file formats
        if($imageFileType != "pdf" ) {
            $errors[]= "Error: S&oacute;lo archivos PDF son permitidos.";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        
        if ($uploadOk == 0) {
            $errors[]= "Error: ocurri&oacute; un problema.";
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES['expediente_estudiante']['tmp_name'], $target_file)) {
                $messages[]= "OK: El Archivo se guardo correctamente.";
               $uploadOk =1;

            } else {
               $errors[]= "Error: no se pudo guardar el archivo.";
            }
        }
        //   *******

        if ($uploadOk == 0) {
            if (isset($errors)){           
                foreach ($errors as $error){
                        print '<p class="alert alert-danger">'.$error. '</p>';
                }            
            }
            exit();
        }
        if ($uploadOk == 1){
                return "OK";
        }
    
    }

?>



