<?php
include('../conexion/conexion.php');
$id = $_POST['id'];

//--------------------------Datos del Segundo Acordeon (SEGUIMIENTO)----------------------------------------------->
$inicioEstudio = mysqli_real_escape_string($conexion, $_POST['inicioEstudio']);//tipo numerico
$finEstudio = mysqli_real_escape_string($conexion, $_POST['finEstudio']);//tipo numerico
$selecBeca = mysqli_real_escape_string($conexion, $_POST['selecBeca']);//tipo numerico
$inicioBeca = mysqli_real_escape_string($conexion, $_POST['inicioBeca']);//tipo date
$finBeca = mysqli_real_escape_string($conexion, $_POST['finBeca']);//tipo date
$actExtra = mysqli_real_escape_string($conexion, $_POST['actExtra']);//tipo date
$causaBaja = mysqli_real_escape_string($conexion, $_POST['causaBaja']);//tipo date

//--------------------------PARA INGRESAR DATOS-------------------------
$actualizarIngreso = "";



//----------------------------------------------------------VALIDACIONES-----------------------------------------------------------
// Convertir la primera letra de cada palabra a mayúscula
$nombreEst = ucwords(strtolower($nombreEst));
    
// Validar que la clave de trabajador sea de 6 dígitos
    
// Validar que el sexo sea uno de los valores permitidos (Masculino o Femenino)
if ($sexo !== 'Masculino' && $sexo !== 'Femenino') {
        echo "Selecciona una opción válida para el sexo.";
        exit;
}




$actualizarIngreso = "UPDATE ingresoestudiante SET 
            expediente_estudiante = '". $expediente_estudiante ."', 
            nombreEst = '". $nombreEst ."', 
            sexo = '". $sexo ."', 
            grupoVulnerable = '". $grupoVulnerable ."', 
            matricula = '". $matricula ."', 
            numCVU = '". $numCVU ."', 
            posgrado = '". $posgrado ."', 
            generacion = '". $generacion ."'
            WHERE idEstudiante = '" . $id . "'";


$sqlIngreso = mysqli_query($conexion, $actualizarIngreso);


header("Location: ../principales/s.php");
?>
