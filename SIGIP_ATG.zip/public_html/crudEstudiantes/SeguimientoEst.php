<?php 

include('../conexion/conexion.php');

//--------------------------Datos del Segundo Acordeon (SEGUIMIENTO)----------------------------------------------->
$idEstudiante= mysqli_real_escape_string($conexion, $_POST['idEstudiante']);//tipo numerico
$inicioEstudio = mysqli_real_escape_string($conexion, $_POST['inicioEstudio']);//tipo numerico
$finEstudio = mysqli_real_escape_string($conexion, $_POST['finEstudio']);//tipo numerico
$selecBeca = mysqli_real_escape_string($conexion, $_POST['selecBeca']);//tipo numerico
$inicioBeca = mysqli_real_escape_string($conexion, $_POST['inicioBeca']);//tipo date
$finBeca = mysqli_real_escape_string($conexion, $_POST['finBeca']);//tipo date
$actExtra = mysqli_real_escape_string($conexion, $_POST['actExtra']);//tipo date
$causaBaja = mysqli_real_escape_string($conexion, $_POST['causaBaja']);//tipo date7

$agregarSeguimiento = "";//insertar
$actualizarSeguimiento = "";//actualizar

$sql = "SELECT * FROM seguimientoestudiante WHERE idEstudiante = '$idEstudiante'";
$res = $conexion->query($sql);

if ($res->num_rows > 0) {//si existen registros
    if($selecBeca === 'si'){

        $actualizarSeguimiento = "UPDATE seguimientoestudiante SET 
            inicioEstudio = '". $inicioEstudio ."', 
            finEstudio = '". $finEstudio ."', 
            selecBeca = '". $selecBeca ."', 
            inicioBeca = '". $inicioBeca ."', 
            finBeca = '". $finBeca ."', 
            actExtra = '". $actExtra ."', 
            causaBaja = '". $causaBaja ."' 
            WHERE idEstudiante = '" . $idEstudiante . "'";
    
    }else{
    
        $actualizarSeguimiento = "UPDATE seguimientoestudiante SET 
            inicioEstudio = '". $inicioEstudio ."', 
            finEstudio = '". $finEstudio ."', 
            selecBeca = '". $selecBeca ."', 
            inicioBeca = '0000-00-00', 
            finBeca = '0000-00-00', 
            actExtra = '". $actExtra ."', 
            causaBaja = '". $causaBaja ."'
            WHERE idEstudiante = '" . $idEstudiante . "'";
    
    }


    
    $sqlSeguimiento = mysqli_query($conexion, $actualizarSeguimiento);
    
} else {//si no existe registros
    if($selecBeca === 'si'){
        $agregarSeguimiento = "INSERT INTO seguimientoestudiante (idEstudiante, inicioEstudio, finEstudio, selecBeca, inicioBeca, finBeca, actExtra, causaBaja)
                VALUES ('$idEstudiante','$inicioEstudio', '$finEstudio', '$selecBeca', '$inicioBeca', '$finBeca', '$actExtra', '$causaBaja')";
    }else{
        $agregarSeguimiento = "INSERT INTO seguimientoestudiante (idEstudiante, inicioEstudio, finEstudio, selecBeca, inicioBeca, finBeca, actExtra, causaBaja)
                VALUES ('$idEstudiante','$inicioEstudio', '$finEstudio', '$selecBeca', '0000-00-00', '0000-00-00', '$actExtra', '$causaBaja')";
    }

    
    $sqlSeguimiento = mysqli_query($conexion, $agregarSeguimiento);
}






header("Location: ../principales/generalesEstudiantes.php");
?>