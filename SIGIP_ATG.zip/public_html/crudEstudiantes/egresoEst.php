<?php 

include('../conexion/conexion.php');

//--------------------------Datos del Tercer Acordeon (EGRESO)----------------------------------------------->
$idEstudiante= mysqli_real_escape_string($conexion, $_POST['idEstudiante']);//tipo numerico
$graduacion = mysqli_real_escape_string($conexion, $_POST['graduacion']);//tipo numerico
$continuaEstudios = mysqli_real_escape_string($conexion, $_POST['continuaEstudios']);//tipo numerico
$sni = mysqli_real_escape_string($conexion, $_POST['sni']);//tipo numerico
$anioIngreso = mysqli_real_escape_string($conexion, $_POST['anioIngreso']);//tipo date
$lugarTrabaja = mysqli_real_escape_string($conexion, $_POST['lugarTrabaja']);//tipo date
$aQueSeDedica = mysqli_real_escape_string($conexion, $_POST['aQueSeDedica']);//tipo date


$agregarEgreso = "";
$actualizarEgreso = "";

$sql = "SELECT * FROM egeresoestudiante WHERE idEstudiante = '$idEstudiante'";
$res = $conexion->query($sql);

if ($res->num_rows > 0) {//si existen registros

    $actualizarEgreso = "UPDATE egeresoestudiante SET 
    graduacion = '". $graduacion ."', 
    continuaEstudios = '". $continuaEstudios ."', 
    sni = '". $sni ."', 
    anioIngreso = '". $anioIngreso ."', 
    lugarTrabaja = '". $lugarTrabaja ."', 
    aQueSeDedica = '". $aQueSeDedica ."'
    WHERE idEstudiante = '" . $idEstudiante . "'";   

    $sqlEgreso = mysqli_query($conexion, $actualizarEgreso);

} else {//si no existe registros
    $agregarEgreso = "INSERT INTO egeresoestudiante (idEstudiante, graduacion, continuaEstudios, sni, anioIngreso, lugarTrabaja, aQueSeDedica)
    VALUES ('$idEstudiante','$graduacion', '$continuaEstudios', '$sni', '$anioIngreso', '$lugarTrabaja', '$aQueSeDedica')";
    
    $sqlEgreso = mysqli_query($conexion, $agregarEgreso);
}



header("Location: ../principales/generalesEstudiantes.php");
?>