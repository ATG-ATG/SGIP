<?php
include('../conexion/conexion.php'); //consulta para los datos obtenidos anteriormente en la base de datos

// include_once 'includes/php-pagination-class.php';
//session_start ();
//session_cache_expire(1);
//$_SESSION ['archivo'] = "dictamen.php";
//if (empty($_SESSION['login'])) {
//		header( 'Location: login.php' );
//		die;
//}
//$nom= $_SESSION['nombre'];
//$num = $_SESSION['user'];
//$userid = $_SESSION['userid'];
//$usernivel =  $_SESSION['nivel'];
//include_once '../dao/daoexpeposgrado.php';
       
         $Archivo = $_POST['eliminaarchi'];
         $idEstu = $_POST['idestu'];
         if (empty($Archivo)){
             print 'Error: No se proporcion&oacute; un nombre de archivo';
             exit();
         }
        
        $StatusBorra =1; 
        if (!file_exists('filesestudiantes/'.$Archivo)) {
            $StatusBorra = 0;
            $errors[] = 'Archivo: '.'filesestudiantes/'.$Archivo.' a borrar no existe';  
        } 
        else {
            if (!unlink("filesestudiantes/$Archivo")){
                $StatusBorra = 0;
                $errors[] = 'Ocurri&oacute; un error al intentar borrar archivo';  
              }
              else {
                  $messages [] = 'OK: El archivo se borr&oacute; con exito';
                $sql="UPDATE ingresoestudiante SET expediente_estudiante = '' WHERE idEstudiante = $idEstu";
                $result = mysqli_query($conexion, $sql);
                if ($result) {
                    $messages[] = 'OK: Se actualizo la BD correctamente';
                }

                }
        
        }       
        if ($StatusBorra == 0)  {  
            if (isset($errors)){           
                foreach ($errors as $error){
                        echo"<p>$error</p>";
                }            
            }
            exit();
        }
    print ("OK");
        