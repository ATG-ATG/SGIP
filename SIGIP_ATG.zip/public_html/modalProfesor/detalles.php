<?php
include('../conexion/conexion.php'); 
include('../conexion/key.php');

$id = isset($_GET['id']) ? $_GET['id'] : '';
$token = isset($_GET['token']) ? $_GET['token'] : '';

if ($id == '' || $token == '') {
    echo "Error al procesar la petición";
    exit;
} else {
    $token_tmp = hash_hmac('sha256', $id, KEY_TOKEN);//antes se usaba "shal" pero da error, asi que se usa sha256

    if ($token == $token_tmp) {
        // Utilizar una consulta preparada con un marcador de posición (?)
        //para datos personales
        $sql_detalle = "SELECT * FROM profesores WHERE profid=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle = mysqli_prepare($conexion, $sql_detalle);//se prepara la consulta antes de hacer la ejecucion
        //para datos academicos
        $sql_detalle2 = "SELECT * FROM academicosprofesor WHERE profid=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle2 = mysqli_prepare($conexion, $sql_detalle2);//se prepara la consulta antes de hacer la ejecucion
        //para datos laborales
        $sql_detalle3 = "SELECT * FROM laboralesprofesor WHERE profid=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle3 = mysqli_prepare($conexion, $sql_detalle3);//se prepara la consulta antes de hacer la ejecucion

        $sql_detalle4 = "SELECT * FROM masposgrados WHERE idProfesor=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle4 = mysqli_prepare($conexion, $sql_detalle4);//se prepara la consulta antes de hacer la ejecucion



        //La función mysqli_stmt_bind_param() se utiliza para vincular valores a los marcadores de posición en una consulta SQL preparada antes de ejecutarla
        //msqli_stm =  representa la consulta preparada, y el segundo valor despues de eso son los valores que se van a vincular.
        mysqli_stmt_bind_param($detalle, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle);
        $res_detalle = mysqli_stmt_get_result($detalle);//La función mysqli_stmt_get_result() se utiliza para obtener un conjunto de resultados desde una consulta 
        //preparada en forma de un objeto mysqli_result. Esta función es útil cuando necesitas obtener y manipular los resultados de una consulta SELECT que ha sido 
        //ejecutada utilizando una consulta preparada.

        mysqli_stmt_bind_param($detalle2, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle2);
        $res_detalle2 = mysqli_stmt_get_result($detalle2);//para los datos academicos 
        
        mysqli_stmt_bind_param($detalle3, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle3);
        $res_detalle3 = mysqli_stmt_get_result($detalle3);//para los datos academicos 

        mysqli_stmt_bind_param($detalle4, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle4);
        $res_detalle4 = mysqli_stmt_get_result($detalle4);//para los datos academicos 



        if ($res_detalle && $res_detalle2 && $res_detalle3 && $res_detalle4) {
            $row_detalle = mysqli_fetch_array($res_detalle);//hace un recorrido por todos los valores que contiene la variable $res_detalle(datos generales)
            $row_detalle2 = mysqli_fetch_array($res_detalle2);//hace un recorrido por todos los valores que contiene la variable $res_detalle2(datos academicos)
            $row_detalle3 = mysqli_fetch_array($res_detalle3);//hace un recorrido por todos los valores que contiene la variable $res_detalle2(datos academicos)
            $row_detalle4 = mysqli_fetch_array($res_detalle4);//hace un recorrido por todos los valores que contiene la variable $res_detalle2(mas posgrados)

            // Ahora puedes acceder a los datos del profesor utilizando el array asociativo $row_detalle.
            $nombre = $row_detalle['nombre'];
            $apellidoPaterno = $row_detalle['apellidoPaterno'] ?? '';
            $apellidoMaterno = $row_detalle['apellidoMaterno'] ?? '';
            $claveTrabajador = $row_detalle['claveTrabajador'] ?? '';
            $correo = $row_detalle['correo'] ?? '';
            $telefono = $row_detalle['telefono'] ?? '';
            $sexo = $row_detalle['sexo'] ?? '';
            $nacionalidad = $row_detalle['nacionalidad'] ?? '';
            $pais = $row_detalle['pais'] ?? '';
            $estado = $row_detalle['estado'] ?? '';
//datos academicos
            $gradoAcademico = $row_detalle2['gradoAcademico'] ?? '';
            $instGrado = $row_detalle2['insUltimoGrado'] ?? '';
            $anioObtGrado = $row_detalle2['anioObtGrado'] ?? '';
            $url = $row_detalle2['urlProductividad'] ?? '';
            $vigenciaSNI = $row_detalle2['vigenciaSNI'] ?? '';
            $areaEstudios = $row_detalle2['areaEstudios'] ?? '';
            $sni = $row_detalle2['sni'] ?? '';
            $nacionalidad2 = $row_detalle2['nacionalidad2'] ?? '';
            $pais2 = $row_detalle2['pais2'] ?? '';
            $cvun = $row_detalle2['cvun'] ?? '';
            //$cvu = $row_detalle2['cvu'] ?? ''; archivo cvu
            $cvu =  $row_detalle2['cvu'];//tipo texto
            $estado2 = $row_detalle2['estado2'] ?? '';
//datos laborales
            $adscripcion = $row_detalle3['adscripcion'] ?? '';
            $posgrados = $row_detalle3['posgrados'] ?? '';
            $tiempoPosgrado = $row_detalle3['tiempoPosgrado'] ?? '';
//Mas posgrados
            $posgrado1 = $row_detalle4['posgrado1'] ?? '';
            $tiempoPosgrado1 = $row_detalle4['tiempoPosgrado1'] ?? '';
            $posgrado2 = $row_detalle4['posgrado2'] ?? '';
            $tiempoPosgrado2 = $row_detalle4['tiempoPosgrado2'] ?? '';
            $posgrado3 = $row_detalle4['posgrado3'] ?? '';
            $tiempoPosgrado3 = $row_detalle4['tiempoPosgrado3'] ?? '';
            $posgrado4 = $row_detalle4['posgrado4'] ?? '';
            $tiempoPosgrado4 = $row_detalle4['tiempoPosgrado4'] ?? '';
            $posgrado5 = $row_detalle4['posgrado5'] ?? '';
            $tiempoPosgrado5 = $row_detalle4['tiempoPosgrado5'] ?? '';


        } else {
            echo "Error al obtener los detalles del profesor: " . mysqli_error($conexion);
        }
    } else {
        echo "Error al procesar la petición";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del profesor</title>
    <!-- boostraps -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link rel="stylesheet" href="../css/detalles.css">
</head>
<?php include_once('../menu.php');?><!--INCLUIR EL MENU-->
<body>
    <div class="row">
    
    <div class="col-8">
        <div data-bs-spy="scroll" data-bs-target="#list-example" data-bs-smooth-scroll="true" class="scrollspy-example" tabindex="0">
        <h4 id="list-item-1">Datos Personales</h4>
        <p><?php 
        echo "Nombre del Profesor(a): " . $nombre . "<br>";
        echo "Primer Apellido: " . $apellidoPaterno . "<br>";
        echo "Segundo Apellido: " . $apellidoMaterno . "<br>";
        echo "Clave de trabajador: " . $claveTrabajador . "<br>";
        echo "Correo: " . $correo . "<br>";
        echo "Teléfono: " . $telefono . "<br>";
        echo "Sexo: " . $sexo . "<br>";
        echo "Nacionalidad: " . $nacionalidad . "<br>";
        if($nacionalidad == 'Mexicana'){
            echo "Estado: " . $estado . "<br>";
        }else{
            if($pais=='otro'){
                $otroPais = $row_detalle['otroPais'];
                echo "País: " . $otroPais . "<br>";    
            }
            echo "País: " . $pais . "<br>";
        }

        ?></p>
        <p><?php ?></p>
        
        <h4 id="list-item-2">Datos Académicos</h4>
        <p><?php 
        echo "Grado Académico: " . $gradoAcademico . "<br>";
        echo "Institución de obtención de último grado: " . $instGrado . "<br>";
        echo "Nacionalidad: " . $nacionalidad2 . "<br>";
        if($nacionalidad2 == 'Mexicana'){

            echo "estado: " . $estado2 . "<br>";
        }else{
            if($pais2=='otro'){
                $otroPais2 = $row_detalle2['otroPais2'];
                echo "País: " . $otroPais2 . "<br>";    
            }
            echo "País: " . $pais2 . "<br>";
        }
        echo "Año de obtención de grado: " . $anioObtGrado . "<br>";
        echo "Número de CVU CONAHCyT: " . $cvun . "<br>";
        echo 'Expediente del profesor: <a href="../crudProfesor/filesprofesor/'.$cvu.'"'.' target="_blank">'.$cvu.'</a><br>';
        //echo "ARCHIVO CVU CONAHCYT: <a href=\"$cvu\" target=\"_blank\">$cvu</a><br>";
        echo "Área de estudios: " . $areaEstudios . "<br>";
        echo "SNI: " . $sni . "<br>";
        echo "Vigencia del SNI: " . $vigenciaSNI . "<br>";
        //echo "Productividad: " . $url . "<br>";
        echo "Productividad: <a href=\"$url\" target=\"_blank\">$url</a><br>";
?>
        </p>
        <h4 id="list-item-3">Datos Laborales</h4>
        <p>
            <?php echo "Posgrado al que pertenece: " . $posgrados . "<br>";?>
            <?php echo "Adscripcion actual: " . $adscripcion . "<br>";?>
            <?php echo "Tiempo en el Posgrado: " . $tiempoPosgrado . "<br>";?>
        </p>
        <h4 id="list-item-4">Posgrados en las que participa</h4>
            <?php
            if(!$posgrado1 == "" && !$tiempoPosgrado1 ==""){
                echo "Posgrado 1: " . $posgrado1 . "<br>";
                echo "Tiempo del posgrado 1: " . $tiempoPosgrado1 . "<br>";
                if(!$posgrado2 == "" && !$tiempoPosgrado2 ==""){
                    echo "Posgrado 2: " . $posgrado2 . "<br>";
                    echo "Tiempo del posgrado 2: " . $tiempoPosgrado2 . "<br>";
                    if(!$posgrado3 == "" && !$tiempoPosgrado3 ==""){
                        echo "Posgrado 3: " . $posgrado3 . "<br>";
                        echo "Tiempo del posgrado 3: " . $tiempoPosgrado3 . "<br>";
                        if(!$posgrado4 == "" && !$tiempoPosgrado4 ==""){
                            echo "Posgrado 4: " . $posgrado4 . "<br>";
                            echo "Tiempo del posgrado 4: " . $tiempoPosgrado4 . "<br>";
                            if(!$posgrado5 == "" && !$tiempoPosgrado1 ==""){
                                echo "Posgrado 5: " . $posgrado5 . "<br>";
                                echo "Tiempo del posgrado 5: " . $tiempoPosgrado5 . "<br>";
                            }
                        }
                    }
                }
            }else{
                echo "No participa en mas posgrados";
            }
           
            ?>
        </div>
    </div>
    </div>
</body>
</html>
