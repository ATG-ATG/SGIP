<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <!-- boostraps -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Profesor Externo</title>
</head>
<?php include_once('../menu.php');?>
<?php include('../conexion/conexion.php');?>
<body>

    

    <div style="width: 80%; margin: auto;">
    <h3 class="modal-title">
        Ingresa los datos del Profesor Externo
    </h3>
    <form method="POST" action="../crudProfesorExterno/insertar.php" enctype="multipart/form-data">

<!--------------------------------------------------------PRIMER ACORDEON (DATOS GENERALES)------------------------------------------->
            
                    <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                       <h4>Datos Personales</h4> 
                    </button>
                            
                            <div class="row">
                                <div class="col">
                                    <div class="form-group">
                                        <label for="nombre" class="col-form-label">Nombre</label>
                                        <input type="text" name="nombre" id="nombre" class="form-control" required placeholder="Nombre del Profesor" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-group">
                                        <label for="apellidoPaterno" class="col-form-label">Primer Apellido</label>
                                        <input type="text" name="apellidoPaterno" id="apellidoPaterno" class="form-control" required placeholder="Primer Apellido del Profesor" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-group">
                                        <label for="apellidoMaterno" class="col-form-label">Segundo Apellido</label>
                                        <input type="text" name="apellidoMaterno" id="apellidoMaterno" class="form-control" required placeholder="Segundo Apellido del Profesor" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col">
                                    <div class="form-group">
                                        <label for="claveTrabajador" class="col-form-label">Clave del Profesor</label>
                                        <input type="number" name="claveTrabajador" id="claveTrabajador" class="form-control" pattern="\d{6}" min="000000" max="999999" title="Ingresa 6 dígitos" placeholder="Ingresa 6 digitos" required>
                                    </div>  
                                </div>
                                <div class="col">
                                    <div class="form-group">
                                        <label for="correo" class="col-form-label">Correo Electrónico</label>
                                        <input type="email" id="correo" name="correo" class="form-control" required placeholder="Correo Electrónico del Profesor" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}">
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-group">
                                        <label for="telefono" class="col-form-label">Teléfono</label>
                                        <input type="number" name="telefono" id="telefono" class="form-control" title="Ingresa un número de teléfono a 10 dígitos" placeholder="Ingresa 10 dígitos" required>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col">
                                    <div class="form-group">
                                        <br>
                                        <label for="nacionalidad">Nacionalidad del Profesor:</label>
                                        <select name="nacionalidad" id="nacionalidad" onchange="mostrarOpciones()" required>
                                            <option selected disabled value="">Selecciona una opción</option>
                                            <?php
                                                $sql = "SELECT * FROM `concentradoacademico`";//hace una consulta
                                                $res = mysqli_query($conexion, $sql);//guarda consulta

                                                while ($row = mysqli_fetch_array($res)) {//mientras contengas datos en el array
                                                    $nacionalidad = $row['nacionalidades'];//obtiene el dato del campo 'nacionalidades'
                                                    if(!$nacionalidad==""){//condicional para no mostrar los campos en blanco de la base de datos
                                            ?>
                                                        <!--muestra en el select los datos-->
                                                        <option value="<?php echo $nacionalidad; ?>"><?php echo $nacionalidad; ?></option>
                                            <?php
                                                    }
                                                }
                                            ?>
                                        </select>

                                        <div id="opcionesEstados" style="display: none;">
                                            <label for="estado">Estados de México:</label>
                                            <select id="estado" name="estado">
                                            <?php
                                                $sql = "SELECT * FROM `concentradoacademico`";//hace una consulta
                                                $res = mysqli_query($conexion, $sql);//guarda consulta
                                                while ($row = mysqli_fetch_array($res)) {
                                                    $estado = $row['estados'];//condicional para no mostrar los campos en blanco de la base de datos
                                                    if(!$estado==""){
                                            ?>
                                                        <option value="<?php echo $estado;?>"><?php echo $estado; ?></option>
                                            <?php
                                                    }
                                                }
                                            ?>
                                            </select>
                                        </div>

                                        <div id="opcionesPaises" style="display: none;">
                                            <label for="pais">Países:</label>
                                            <select id="pais" name="pais" onchange="mostrarOtroPais()">
                                            <option selected disabled value="">Selecciona un país</option>
                                                <?php

                                                $sql = "SELECT * FROM `concentradoacademico`";//hace una consulta
                                                $res = mysqli_query($conexion, $sql);//guarda consulta

                                                while ($row = mysqli_fetch_array($res)) {
                                                    $pais = $row['paises'];
                                                    if(!$pais==""){//condicional para no mostrar los campos en blanco de la base de datos
                                                ?>
                                                        <option value="<?php echo $pais; ?>"><?php echo $pais; ?></option>

                                                <?php
                                                    }
                                                }
                                                ?>
                                            <option value="otro">Otro</option>
                                            </select>
                                            <br>

                                            <div id="campoOtroPais" style="display: none;">
                                            <label for="otroPais">Ingresa el nombre del país:</label>
                                            <input type="text" id="otroPais" name="otroPais" placeholder="Nombre del país">
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col">
                                    <div class="form-group">
                                        <br>
                                        <label for="">Sexo:</label>
                                        <label for="masculino">Masculino</label>
                                        <input type="radio" name="sexo" id="masculino" value="Masculino">
                            
                                        <label for="femenino">Femenino</label>
                                        <input type="radio" name="sexo" id="femenino" value="Femenino">
                                    </div>
                                </div>
                            </div>
        <!--------------------------------------------------FIN PRIMER ACORDEON (DATOS GENERALES)------------------------------------------->
            <!--------------------------------------------------------SEGUNDO ACORDEON (DATOS ACADEMICOS)------------------------------------------->
            
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        <h4>Datos Académicos</h4>
                    </button><!---------accordionBody-------->
                            <div class="row"><!--FILA 1-->
                                <div class="col"><!--COLUMNA 1 FILA 1-->
                                    <div class="form-group"><!--GRUPO DE FORMULARIO-->
                                        <label for="gradoAcademico" class="col-form-label">Grado Académico</label>
                                        <select name="gradoAcademico" id="gradoAcademico" class="form-select" required>
                                            <option selected disabled value="">elige una opción...</option><!--"selected disabled value=" metodo para dejar inhablitado la opcion de 'elige una opcion'-->

                                            <?php
                                            $sql = "SELECT * FROM `concentradoacademico`";
                                            $res = mysqli_query($conexion, $sql);

                                            while ($row = mysqli_fetch_array($res)) {
                                                $gradoAcademico = $row['gradoAcademico'];
                                                if(!$gradoAcademico==""){ //esto ayuda para que en caso de que en la base de datos este algun dato abajo vacio o null
                                                    //no se muestren en los select
                                            ?>
                                                <option value="<?php echo $gradoAcademico; ?>"><?php echo $gradoAcademico; ?></option>

                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div><!--FIN GRUPO DE FORMULARIO-->
                                </div><!--FIN COLUMNA 1 FILA 1-->

                                <div class="col">
                                    <div class="form-group">
                                        <br>
                                        <label for="nacionalidad2">Nacionalidad Académico:</label>
                                        <select id="nacionalidad2" name="nacionalidad2" onchange="mostrarOpciones2()" required>
                                            <option selected disabled value="">Selecciona una opción</option>
                                            <?php        
                                            $sql = "SELECT * FROM `concentradoacademico`";
                                            $res = mysqli_query($conexion, $sql);

                                            while ($row = mysqli_fetch_array($res)) {
                                                $nacionalidad2 = $row['nacionalidades'];
                                                if(!$nacionalidad2==""){
                                            ?>
                                            <option value="<?php echo $nacionalidad2; ?>"><?php echo $nacionalidad2; ?></option>
                                            <?php
                                                }
                                            }
                                            ?>
                                        </select>

                                        <div id="opcionEstados" style="display: none;">
                                            <label for="estado2">Estados de México:</label>
                                            <select id="estado2" name="estado2">
                                                <?php
                                                            
                                                    $sql = "SELECT * FROM `concentradoacademico`";
                                                    $res = mysqli_query($conexion, $sql);

                                                    while ($row = mysqli_fetch_array($res)) {
                                                        $estado2 = $row['estados'];
                                                        if(!$estado2==""){
                                                ?>
                                                            <option value="<?php echo $estado2; ?>"><?php echo $estado2; ?></option>

                                                <?php
                                                        }
                                                    }
                                                ?>
                                            </select>
                                        </div>

                                        <div id="opcionPaises" style="display: none;">
                                            <label for="pais2">País:</label>
                                            <select id="pais2" name="pais2" onchange="mostrarOtroPais2()">
                                                <option selected disabled value="">Selecciona un país</option>
                                                <?php
                                                                
                                                    $sql = "SELECT * FROM `concentradoacademico`";
                                                    $res = mysqli_query($conexion, $sql);

                                                    while ($row = mysqli_fetch_array($res)) {
                                                        $pais2 = $row['paises'];
                                                        if(!$pais2==""){
                                                ?>
                                                            <option value="<?php echo $pais2; ?>"><?php echo $pais2; ?></option>

                                                <?php
                                                        }
                                                    }
                                                ?>
                                                <option value="otro">Otro</option>
                                            </select>
                                            <br>

                                            <div id="campoOtroPais2" style="display: none;">
                                                <label for="otroPais2">Ingresa el nombre del país:</label>
                                                <input type="text" id="otroPais2" name="otroPais2" placeholder="Nombre del país">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="row"><!--FILA 2-->
                                <div class="col">
                                    <div class="form-group">
                                        <label for="instGrado" class="col-form-label">Institución de obtención del último grado</label>
                                        <select name="instGrado" id="instGrado" class="form-select" onchange="mostrarOtraInst()" required>
                                            <option selected disabled value="">elige una opción...</option>

                                            <?php
                                            $sql = "SELECT * FROM `concentradoacademico`";
                                            $res = mysqli_query($conexion, $sql);
                                            while ($row = mysqli_fetch_array($res)) {
                                                $instGrado = $row['instGrado'];
                                                if(!$instGrado==""){
                                            ?>
                                                    <option value="<?php echo $instGrado; ?>"><?php echo $instGrado; ?></option>
                                            <?php
                                                }    
                                            }
                                            ?>
                                            <option value="otro">Otro</option>
                                        </select>

                                        <div id="campoOtraInst" style="display: none;">
                                            <label for="otraInst">Ingresa la institución externa:</label>
                                            <input type="text" id="otraInst" name="otraInst" placeholder="Nombre de la Institución">
                                        </div>
                                    </div>
                                </div>
                                <!--FIN COLUMNA 1 FILA 2-->

                                <div class="col"><!--COLUMNA 2 FILA 2-->
                                    <div class="form-group">
                                        <label for="anioObtGrado" class="col-form-label">Año de obtencion de Grado(AAAA)</label>
                                        <input type="number" name="anioObtGrado" id="anioObtGrado" class="form-control" pattern="^(19|20)\d{2}$" title="Ingresa un año válido (entre 1900 y 2024)" min="1960" max="2024" placeholder="Ingresa 4 dígitos" required>
                                    </div>
                                </div><!--FIN COLUMNA 2 FILA 2-->
                            </div><!--FIN FILA 2-->


                            <div class="row"><!--FILA 3-->
                                <div class="col"><!--COLUMNA 1 FILA 3-->
                                    <div class="form-group">
                                        <label for="sni" class="col-form-label">SNI</label>
                                        <select  id="sni" name="sni" class="form-select" required>
                                        <option selected disabled value="">elige una opción...</option>

                                        <?php
                                                    
                                        $sql = "SELECT * FROM `concentradoacademico`";
                                        $res = mysqli_query($conexion, $sql);

                                        while ($row = mysqli_fetch_array($res)) {
                                            $sni = $row['sni'];
                                            if(!$sni==""){
                                        ?>
                                                <option value="<?php echo $sni; ?>"><?php echo $sni; ?></option>
                                        <?php
                                            }                
                                        }
                                        ?>
                                        </select>
                                    </div>
                                </div><!--FIN COLUMNA 1 FILA 3-->

                                <div class="col"><!--COLUMNA 2 FILA 3-->
                                    <div class="form-group">
                                        <label for="vigenciaSNI" class="col-form-label">Vigencia del SNI</label>
                                        <input type="date" name="vigenciaSNI" id="vigenciaSNI" min="1900-01-01" max="2050-12-31">
                                    </div>
                                </div><!--FIN COLUMNA 2 FILA 3-->

                            </div><!--FIN FILA 3-->


                            <div class="row"><!--FILA 4-->
                                <div class="col"><!--COLUMNA 1 FILA 4-->
                                    <div class="form-group">
                                        <label for="cvu" class="col-form-label">CVU CONAHCyT</label>
                                        <input type="file" name="cvu" id="cvu" class="form-control" required>
                                    </div>
                                </div><!--FIN COLUMNA 1 FILA 4-->
                                
                                <div class="col"><!--COLUMNA 1 FILA 4-->
                                    <div class="form-group">
                                        <label for="cvun" class="col-form-label">Número de CVU CONAHCyT</label>
                                        <input type="number" name="cvun" id="cvun" required class="form-control" min="1900-01-01" max="2050-12-31">
                                    </div>
                                </div>

                                <div class="col"><!--COLUMNA 2 FILA 4-->
                                    <div class="form-group">
                                        <label for="areaEstudios" class="col-form-label">Área de Estudios</label>
                                        <select name="areaEstudios" id="areaEstudios" class="form-select" required>
                                        <option selected disabled value="">elige una opción...</option>

                                        <?php                               
                                            $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                            $res = mysqli_query($conexion, $sql);
                                            while ($row = mysqli_fetch_array($res)) {
                                                $areaEstudios = $row['areaEstudio'];
                                                if(!$areaEstudios==""){
                                        ?>
                                                <option value="<?php echo $areaEstudios; ?>"><?php echo $areaEstudios; ?></option>
                                        <?php
                                                }                                                            
                                        }
                                        ?>
                                        </select>
                                    </div>
                                </div><!--FIN COLUMNA 2 FILA 4-->
                            </div><!--FIN FILA 4-->

                            <div class="row"><!--FILA 5-->
                                <div class="form-group">
                                    <label for="url" class="col-form-label">Productividad (URL)</label>
                                    <input type="url" name="url" id="url" required class="form-control" pattern="https?://.+">
                                </div>
                            </div><!--FIN FILA 5-->
        <!--------------------------------------------FIN SEGUNDO ACORDEON (DATOS ACADEMICOS)----------------------------------------------------> 
           
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                       <h4>Datos Laborales</h4> 
                    </button>
                        <div class="row"><!---------FILA 1-------->
                            <div class="form-group">
                                <label for="adscripcion" class="col-form-label">Adscripción actual</label>
                                <select name="adscripcion" id="adscripcion" class="form-select" required>
                                    <option selected disabled value="">elige una opción...</option>
                                    <?php
                                        $sql = "SELECT * FROM `sedeshospital`";
                                        $res = mysqli_query($conexion, $sql);
                                        while ($row = mysqli_fetch_array($res)) {
                                            $sedes = $row['sede'];
                                            if(!$sedes==""){
                                        ?>
                                            <option value="<?php echo $sedes; ?>"><?php echo $sedes; ?></option>
                                        <?php
                                            }

                                            
                                        }
                                        ?>
                                </select>
                            </div>
                        </div><!---------FIN FILA 1-------->

                        <div class="row"><!---------FILA 2-------->

                            <div class="col"><!---------COLUMNA 1 FILA 2-------->
                                <div class="form-group">
                                    <label for="posgrados" class="col-form-label">Sede hospital en el que participa</label>
                                    <select name="posgrados" id="posgrados" class="form-select" required>
                                        <option selected disabled value="">elige una opción...</option>

                                        <?php
                                        
                                        $sql = "SELECT * FROM `sedeshospital`";
                                        $res = mysqli_query($conexion, $sql);

                                        while ($row = mysqli_fetch_array($res)) {
                                            $nombre = $row['tipo'];
                                            if(!$nombre==""){
                                        ?>
                                                <option value="<?php echo $nombre; ?>"><?php echo $nombre; ?></option>
                                        <?php
                                            }                                                                
                                        }
                                        ?>
                                        </select>
                                </div>
                            </div><!---------FIN COLUMNA 1 FILA 2-------->

                            <div class="col"><!---------COLUMNA 2 FILA 2-------->
                                <div class="form-group">
                                    <label for="tiempoPosgrado" class="col-form-label">Dedicación en la sede</label>
                                    <select name="tiempoPosgrado" id="tiempoPosgrado" class="form-select" required>
                                    <option selected disabled value="">elige una opción...</option>
                                        <?php
                                        include '../conexion/config.php';
                                            $sql = "SELECT * FROM `concentradoacademico`";
                                            $res = mysqli_query($conexion, $sql);

                                            while ($row = mysqli_fetch_array($res)) {
                                                $tiempoPosgrado = $row['tiempoPosgrado'];
                                                if(!$tiempoPosgrado==""){
                                            ?>
                                                <option value="<?php echo $tiempoPosgrado; ?>"><?php echo $tiempoPosgrado; ?></option>
                                            <?php
                                                }

                                                
                                            }
                                            ?>
                                    </select>
                                </div>
                            </div><!---------FIN COLUMNA 2 FILA 2-------->

                        </div><!---------FIN FILA 2-------->

        <!--------------------------------------------FIN TERCER ACORDEON (DATOS LABORALES)----------------------------------------------------> 
        <div class="modal-footer">
                <a class="btn btn-outline-secondary" href="../principales/generalesProfesor.php">Cerrar</a>
                <button type="submit" class="btn btn-primary">Guardar</button>
        </div>
        </form>

    </div>

    </body>
</html>
<script src="../js/evaluarProfesor.js"></script>