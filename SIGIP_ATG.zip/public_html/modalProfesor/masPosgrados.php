<?php
include('../conexion/conexion.php');
include('../menu.php');

// Obtener la id del profesor (por ejemplo, desde la URL o una consulta a la base de datos)
$profesorId = isset($_GET['id']) ? $_GET['id'] : null;

if ($profesorId === null) {
    echo "Error: No se ha proporcionado una ID válida de profesor.";
    exit;
}

// Array para almacenar los datos obtenidos de la base de datos
$posgradosGuardados = []; // Array para los nombres de posgrados guardados
$tiemposPosgradoGuardados = []; // Array para los tiempos de posgrados guardados

// Obtener los datos actuales de la base de datos si existen
$sql = "SELECT * FROM masposgrados WHERE idProfesor = ?";
$stmt = $conexion->prepare($sql);
$stmt->bind_param("i", $profesorId);
$stmt->execute();
$res = $stmt->get_result();

if ($row = $res->fetch_assoc()) {
    // Guardar los nombres de posgrados y tiempos de posgrado si existen en la base de datos
    for ($i = 1; $i <= 5; $i++) {
        $posgradoCampo = "posgrado$i";
        $tiempoPosgradoCampo = "tiempoPosgrado$i";

        if (!empty($row[$posgradoCampo])) {
            $posgradosGuardados[$i] = $row[$posgradoCampo];
        }

        if (!empty($row[$tiempoPosgradoCampo])) {
            $tiemposPosgradoGuardados[$i] = $row[$tiempoPosgradoCampo];
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Posgrados</title>
</head>
<body>
    <div class="container">
        <h1>Agregar Posgrados</h1>
        <form id="posgradosForm" method="post" action="../crudProfesor/insertarPosgrados.php">
            <!-- Campo oculto para enviar la ID del profesor -->
            <input type="hidden" name="idProfesor" value="<?php echo $profesorId; ?>">
            
            <?php for ($i = 1; $i <= 5; $i++) { ?>
                <div class="row">
                    <div class="col">
                        <div class="form-group">
                            <label for="posgrado<?php echo $i; ?>">Posgrado <?php echo $i; ?>:</label>
                            <select name="posgrado<?php echo $i; ?>" id="posgrado<?php echo $i; ?>" class="form-select">
                                <option selected disabled value="">Elige una opción...</option>
                                <?php
                                $sql = "SELECT * FROM generalposgrados";
                                $res = mysqli_query($conexion, $sql);
                                while ($row = mysqli_fetch_array($res)) {
                                    $nombre = $row['nombre'];
                                    $selected = isset($posgradosGuardados[$i]) && $posgradosGuardados[$i] === $nombre ? 'selected' : '';
                                    if (!empty($nombre)) {
                                        ?>
                                        <option value="<?php echo $nombre; ?>" <?php echo $selected; ?>><?php echo $nombre; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                    <div class="col">
                        <div class="form-group">
                            <label for="tiempoPosgrado<?php echo $i; ?>">Tiempo Posgrado <?php echo $i; ?>:</label>
                            <select name="tiempoPosgrado<?php echo $i; ?>" id="tiempoPosgrado<?php echo $i; ?>" class="form-select">
                                <option selected disabled value="">Elige una opción...</option>
                                <?php
                                $sql = "SELECT * FROM concentradoacademico";
                                $res = mysqli_query($conexion, $sql);
                                while ($row = mysqli_fetch_array($res)) {
                                    $tiempoPosgrado = $row['tiempoPosgrado'];
                                    $selected = isset($tiemposPosgradoGuardados[$i]) && $tiemposPosgradoGuardados[$i] === $tiempoPosgrado ? 'selected' : '';
                                    if (!empty($tiempoPosgrado)) {
                                        ?>
                                        <option value="<?php echo $tiempoPosgrado; ?>" <?php echo $selected; ?>><?php echo $tiempoPosgrado; ?></option>
                                        <?php
                                    }
                                }
                                ?>
                            </select>
                        </div>
                    </div>
                </div>
            <?php } ?>
            <button type="submit" class="btn btn-primary">Guardar</button>
            <a class="btn btn-outline-secondary" href="../principales/generalesProfesor.php">Cerrar</a>
        </form>
    </div>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
