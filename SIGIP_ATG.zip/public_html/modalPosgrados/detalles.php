<?php
//detalles POSGRADOS
include('../conexion/conexion.php'); 
include('../conexion/key.php');

$id = isset($_GET['id']) ? $_GET['id'] : '';
$token = isset($_GET['token']) ? $_GET['token'] : '';

if ($id == '' || $token == '') {
    echo "Error al procesar la petición";
    exit;
} else {
    $token_tmp = hash_hmac('sha256', $id, KEY_TOKEN);//antes se usaba "shal" pero da error, asi que se usa sha256

    if ($token == $token_tmp) {
        // Utilizar una consulta preparada con un marcador de posición (?)
        //para datos personales
        $sql_detalle = "SELECT * FROM generalposgrados WHERE idposgrados=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle = mysqli_prepare($conexion, $sql_detalle);//se prepara la consulta antes de hacer la ejecucion
        //para datos  generales
        $sql_detalle2 = "SELECT * FROM evaluacionposgrado WHERE idposgrados=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle2 = mysqli_prepare($conexion, $sql_detalle2);//se prepara la consulta antes de hacer la ejecucion
        //para datos de evaluacion
        $sql_detalle3 = "SELECT * FROM fichatecnicapos WHERE idposgrados=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle3 = mysqli_prepare($conexion, $sql_detalle3);//se prepara la consulta antes de hacer la ejecucion
        //para datos de la ficha tecnica
        $sql_detalle4 = "SELECT * FROM asistentepos WHERE idposgrados=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle4 = mysqli_prepare($conexion, $sql_detalle4);//se prepara la consulta antes de hacer la ejecucion
        //para datos de asistente

        //La función mysqli_stmt_bind_param() se utiliza para vincular valores a los marcadores de posición en una consulta SQL preparada antes de ejecutarla
        //msqli_stm =  representa la consulta preparada, y el segundo valor despues de eso son los valores que se van a vincular.
        mysqli_stmt_bind_param($detalle, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle);
        $res_detalle = mysqli_stmt_get_result($detalle);//La función mysqli_stmt_get_result() se utiliza para obtener un conjunto de resultados desde una consulta 
        //preparada en forma de un objeto mysqli_result. Esta función es útil cuando necesitas obtener y manipular los resultados de una consulta SELECT que ha sido 
        //ejecutada utilizando una consulta preparada.

        mysqli_stmt_bind_param($detalle2, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle2);
        $res_detalle2 = mysqli_stmt_get_result($detalle2);//para los datos de evaluacion 
        
        mysqli_stmt_bind_param($detalle3, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle3);
        $res_detalle3 = mysqli_stmt_get_result($detalle3);//para ficha tecnica de posgrados

        mysqli_stmt_bind_param($detalle4, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle4);
        $res_detalle4 = mysqli_stmt_get_result($detalle4);//para asistentes de posgrados




        if ($res_detalle && $res_detalle2 && $res_detalle3 && $res_detalle4) {
            $row_detalle = mysqli_fetch_array($res_detalle);//hace un recorrido por todos los valores que contiene la variable $res_detalle(datos generales)
            $row_detalle2 = mysqli_fetch_array($res_detalle2);//hace un recorrido por todos los valores que contiene la variable $res_detalle2(datos evaluacion)
            $row_detalle3 = mysqli_fetch_array($res_detalle3);//hace un recorrido por todos los valores que contiene la variable $res_detalle3(datos ficha tecnica)
            $row_detalle4 = mysqli_fetch_array($res_detalle4);//hace un recorrido por todos los valores que contiene la variable $res_detalle4(datos asistente)

            $nombre =  $row_detalle['nombre'];//tipo texto
            $numSPN =  $row_detalle['numSPN'];//tipo numerico
            $numREG =  $row_detalle['numREG'];//tipo numerico
            $grado =  $row_detalle['grado'];
            $orientacion =  $row_detalle['orientacion'];
            $areaEstudio =  $row_detalle['areaEstudio'];
            $region =  $row_detalle['region'];
            //$direccion = $row_detalle['direccion'];
            $dependencia = $row_detalle['dependencia'];
            $nombreCoord =  $row_detalle['nombreCoord'];//tipo texto
            $apellidoPCoord = $row_detalle['apellidoPCoord'];//tipo texto
            $apellidoMCoord = $row_detalle['apellidoMCoord'];//tipo texto
            $anioInicio =  $row_detalle['anioInicio'];//tipo numerico
            $inicioposg =  $row_detalle['inicioposg'];//tipo numerico
            //$gradoCoord = $row_detalle['gradoCoord'];//tipo numerico
            $correo = $row_detalle['correo'];
            $telefono = $row_detalle['telefono'];
            $pagWeb = $row_detalle['pagWeb'];
            //obtencion de dato añadido
            $sexo =  $row_detalle['sexo'];
            //--------------------------Datos del Segundo Acordeon (Evaluacion)----------------------------------------------->
            $instPos = $row_detalle2['instPos'];
           // $doc = $row_detalle2['doc'];
            $ultEva = $row_detalle2['ultEva'];//tipo numerico
            //$nucleoAcademico = $row_detalle2['nucleoAcademico'];
            //--------------------------Datos del Tercer Acordeon (Ficha Tecnica)----------------------------------------------->
            $periocidad = $row_detalle3['periocidad'];
           // $docft = $row_detalle3['docft'];
            $durPos =  $row_detalle3['durPos'];
            $credito =  $row_detalle3['credito'];
            //--------------------------Datos del Cuarto Acordeon (Asistentes)----------------------------------------------->
            $nombreAsis = $row_detalle4['nombreAsis'];//tipo texto
            $apellidoPAsis = $row_detalle4['apellidoPAsis'];//tipo texto
            $apellidoMAsis = $row_detalle4['apellidoMAsis'];//tipo texto
            $correoAsis =  $row_detalle4['correoAsis'];
            $telefonoAsis =  $row_detalle4['telefonoAsis'];//tipo numerico
            /*abajo, dato para poder evaluar si es ese u otro dato, no modificar*/
            $tipoTrabajo =  $row_detalle4['tipoTrabajo'];//tipo de seleccion "otro"
            /*arriba, dato para poder evaluar si es ese u otro dato, no modificar*/
            $otroAsistente = $row_detalle4['otroAsistente2'] ?? '';//tipo texto
            $nombreAsis2 = $row_detalle4['nombreAsis2'] ?? '';//tipo texto
            $apellidoPAsis2 = $row_detalle4['apellidoPAsis2'] ?? '';//tipo texto
            $apellidoMAsis2 = $row_detalle4['apellidoMAsis2'] ?? '';//tipo texto
            $correoAsis2 = $row_detalle4['correoAsis2'] ?? '';//tipo texto
            $telefonoAsis2 = $row_detalle4['telefonoAsis2'] ?? '';//tipo texto
            $tipoTrabajo2 = $row_detalle4['tipoTrabajo2'] ?? '';//tipo texto

        } else {
            echo "Error al obtener los detalles del profesor: " . mysqli_error($conexion);
        }
    } else {
        echo "Error al procesar la petición";
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles de posgrados</title>
    <!-- boostraps -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/detalles.css">
</head>
<?php include_once('../menu.php');?><!--INCLUIR EL MENU-->
<body>
    <div class="row">
    <div class="col-8">
        <div data-bs-spy="scroll" data-bs-target="#list-example" data-bs-smooth-scroll="true" class="scrollspy-example" tabindex="0">
        <h4 id="list-item-1">Datos Generales</h4>
            <p><?php 
            echo "Nombre del Progrado: " . $nombre . "<br>";
            echo "Número de registro SNP: " . $numSPN . "<br>";
            echo "Número de registro Profesiones: " . $numREG . "<br>";
            echo "Correo del posgrado: " . $correo . "<br>";
            echo "Telefono: " . $telefono . "<br>";
            echo "Grado de Estudio: " . $grado . "<br>";
            echo "Orientacion del posgrado: " . $orientacion . "<br>";
            echo "Región: " . $region . "<br>";
            //echo "Direccion: " . $direccion . "<br>";
            echo "Dependencia: " . $dependencia . "<br>";
            echo "Nombre del Coordinador: " . $nombreCoord . "  " . $apellidoPCoord .  "  " . $apellidoMCoord ."<br>";
            //echo "Segundo Apellido del Coordinador: " . $apellidoMCoord . "<br>";
            //echo "Grado del Coordinador: " . $gradoCoord . "<br>";
            echo "Sexo: " . $sexo . "<br>";
            echo "Año de inicio del coordinador: " . $anioInicio . "<br>";
            echo "Año de inicio del posgrado: " . $inicioposg . "<br>";
            //echo "Pagina Web: " . $pagWeb . "<br>";
            echo "Página Web: <a href=\"$pagWeb\" target=\"_blank\">$pagWeb</a><br>";
            ?></p>
        
        
        <h4 id="list-item-2">Evaluación</h4>
            <p><?php 
            if($instPos == 'otro'){
                $otraInst = $row_detalle['otraInst'];
                echo "Instancia Evaluadora: " . $otraInst . "<br>";
            }else{
                echo "Instancia Evaluadora: " . $instPos . "<br>";
            }
           // echo "Documento de la Evaluación: " . $doc . "<br>";
            echo "Año de la última evaluacion: " . $ultEva . "<br>";
           // echo "Núcleo Académico: " . $nucleoAcademico . "<br>";
            ?></p>

        <h4 id="list-item-3">Ficha Técnica</h4>
            <p>
                <?php
                    echo "Periocidad : " . $periocidad . "<br>";
                   // echo "Ficha Técnica: " . $docft . "<br>";
                    echo "Duración del posgrado: " . $durPos . "<br>";
                    echo "Créditos: " . $credito . "<br>";
                ?>
            </p>
        <h4 id="list-item-4">Asistentes</h4>
            <p>
                <?php
                    echo "Nombre del Asistente : " . $nombreAsis . "<br>";
                    echo "Apellido Paterno: " . $apellidoPAsis . "<br>";
                    echo "Apellido Materno: " . $apellidoMAsis . "<br>";
                    echo "Correo Electrónico: " . $correoAsis . "<br>";
                    echo "Telefono: " . $telefonoAsis . "<br>";
                    if($tipoTrabajo == 'otro'){
                        $otroTrabajo = $row_detalle['otroTrabajo'];
                        echo "tipo de Trabajo: " . $otroTrabajo . "<br>";
                    }else{
                        echo "Tipo de Trabajo: " . $tipoTrabajo . "<br>";
                    }
                    if($otroAsistente === "si"){
                        echo "Nombre del segundo asistente: ". $nombreAsis2. "<br>";
                        echo "Apellido Paterno: ".$apellidoPAsis2. "<br>";
                        echo "Apellido Materno: ".$apellidoMAsis2. "<br>";
                        echo "Correo: ".$correoAsis2. "<br>";
                        echo "Telefono: ".$telefonoAsis2. "<br>";
                        echo "Tipo de trabajo: ".$tipoTrabajo2. "<br>";
                    }else{
                        echo "No hay mas asistentes". "<br>";
                    }
                ?>
            </p>
        </div>
        <a class="btn btn-outline-secondary" href="../principales/generalesPosgrados.php">Regresar</a>
    </div>
    </div>
</body>
</html>
