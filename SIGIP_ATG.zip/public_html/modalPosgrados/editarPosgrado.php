<!--
    Aqui se muestra los datos anteriormente al gaber agregado un posgrado.
    Esta informacion es enviada al archivo "editarPos.php", en la carpeta "baseDatosPos",
    para posteriormente, actualizar la tabla de datos
-->

<?php 
include('../conexion/conexion.php'); //consulta para los datos obtenidos anteriormente en la base de datos
$id = $_REQUEST['id'];

/**
 * SELECT * FROM "nombre de la tabla que estara en la bases de datos"
 * Todas las tablas que componene esto, tienen la misma idPosgrados, para identificar, no da errores
 */

//lines de codigo para obtener los valores previos del formulario
//------------------PRIMER ACORDEON (DATOS GENERALES----------------------------------)
$sql = "SELECT * FROM generalposgrados WHERE idPosgrados='" . $id . "'"; //se traeran el valor guardado en esta tabla(ir a codigo de linea: 237 )
$res = mysqli_query($conexion, $sql);
$datos_generales = mysqli_fetch_assoc($res);
$nombre_previo = $datos_generales['nombre'];//nombre del posgrado
$numSPN_previo = $datos_generales['numSPN'];//numero de registro SPN
$numREG_previo = $datos_generales['numREG'];//numero de registro SPN
$grado_previo = $datos_generales['grado'];//grado de estudios
$correo_previo = $datos_generales['correo'];
$telefono_previo = $datos_generales['telefono'];
$orientacion_previo = $datos_generales['orientacion'];//orientacion del posgrado
$areaEstudio_previo = $datos_generales['areaEstudio'];//area de estudio
$region_previo = $datos_generales['region'];//region del posgrado
//$direccion_previo = $datos_generales['direccion'];//direcciion del posgrado
$dependencia_previo = $datos_generales['dependencia'];//dependencia del posgrado
$nombreCoord_previo = $datos_generales['nombreCoord'];//nombre del posgrado
$apelldioPCoord_previo = $datos_generales['apellidoPCoord'];//nombre del posgrado
$apellidoMCoord_previo = $datos_generales['apellidoMCoord'];//nombre del posgrado
$gradoCoord_previo = $datos_generales['gradoCoord'];//grado del coordinador del posgrado
$sexo_previo = $datos_generales['sexo'];//sexo del coordinador
$anioInicio_previo = $datos_generales['anioInicio']?? '';//año de inicio
$anioInicio_previoposg = $datos_generales['inicioposg']?? '';//año de inicio
$pagWeb_previo = $datos_generales['pagWeb']?? '';//pagina web
$correo_previo = $datos_generales['correo']?? '';//pagina web
$telefono_previo = $datos_generales['telefono']?? '';//pagina web
$estadoposgrado_previo = $datos_generales['estadoposgrado']?? '';//pagina web
//------------------FIN PRIMER ACORDEON (DATOS GENERALES----------------------------------)

//------------------SEGUNDO  ACORDEON (EVALUACION)----------------------------------)
$sql2 = "SELECT * FROM `evaluacionposgrado` WHERE idPosgrados='" . $id . "'"; //se traeran el valor guardado en esta tabla(ir a codigo de linea: 237 )
$res2 = mysqli_query($conexion, $sql2);
$datos_evaluacion = mysqli_fetch_assoc($res2);
$instPos_previo = $datos_evaluacion['instPos']?? '';//intancia evaludadora del posgrado
$inicioposg_previo = $datos_evaluacion['inicioposg']?? '';
$actualizacion= $datos_evaluacion['actualizacion']?? '';
$ultEva_previo = $datos_evaluacion['ultEva']?? '';//iaño de ultima evaluacion del posgrado

//------------------FIN SEGUNDO  ACORDEON (EVALUACION)----------------------------------)

//------------------TERCER ACORDEON (FICHA TECNICA)----------------------------------)
$sql4 = "SELECT * FROM fichatecnicapos WHERE idPosgrados='" . $id . "'"; //se traeran el valor guardado en esta tabla(ir a codigo de linea: 237 )
$res4 = mysqli_query($conexion, $sql4);
$datos_asistente = mysqli_fetch_assoc($res4);
$periocidad_previo = $datos_asistente['periocidad']?? '';//periodicdad
$durPos_previo = $datos_asistente['durPos']?? '';//duracion del posgrado
$credito_previo = $datos_asistente['credito']?? '';//creditos
//------------------FIN TERCER ACORDEON (FICHA TECNICA)----------------------------------)


//------------------CUARTO ACORDEON (ASISTENTE))--------------------------------------)
$sql3 = "SELECT * FROM asistentepos WHERE idPosgrados='" . $id . "'"; //se traeran el valor guardado en esta tabla(ir a codigo de linea: 237 )
$res3 = mysqli_query($conexion, $sql3);
$datos_fichaTec = mysqli_fetch_assoc($res3);
$nombreAsis_previo = $datos_fichaTec['nombreAsis']?? '';//nombre del coordinador
$apellidoPAsis_previo = $datos_fichaTec['apellidoPAsis']?? '';//apellido paterno del coordinador
$apellidoMAsis_previo = $datos_fichaTec['apellidoMAsis']?? '';//apellido materno del coordinador
$correoAsis_previo = $datos_fichaTec['correoAsis']?? '';//apellido paterno del coordinador
$telefonoAsis_previo = $datos_fichaTec['telefonoAsis']?? '';//apellido paterno del coordinador
$tipoTrabajo_previo = $datos_fichaTec['tipoTrabajo']?? '';//apellido paterno del coordinador
$otroAsistente = $datos_fichaTec['otroAsistente2'] ?? '';
//------------------CUARTO ACORDEON (ASISTENTE)----------------------------------)

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">

    <!-- boostraps -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Editar Posgrado</title>

    <link rel="stylesheet" href="../css/editar.css">
</head>
<!--  -->

<?php
//nose al chile pa que sirve esto, alberto lo puso xd
$id = $_GET['id'];
$sql = "SELECT * FROM `generalposgrados` WHERE idposgrados='" . $id . "'";
$res = mysqli_query($conexion, $sql);
$row = mysqli_fetch_assoc($res);

?>

<?php include_once('../menu.php');?><!--INCLUIR EL MENU-->

<!--ventana para actualizar--->


<div style="width: 80%; margin: auto;">

  <form method="POST" action="../crudPosgrado/editar.php" enctype="multipart/form-data">
    <div class="modal-body" id="cont_modal">
      <h4>Datos Generales del posgrado: <?php echo $row['nombre'];?></h4>

        <div class="row">

            <div class="col">
            <div class="form-group">
                <input type="hidden" name="id" value="<?php echo $row['idPosgrados']; ?>">
                <label for="nombre" class="col-form-label">Nombre del posgrado</label>
                <input type="text" name="nombre" id="nombre" class="form-control" required value="<?php echo $row['nombre'] ?>">
            </div>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="numSPN" class="col-form-label">Número de registro SNP</label>
                    <input type="text" name="numSPN" id="numSPN" class="form-control" pattern="\d{6}" min="0000" max="999999" title="Ingresa 6 dígitos" placeholder="Ingresa 6 dígitos 000000" required value="<?php echo $row['numSPN'] ?>">
                </div>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="numREG" class="col-form-label">Número de Registro en Profesiones</label>
                    <input type="text" name="numREG" id="numREG" class="form-control" pattern="\d{6}" min="000000" max="999999" title="Ingresa 6 dígitos" placeholder="Ingresa 6 dígitos 000000" required value="<?php echo $row['numREG'] ?>">
                </div>
            </div>

            <div class="col">
                <?php 
                //grado academico del posgrado
                //En php y haces una consulta en la tabla de concentrados
                $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                $res = mysqli_query($conexion, $sql);
                
                //se hizo en php por que en html da errores
                echo '<div class="form-group">';
                echo '<label for="grado" class="col-form-label">Grado de estudio</label>';
                echo '<select name="grado" id="grado" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                //no mover lo de arriba, unicamente cambiar el nombre de las variables
                
                while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                    $grado = $row['grado'];//se obtiene el dato de la tabla concentradoacademico
                    if(!$grado==""){//que en caso de editar, no muestre los valores nulos
                        // Verificar si el valor actual coincide con el valor previo
                        $selected = ($grado == $grado_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                        //si coinciden, se deja seleccionado, sino evalua el otro
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo "<option value=\"$grado\" $selected>$grado</option>";
                    }
                }
                echo '</select>';
                echo '</div>';
                ?> 
            </div>

        </div>

        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label for="correo" class="col-form-label">Correo Electrónico</label>
                    <input type="email" id="correo" name="correo" class="form-control" required placeholder="Correo Electrónico del Posgrado" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" value="<?php echo $correo_previo ?>">
                </div>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="telefono" class="col-form-label">Teléfono</label>
                    <input type="tel" name="telefono" id="telefono" class="form-control" title="Ingresa un número de teléfono a 10 dígitos" placeholder="Ingresa 10 dígitos" required value="<?php echo $telefono_previo ?>">
                </div>
            </div>
            <div class="col">
                <?php 
                //grado academico del posgrado
                //En php y haces una consulta en la tabla de concentrados
                $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                $res = mysqli_query($conexion, $sql);
                
                //se hizo en php por que en html da errores
                echo '<div class="form-group">';
                echo '<label for="estadoposgrado" class="col-form-label">Estado Actual del Posgrado</label>';
                echo '<select name="estadoposgrado" id="estadoposgrado" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                //no mover lo de arriba, unicamente cambiar el nombre de las variables
                
                while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                    $estado_posgrado = $row['estado_posgrado'];//se obtiene el dato de la tabla concentradoacademico
                    if(!$estado_posgrado==""){//que en caso de editar, no muestre los valores nulos
                        // Verificar si el valor actual coincide con el valor previo
                        $selected = ($estado_posgrado == $estadoposgrado_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                        //si coinciden, se deja seleccionado, sino evalua el otro
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo "<option value=\"$estado_posgrado\" $selected>$estado_posgrado</option>";
                    }
                }
                echo '</select>';
                echo '</div>';
                ?> 
            </div>
        </div>

        <div class="row">
            <div class="col">
            <?php 
                //grado academico del posgrado
                //En php y haces una consulta en la tabla de concentrados
                $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                $res = mysqli_query($conexion, $sql);
                
                //se hizo en php por que en html da errores
                echo '<div class="form-group">';
                echo '<label for="orientacion" class="col-form-label">Orientacion del posgrado</label>';
                echo '<select name="orientacion" id="orientacion" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                //no mover lo de arriba, unicamente cambiar el nombre de las variables
                
                while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                    $orientacion = $row['orientacion'];//se obtiene el dato de la tabla generalposgradoconcentrado
                    if(!$orientacion==""){//que en caso de editar, no muestre los valores nulos
                        // Verificar si el valor actual coincide con el valor previo
                        $selected = ($orientacion == $orientacion_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                        //si coinciden, se deja seleccionado, sino evalua el otro
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo "<option value=\"$orientacion\" $selected>$orientacion</option>";
                    }
                }
                echo '</select>';
                echo '</div>';
                ?> 
            </div>

            <div class="col">
                <?php 
                //grado academico del posgrado
                //En php y haces una consulta en la tabla de concentrados
                $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                $res = mysqli_query($conexion, $sql);
                
                //se hizo en php por que en html da errores
                echo '<div class="form-group">';
                echo '<label for="areaEstudio" class="col-form-label">Área de estudio(áreas SNI)</label>';
                echo '<select name="areaEstudio" id="areaEstudio" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                //no mover lo de arriba, unicamente cambiar el nombre de las variables
                
                while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                    $areaEstudio = $row['areaEstudio'];//se obtiene el dato de la tabla generalposgradoconcentrado
                    if(!$areaEstudio==""){//que en caso de editar, no muestre los valores nulos
                        // Verificar si el valor actual coincide con el valor previo
                        $selected = ($areaEstudio == $areaEstudio_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                        //si coinciden, se deja seleccionado, sino evalua el otro
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo "<option value=\"$areaEstudio\" $selected>$areaEstudio</option>";
                    }
                }
                echo '</select>';
                echo '</div>';
                ?> 
            </div>

            <div class="col">
                <?php 
                //grado academico del posgrado
                //En php y haces una consulta en la tabla de concentrados
                $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                $res = mysqli_query($conexion, $sql);
                
                //se hizo en php por que en html da errores
                echo '<div class="form-group">';
                echo '<label for="region" class="col-form-label">Region(áreas SNI)</label>';
                echo '<select name="region" id="region" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                //no mover lo de arriba, unicamente cambiar el nombre de las variables
                
                while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                    $region = $row['region'];//se obtiene el dato de la tabla generalposgradoconcentrado
                    if(!$region==""){//que en caso de editar, no muestre los valores nulos
                        // Verificar si el valor actual coincide con el valor previo
                        $selected = ($region == $region_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                        //si coinciden, se deja seleccionado, sino evalua el otro
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo "<option value=\"$region\" $selected>$region</option>";
                    }
                }
                echo '</select>';
                echo '</div>';
                ?> 
            </div>
        </div>
     
        

        <div class="row">
            <div class="col">
                <?php 
                //grado academico del posgrado
                //En php y haces una consulta en la tabla de concentrados
                $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                $res = mysqli_query($conexion, $sql);
                
                //se hizo en php por que en html da errores
                echo '<div class="form-group">';
                echo '<label for="dependencia" class="col-form-label">Dependencia</label>';
                echo '<select name="dependencia" id="dependencia" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                //no mover lo de arriba, unicamente cambiar el nombre de las variables
                
                while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                    $dependencia = $row['sedes'];//se obtiene el dato de la tabla generalposgradoconcentrado
                    if(!$dependencia==""){//que en caso de editar, no muestre los valores nulos
                        // Verificar si el valor actual coincide con el valor previo
                        $selected = ($dependencia == $dependencia_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                        //si coinciden, se deja seleccionado, sino evalua el otro
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo "<option value=\"$dependencia\" $selected>$dependencia</option>";
                    }
                }
                echo '</select>';
                echo '</div>';
                ?> 
            </div>

        </div>

        <div class="row">
        
            <div class="col">
                <div class="form-group">
                    <label for="nombreCoord" class="col-form-label">Nombre del coordinador</label>
                    <input type="text" name="nombreCoord" id="nombreCoord" class="form-control" required value="<?php echo $datos_generales['nombreCoord']; ?>">
                </div>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="apellidoPCoord" class="col-form-label">Primer Apellido del coordinador</label>
                    <input type="text" name="apellidoPCoord" id="apellidoPCoord" class="form-control" required value="<?php echo $datos_generales['apellidoPCoord']; ?>">
                </div>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="apellidoMCoord" class="col-form-label">Segundo Apellido del coordinador</label>
                    <input type="text" name="apellidoMCoord" id="apellidoMCoord" class="form-control" required value="<?php echo $datos_generales['apellidoMCoord']; ?>">
                </div>
            </div>
                <div class="col">
                <?php 
                //grado academico del coordinador
                //En php y haces una consulta en la tabla de concentrados
                $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                $res = mysqli_query($conexion, $sql);
                
                //se hizo en php por que en html da errores
                echo '<div class="form-group">';
                echo '<label for="gradoCoord" class="col-form-label">Grado de Coordinador</label>';
                echo '<select name="gradoCoord" id="gradoCoord" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                //no mover lo de arriba, unicamente cambiar el nombre de las variables
                
                while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                    $gradoCoord = $row['grado'];//se obtiene el dato de la tabla generalposgradoconcentrado
                    if(!$gradoCoord==""){//que en caso de editar, no muestre los valores nulos
                        // Verificar si el valor actual coincide con el valor previo
                        $selected = ($gradoCoord == $gradoCoord_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                        //si coinciden, se deja seleccionado, sino evalua el otro
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo "<option value=\"$gradoCoord\" $selected>$gradoCoord</option>";
                    }
                }
                echo '</select>';
                echo '</div>';
                ?> 
                </div>
            <div class="col">
            
                <div class="form-group">
                    <br><label for="">Sexo:</label><br>
                    <label for="masculino">Masculino</label>
                    <input type="radio" name="sexo" id="masculino" value="Masculino" <?php echo ($datos_generales['sexo'] === 'Masculino') ? 'checked' : ''; ?>>
                                        
                    <label for="femenino">Femenino</label>
                    <input type="radio" name="sexo" id="femenino" value="Femenino" <?php echo ($datos_generales['sexo'] === 'Femenino') ? 'checked' : ''; ?>>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label for="anioInicio" class="col-form-label">Año de inicio del coordinador</label>
                    <input type="number" name="anioInicio" id="anioInicio" class="form-control" required value="<?php echo $datos_generales['anioInicio']; ?>">
                </div>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="inicioposg" class="col-form-label">Año de inicio del posgrado</label>
                    <input type="number" name="inicioposg" id="inicioposg" class="form-control" required value="<?php echo $datos_generales['inicioposg']; ?>">
                </div>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="pagWeb" class="col-form-label">Página Web</label>
                    <input type="url" name="pagWeb" id="pagWeb" class="form-control" required value="<?php echo $datos_generales['pagWeb']; ?>">
                </div>
            </div>
        </div>

<!---------------------------------------------FIN DATOS GENERALES---------------------------------------------------------------------------------->       

<!---------------------------------------------EVALUACION---------------------------------------------------------------------------------->       
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
        <h4>Evaluación</h4> <br>
        </button>

        <div class="row">
            
                <?php
                if($instPos_previo==='otro'){
                    $otraInst_previo = $datos_evaluacion['otraInst'];
                ?>
                    <div class="col">
                        <?php 
                        
                        //se hizo en php por que en html da errores
                        echo '<div class="form-group">';
                        echo '<label for="instPos" class="col-form-label">Instancia evaluadora del posgrado</label>';
                        ?>
                        <input type="text" id="instPos" name="instPos" class="form-control" value="<?php echo $otraInst_previo; ?>">
                        <?php  
                        echo '</select>';
                        echo '</div>';
                        ?> 
                    </div>
                    
                <?php
                }
                else{
                ?>
                    <div class="col">
                        <?php 
                        $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                        $res = mysqli_query($conexion, $sql);
                        
                        //se hizo en php por que en html da errores
                        echo '<div class="form-group">';
                        echo '<label for="instPos" class="col-form-label">Instancia evaluadora del posgrado</label>';
                        echo '<select name="instPos" id="instPos" class="form-select" required>';
                        echo '<option selected disabled value="">elige una opción...</option>';
                        //no mover lo de arriba, unicamente cambiar el nombre de las variables
                        
                        while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                            $instPos = $row['instPos'];//se obtiene el dato de la tabla generalposgradoconcentrado
                            if(!$instPos==""){//que en caso de editar, no muestre los valores nulos
                                // Verificar si el valor actual coincide con el valor previo
                                $selected = ($instPos == $instPos_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                                //si coinciden, se deja seleccionado, sino evalua el otro
                            
                                // Generar la opción con el atributo selected si coincide con el valor previo
                                echo "<option value=\"$instPos\" $selected>$instPos</option>";
                            }
                        }
                        echo '</select>';
                        echo '</div>';
                        ?> 
                    </div>
                <?php }?>
            </div>
           
            <?php if($actualizacion === 'si') { ?>
                <div class="col">
                    <div class="form-group">
                        <label for="anioAct" class="col-form-label">Año de actualización</label>
                        <input type="number" id="anioAct" name="anioAct" class="form-control" placeholder="Año de actualización (4 Dígitos)" value="<?php echo $datos_evaluacion['anioAct']; ?>">
                    </div>   
                </div>    
                <?php } else { ?>
                    <div class="col">
                        <div class="form-group">
                            <label for="actualizacion" class="col-form-label">¿Tiene Actualización?</label>
                            <select name="actualizacion" id="actualizacion" class="form-select" onchange="actualizacionhcu()" required>
                                <option selected disabled value="">Elige una opción...</option>
                                <?php 
                                // Opción para "Sí"
                                echo '<option value="si">Sí</option>';
                                
                                // Opción para "No" con la condición de si es la opción actual
                                $actualizacion_si = 'no'; // Obtener el dato de la tabla concentradoacademico
                                if ($actualizacion_si == $actualizacion) {
                                    echo '<option value="no" selected>No</option>';
                                } else {
                                    echo '<option value="no">No</option>';
                                }
                                ?>
                            </select>
                            <div id="campoOtroHcu" style="display: none;">
                                <div class="row">
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="anioAct" class="col-form-label">Año de actualización</label>
                                            <input type="number" id="anioAct" name="anioAct" class="form-control" placeholder="Año de actualicación(4 Digitos)">
                                        </div>   
                                    </div>           
                                </div>
                            </div>
                        </div>
                    </div>
                <?php } ?>
    
        </div>

       

        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label for="inicioposg" class="col-form-label">Año de inicio del posgrado </label>
                    <input type="number" name="inicioposg" id="inicioposg" class="form-control" pattern="^(19|20)\d{2}$" title="Ingresa un año válido (entre 1900 y 2024)" min="1900" max="2024" placeholder="Ingresa 4 digitos" value="<?php echo $inicioposg_previo; ?>" required>
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label for="ultEva" class="col-form-label">Año de la última evaluación </label>
                    <input type="number" name="ultEva" id="ultEva" class="form-control" pattern="^(19|20)\d{2}$" title="Ingresa un año válido (entre 1900 y 2024)" min="1900" max="2024" placeholder="Ingresa 4 digitos" value="<?php echo $ultEva_previo; ?>" required>
                </div>
            </div>
        </div>
<!---------------------------------------------FIN EVALUACION---------------------------------------------------------------------------------->       
<br>
<!---------------------------------------------FICHA TECNICA---------------------------------------------------------------------------------->       

        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseTwo">
        <h4>Ficha Técnica</h4> <br>
        </button>

        <div class="row">
            <div class="col">
                <?php 
                //grado academico del posgrado
                //En php y haces una consulta en la tabla de concentrados
                $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                $res = mysqli_query($conexion, $sql);
                
                //se hizo en php por que en html da errores
                echo '<div class="form-group">';
                echo '<label for="periocidad" class="col-form-label">Periocidad</label>';
                echo '<select name="periocidad" id="periocidad" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                //no mover lo de arriba, unicamente cambiar el nombre de las variables
                
                while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                    $periocidad = $row['periocidad'];//se obtiene el dato de la tabla generalposgradoconcentrado
                    if(!$periocidad==""){//que en caso de editar, no muestre los valores nulos
                        // Verificar si el valor actual coincide con el valor previo
                        $selected = ($periocidad == $periocidad_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                        //si coinciden, se deja seleccionado, sino evalua el otro
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo "<option value=\"$periocidad\" $selected>$periocidad</option>";
                    }
                }
                echo '</select>';
                echo '</div>';
                ?> 
            </div>


            <div class="col">
                <?php 
                //grado academico del posgrado
                //En php y haces una consulta en la tabla de concentrados
                $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                $res = mysqli_query($conexion, $sql);
                
                //se hizo en php por que en html da errores
                echo '<div class="form-group">';
                echo '<label for="durPos" class="col-form-label">Duracion del Posgrado</label>';
                echo '<select name="durPos" id="durPos" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                //no mover lo de arriba, unicamente cambiar el nombre de las variables
                
                while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                    $durPos = $row['durPos'];//se obtiene el dato de la tabla generalposgradoconcentrado
                    if(!$durPos==""){//que en caso de editar, no muestre los valores nulos
                        // Verificar si el valor actual coincide con el valor previo
                        $selected = ($durPos == $durPos_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                        //si coinciden, se deja seleccionado, sino evalua el otro
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo "<option value=\"$durPos\" $selected>$durPos</option>";
                    }
                }
                echo '</select>';
                echo '</div>';
                ?> 
            </div>

            <div class="col"><!--COLUMNA 2 FILA 2-->
                <div class="form-group"><!--GRUPO DE FORMULARIO-->
                    <label for="credito" class="col-form-label">Créditos</label><!--RANGO ENTRE 45 Y 300-->
                    <input type="number" name="credito" id="credito" class="form-control" min="45" max="300" title="Ingresa entre 2 y 3 dígitos" placeholder="Ingresa los creditos(Mayor a 44 Créditos)" required value="<?php echo $credito_previo;?>">
                </div><!--FIN GRUPO DE FORMULARIO-->
            </div>><!--FIN COLUMNA 2 FILA 2-->
        </div>

<!---------------------------------------------FIN FICHA TECNICA---------------------------------------------------------------------------------->       
<br>
<!---------------------------------------------ASISTENTES---------------------------------------------------------------------------------->       
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseTwo">
        <h4>Asistente</h4> <br>
        </button>

        <div class="row"><!--FILA 1 -->

        <div class="col"><!-- COLUMNA 1 FILA 1-->
            <div class="form-group">
                <label for="nombreAsis" class="col-form-label">Nombre del Asistente</label>
                <input type="text" name="nombreAsis" id="nombreAsis" class="form-control" required placeholder="Nombre del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" value="<?php echo $nombreAsis_previo;?>">           
            </div>
        </div><!-- FIN COLUMNA 1 FILA 1-->

        <div class="col"><!-- COLUMNA 2 FILA 1-->
            <div class="form-group">
                <label for="apellidoPAsis" class="col-form-label">Primer Apellido</label>
                <input type="text" name="apellidoPAsis" id="apellidoPAsis" class="form-control" required placeholder="Apellido Paterno del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" value="<?php echo $apellidoPAsis_previo;?>">
            </div>
        </div><!-- FIN COLUMNA 2 FILA 1-->

        <div class="col"><!-- COLUMNA 3 FILA 1-->
            <div class="form-group">
                <label for="apellidoMAsis" class="col-form-label">Segundo Apellido</label>
                <input type="text" name="apellidoMAsis" id="apellidoMAsis" class="form-control" required placeholder="Apellido Materno del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" value="<?php echo $apellidoMAsis_previo;?>">
            </div>
        </div><!-- FIN COLUMNA 3 FILA 1-->

        </div><!--FIN FILA 1 -->   

        <div class="row">
            <div class="col"><!-- COLUMNA 1 FILA 2-->
                <div class="form-group">
                    <label for="correoAsis" class="col-form-label">Correo Electrónico</label>
                    <input type="email" id="correoAsis" name="correoAsis" class="form-control" required placeholder="Correo Electronico del Profesor" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" value="<?php echo $correoAsis_previo;?>">
                </div>
            </div><!-- FIN COLUMNA 1 FILA 2-->

            <div class="col"><!-- COLUMNA 2 FILA 2-->
                <div class="form-group">
                    <label for="telefonoAsis" class="col-form-label">Teléfono</label>
                    <input type="tel" name="telefonoAsis" id="telefonoAsis" class="form-control" title="Ingresa un número de teléfono de 10 dígitos" placeholder="Ingresa 10 dígitos" required value="<?php echo $telefonoAsis_previo;?>">
                </div>
            </div><!-- FIN COLUMNA 2 FILA 2-->

        </div>

        <div class="row">
           
            <?php
                if($tipoTrabajo_previo==='otro'){
                    $otroTrabajo = $datos_fichaTec['otroTrabajo'];
                ?>
                    <div class="col">
                        <?php 
                        
                        //se hizo en php por que en html da errores
                        echo '<div class="form-group">';
                        echo '<label for="tipoTrabajo" class="col-form-label">Tipo de Trabajo</label>';
                        ?>
                        <input type="text" id="tipoTrabajo" name="tipoTrabajo" class="form-control" value="<?php echo $otroTrabajo; ?>">
                        <?php  
                        echo '</select>';
                        echo '</div>';
                        ?> 
                    </div>
                    
                <?php
                }
                else{
                ?>
                    <div class="col">
                        <?php 
                        $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                        $res = mysqli_query($conexion, $sql);
                        
                        //se hizo en php por que en html da errores
                        echo '<div class="form-group">';
                        echo '<label for="tipoTrabajo" class="col-form-label">Tipo de Trabajo</label>';
                        echo '<select name="tipoTrabajo" id="tipoTrabajo" class="form-select" required>';
                        echo '<option selected disabled value="">elige una opción...</option>';
                        //no mover lo de arriba, unicamente cambiar el nombre de las variables
                        
                        while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                            $tipoTrabajo = $row['tipoTrabajo'];//se obtiene el dato de la tabla generalposgradoconcentrado
                            if(!$tipoTrabajo==""){//que en caso de editar, no muestre los valores nulos
                                // Verificar si el valor actual coincide con el valor previo
                                $selected = ($tipoTrabajo == $tipoTrabajo_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                                //si coinciden, se deja seleccionado, sino evalua el otro
                            
                                // Generar la opción con el atributo selected si coincide con el valor previo
                                echo "<option value=\"$tipoTrabajo\" $selected>$tipoTrabajo</option>";
                            }
                        }
                        echo '</select>';
                        echo '</div>';
                        ?> 
                    </div>
                <?php }?>
        </div>        
        <?php
        if($otroAsistente === 'si'){
            $nombreAsis2_previo = $datos_fichaTec['nombreAsis2'] ?? '';
            $apellidoPAsis2_previo = $datos_fichaTec['apellidoPAsis2'] ?? '';
            $apellidoMAsis2_previo = $datos_fichaTec['apellidoMAsis2'] ?? '';
            $correoAsis2_previo = $datos_fichaTec['correoAsis2'] ?? '';
            $telefonoAsis2_previo = $datos_fichaTec['telefonoAsis2'] ?? '';
            $tipoTrabajo2_previo = $datos_fichaTec['tipoTrabajo2'] ?? '';
           ?>
            <h4><br> Datos del Segundo Asistente</h4>
            <div class="row"><!--FILA 1 -->

                <div class="col"><!-- COLUMNA 1 FILA 1-->
                    <div class="form-group">
                        <label for="nombreAsis2" class="col-form-label">Nombre del Asistente</label>
                        <input type="text" name="nombreAsis2" id="nombreAsis2" class="form-control" required placeholder="Nombre del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" value="<?php echo $nombreAsis2_previo;?>">           
                    </div>
                </div><!-- FIN COLUMNA 1 FILA 1-->

                <div class="col"><!-- COLUMNA 2 FILA 1-->
                    <div class="form-group">
                        <label for="apellidoPAsis2" class="col-form-label">Primer Apellido</label>
                        <input type="text" name="apellidoPAsis2" id="apellidoPAsis2" class="form-control" required placeholder="Apellido Paterno del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" value="<?php echo $apellidoPAsis2_previo;?>">
                    </div>
                </div><!-- FIN COLUMNA 2 FILA 1-->

                <div class="col"><!-- COLUMNA 3 FILA 1-->
                    <div class="form-group">
                        <label for="apellidoMAsis2" class="col-form-label">Segundo Apellido</label>
                        <input type="text" name="apellidoMAsis2" id="apellidoMAsis2" class="form-control" required placeholder="Apellido Materno del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" value="<?php echo $apellidoMAsis2_previo;?>">
                    </div>
                </div><!-- FIN COLUMNA 3 FILA 1-->

            </div><!--FIN FILA 1 -->   

            <div class="row">
                    <div class="col"><!-- COLUMNA 1 FILA 2-->
                        <div class="form-group">
                            <label for="correoAsis2" class="col-form-label">Correo Electrónico</label>
                            <input type="email" id="correoAsis2" name="correoAsis2" class="form-control" required placeholder="Correo Electronico del Profesor" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" value="<?php echo $correoAsis2_previo;?>">
                        </div>
                    </div><!-- FIN COLUMNA 1 FILA 2-->

                    <div class="col"><!-- COLUMNA 2 FILA 2-->
                        <div class="form-group">
                            <label for="telefonoAsis2" class="col-form-label">Teléfono</label>
                            <input type="tel" name="telefonoAsis2" id="telefonoAsis2" class="form-control" title="Ingresa un número de teléfono de 10 dígitos" placeholder="Ingresa 10 dígitos" required value="<?php echo $telefonoAsis2_previo;?>">
                        </div>
                    </div><!-- FIN COLUMNA 2 FILA 2-->

                </div>

                
           <?php
        }else{
            ?>
            <br> No hay otro Asistente <br>
            <div class="row" style="text-align: center;">
                    <div class="col">
                        <div class="form-group">
                            <label for="otroAsistente" class="col-form-label">¿Agregar otro Asistente?</label>
                            <select name="otroAsistente" id="otroAsistente" class="form-select" onchange="mostrarOtroAsistente()" required>
                                <option selected disabled value="">Elige una opción...</option>
                                <?php 
                                // Opción para "Sí"
                                echo '<option value="si">Sí</option>';
                                
                                // Opción para "No" con la condición de si es la opción actual
                                $actualizacion_si = 'no'; // Obtener el dato de la tabla concentradoacademico
                                if ($actualizacion_si == $otroAsistente) {
                                    echo '<option value="no" selected>No</option>';
                                } else {
                                    echo '<option value="no">No</option>';
                                }
                                ?>
                            </select>
                            <!--
                                En caso de que se dio en select "otro", se hace funcion script para mostrar el campo para escribir el otro trabajp
                                *Los script se encuentran al final(hasta abajo) de este archivo para ver su funcion*
                            -->
                                <div id="campoOtroAsistente" style="display: none;">
                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="nombreAsis2" class="col-form-label">Ingresa el nombre del Segundo Asistente:</label>
                                                <input type="text" id="nombreAsis2" name="nombreAsis2" class="form-control" placeholder="Nombre del Segundo Asistente">
                                            </div>   
                                        </div>                                                         
                                        
                                        <div class="col"><!-- COLUMNA 2 FILA 1-->
                                            <div class="form-group">
                                                <label for="apellidoPAsis2" class="col-form-label">Primer pellido</label>
                                                <input type="text" name="apellidoPAsis2" id="apellidoPAsis2" class="form-control" placeholder="Apellido Paterno del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                            </div>
                                        </div><!-- FIN COLUMNA 2 FILA 1-->

                                        <div class="col"><!-- COLUMNA 3 FILA 1-->
                                            <div class="form-group">
                                                <label for="apellidoMAsis2" class="col-form-label">Segundo Apellido</label>
                                                <input type="text" name="apellidoMAsis2" id="apellidoMAsis2" class="form-control" placeholder="Apellido Materno del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                            </div>
                                        </div><!-- FIN COLUMNA 3 FILA 1-->
                                    </div>

                                    <div class="row">
                                        <div class="col"><!-- COLUMNA 1 FILA 2-->
                                            <div class="form-group">
                                                <label for="correoAsis2" class="col-form-label">Correo Electrónico</label>
                                                <input type="email" id="correoAsis2" name="correoAsis2" class="form-control" placeholder="Correo Electronico del Prosgrado" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}">
                                            </div>
                                        </div><!-- FIN COLUMNA 1 FILA 2-->

                                        <div class="col"><!-- COLUMNA 2 FILA 2-->
                                            <div class="form-group">
                                                <label for="telefonoAsis2" class="col-form-label">Teléfono</label>
                                                <input type="tel" name="telefonoAsis2" id="telefonoAsis2" class="form-control" title="Ingresa un número de teléfono de 10 dígitos" placeholder="Ingresa 10 dígitos">
                                            </div>
                                        </div><!-- FIN COLUMNA 2 FILA 2-->

                                    </div>
                                </div>                                        
                        </div><!--FIN DEL GRUPO DE FORMULARIO-->
                    </div><!-- FIN COLUMNA 3 FILA 2-->
            </div>
            <?php
        }
        ?>
        
        

                       
    </div>

    <div class="modal-footer">
    <a href="../principales/generalesPosgrados.php"> 
        <button type="button" class="btn btn-secondary" data-bs-toggle="modal">Cerrar</button>
      </a>
        <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
  </form>

</div>
<!---fin ventana Update --->

<script src="../js/evaluarPosgrado.js"></script>