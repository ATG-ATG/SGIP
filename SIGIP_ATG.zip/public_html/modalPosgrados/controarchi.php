<?php


// include_once 'includes/php-pagination-class.php';
//session_start ();
//session_cache_expire(1);
//$_SESSION ['archivo'] = "dictamen.php";
//if (empty($_SESSION['login'])) {
//		header( 'Location: login.php' );
//		die;
//}
//$nom= $_SESSION['nombre'];
//$num = $_SESSION['user'];
//$userid = $_SESSION['userid'];
//$usernivel =  $_SESSION['nivel'];
include_once '../dao/daoexpeposgrado.php';
$accion='';
if (!isset($_POST['accion'])){
    $accion=$_POST['accion'];
    exit();
}

$accion = $_POST['accion'];

if (!isset($_POST['idposgrado'])){
    print "Error: No se envio ID posgrado";
    exit();
}

$idposgrado = $_POST['idposgrado'];

$expe = new Expediente();
switch ($accion){
    case 'Listar' :
        $filtro =$_POST['filtro'];
        
        {
            if ($filtro == ''){
            print "no se envió ID posgrado";
            }
                
        // $paginacion = new pagination();
        $expediente = $expe->obtenerExpediente($filtro);
        // $pagina_actual = 1;
        $num_regs = mysqli_num_rows($expediente);  // Total de registros
        // $regs_por_pagina = 10;
        // $datos_paginacion = $paginacion->calculate_pages($num_regs,$regs_por_pagina, $pagina_actual);
        print "<h2> Expediente Digital </h2>";
        // print '<input class="form-control" id="busca" type="text" placeholder="palabra de busqueda.." onkeyup="buscarDatos()">';
        //print '<button id="buscar" type="button" class="btn btn-success" onclick="buscarUsuarios()"><span class="glyphicon glyphicon-plus"></span>Buscar usuario</button>';
        print '<p align="left"> <button id="adduser" type="button" class="btn btn-success" onclick="mostrarModal()"><span class="glyphicon glyphicon-plus"></span>Agregar archivo digital</button>';
	print '&nbsp; &nbsp; <a href="expediente.php"'. ' class="btn btn-info btn-lg"';
        print '><span class="glyphicon glyphicon-refresh"></span>&nbsp Refrescar</a></p>';
        print "<table class=\"table table-bordered table-striped\">";
	print '<tr> <th> Tipo de documento </th> <th> Descripcion </th> <th> Nombre de archivo </th> <th> Tama&ntilde;o</th> <th style="text-align:center;"> Acciones </th> </tr>';
	while ($regis=mysqli_fetch_array($expediente, MYSQLI_ASSOC))
	{
                $tabla = "<tr> <td>". $TipoDocum[$regis['tipoexpe']];
                $tabla .= "</td> <td>". $regis['descriexpe'];
                $tabla .= " </td> <td>".$regis['archiexpe'];
                $tabla .= " </td> <td>". $regis['tamaexpe'];
                $tabla .= '</td> <td>';
                $tabla .= '&nbsp; <button id="eliminaruser" type="button" class="btn btn-danger" onclick="mostrarModalEliminar(this)"';
                $tabla .= ' data-idexpe="'. $regis['idexpe'].'" ';
                $tabla .= ' data-noemplexpe="'. $regis['noemplexpe'].'" ';
                $tabla .= ' data-tipoexpe="'. $TipoDocum[$regis['tipoexpe']].'" ';
                $tabla .= ' data-descriexpe="'. $regis['descriexpe'].'" ';
                $tabla .= ' data-archiexpe="'. $regis['archiexpe'].'" ';
                 $tabla .= ' data-tmimeexpe="'. $regis['tmimeexpe'].'" ';
                $tabla .= '><span class="glyphicon glyphicon-trash"></span>Eliminar</button>';
                
                $tabla .= '&nbsp; <a href="'.'uploads/'.$regis['archiexpe'].'"'. ' class="btn btn-success" target="_blank"';
                $tabla .= '><span class="glyphicon glyphicon-picture"></span>&nbsp Mostrar</a></td></tr>';
                //$tabla.='<button id="edituser"  type="button" class="btn btn-info" onclick="editarUsuario()"> Editar</button>';
                //$tabla .= '&nbsp; <button id="btnelimina" type="button" class="btn btn-danger"  onclick="eliminarUsuario(this)"> Borrar</button> ';
		print $tabla;
	}
	print "</table>";
       /*
        print '<div class="container">
                <br>
                <nav>
                    <ul class="pagination pagination-lg">
                        <li class="disabled"><a href="#">&laquo;</a></li>
                        <li class="active"><a href="#">'. $datos_paginacion["info"].'</a></li>
                        <li ><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">'. $datos_paginacion["last"].'</a></li>
                        <li><a href="#">&raquo;</a></li>
                    </ul>
                </nav>
        </div>';
        
        */
        break;
    }
    case 'Insertar': {
        //  ***   Codigo para guardar archivo
        $target_dir = "filesposgrado/";
        $carpeta=$target_dir;
        if (!file_exists($carpeta)) {
            mkdir($carpeta, 0777, true);
        }
        $target_file = $carpeta . $idposgrado.'_'. basename($_FILES['archivo']['name']);
        $archiExpe = $idposgrado.'_'.$_FILES['archivo']['name'];
        $tamaExpe = $_FILES['archivo']['size'];
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        // Check if image file is a actual image or fake image
        /*
        $check = getimagesize($_FILES["archivo"]["tmp_name"]);
        if($check !== false) {
            $messages[]= "OK: El archivo es una imagen - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            $errors[]= "Error: El archivo no es una imagen.";
            $uploadOk = 0;
        }
   
         */
        // Check if file already exists
        if (file_exists($target_file)) {
            $errors[]="Error: El archivo ya existe.";
            $uploadOk = 0;
        }
		
		if ($tamaExpe ==0){
			$errors[]="Error: el archivo es demasiado grande.  Tama&ntilde;o m&aacute;ximo admitido: 1.2 MB";
            $uploadOk = 0;
		}
        // Check file size //se obtiene la cant 3MB * 1048576 bytes
        if ($_FILES["archivo"]["size"] > 3145728) {
            $errors[]= "Error: el archivo es demasiado grande. Tama&ntilde;o m&aacute;ximo admitido: 3 MB";
            $uploadOk = 0;
        }
        // Allow certain file formats
        if($imageFileType != "pdf" ) {
            $errors[]= "Error: S&oacute;lo archivos PDF son permitidos.";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        
        if ($uploadOk == 0) {
            $errors[]= "Error: ocurri&oacute; un problema.";
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES['archivo']['tmp_name'], $target_file)) {
                $messages[]= "OK: El Archivo se guardo correctamente.";
               $uploadOk =1;

            } else {
               $errors[]= "Error: no se pudo guardar el archivo.";
            }
        }
        //   *******

        if ($uploadOk == 0) {
            if (isset($errors)){           
                foreach ($errors as $error){
                        print '<p class="alert alert-danger">'.$error. '</p>';
                }            
            }
            exit();
        }
        
        $guardaDatosOk = 0;
        
        $insertaOK = $expe->insertarExpediente($idposgrado, $archiExpe);
        
        if ($insertaOK == 'OK'){
             $messages[] = 'OK: Los datos del archivo se guardaron correctamente en BD';
             $guardaDatosOk = 1;
        }
        else {
            $errors[] = $insertaOK;
            $guardaDatosOk = 0;
            unlink("$target_file");
        }
        
                
        if (isset($messages)){
            foreach ($messages as $msg){
		  print '<p class="alert alert-success">'.$msg.'</p>';
            }
        }
        break;
    }
    case 'Borrar': {
        
         $idExpe =$_POST['id'];
         $Archivo = $_POST['eliminaarchi'];
         if (empty($Archivo)){
             print 'Error: No se proporcion&oacute; un nombre de archivo';
             exit();
         }
         if ($idExpe<1){
             print "Error: Id de expediente no valido";
             exit;
         }
        $StatusBorra =1; 
        if (!file_exists('filesposgrado/'.$Archivo)) {
            $StatusBorra = 0;
            $errors[] = 'Archivo: '.'filesposgrado/'.$Archivo.' a borrar no existe';  
        } 
        else {
            if (!unlink("filesposgrado/$Archivo")){
                $StatusBorra = 0;
                $errors[] = 'Ocurri&oacute; un error al intentar borrar archivo';  
              }
              else {
                  $messages [] = 'OK: El archivo se borr&oacute; con exito';
              }
        
        }     
        $BorraBDStatus =0;      
        if ($StatusBorra == 0)  {  
            if (isset($errors)){           
                foreach ($errors as $error){
                        echo"<p>$error</p>";
                }            
            }
            exit();
        }
        $BorraBDStatus = $expe->borrarExpediente($idExpe);
        $OkBD = 1;
        if ($BorraBDStatus == 'OK'){
            $messages[] = 'OK: Los datos del archivo se borraron correctamente en BD';
        }
        else {
            print $BorraBDStatus;     
            $OkBD =0;
        }
        if ($StatusBorra ==1 && $OkBD){
            print "OK";
        }
        
        break;
    }
    
    
}        