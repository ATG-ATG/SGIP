<?php
if (isset($_GET['archivo'])) {
    $archivo=$_GET['archivo'];
}
else {
    print "no se envio el nombre del archivo";
}
if (isset($_GET['idexpe'])) {
    $idexpe=$_GET['idexpe'];
}
else {
    print "no se envio ID expe";
}
print ("valores: " .$archivo.'-'.$idexpe);
?>