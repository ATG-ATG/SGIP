
<?php 
include('../conexion/conexion.php');//contiene configuraciones relacionadas con la conexión a una base de datos
//lo cual esta en un archivo llamado "config.php" en la carpeta 'conexion'
?>


<!--ventana para Agregar--->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">
                    Datos del Posgrado
                </h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <form method="POST" action="../crudPosgrado/insertar.php" enctype="multipart/form-data"> <!--Se usa un solo formulario para globalizar todos los acordeones-->
                <div class="accordion" id="accordionExample"><!----ACORDEON---->
                                <!--Acordeon para los datos personales-->
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Datos Generales
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                            <div class="accordion-body">   
                                <div class="modal-body" id="cont_modal">

                                    <div class="row">

                                        <div class="col">
                                            <div class="form-group"><!--'nombre'-->
                                                <label for="nombre" class="col-form-label">Nombre del posgrado</label>
                                                <input type="text" name="nombre" id="nombre" class="form-control" required placeholder="Nombre del Posgrado" pattern="[A-Za-z0-9ÁÉÍÓÚáéíóúÑñ\s\-,:]+" title="Solo se permiten letras">                                                        
                                            </div>
                                        </div>

                                        <div class="col">
                                            <div class="form-group"><!--'numSPN'-->
                                                <label for="numSPN" class="col-form-label">Numero de registro SNP</label>
                                                <input type="number" name="numSPN" id="numSPN" class="form-control" pattern="\d{6}" min="000000" max="999999" title="Ingresa 6 dígitos" placeholder="Ingresa 6 digitos" required>
                                            </div>        
                                        </div>

                                        <div class="col">
                                            <div class="form-group"><!--'numREG'-->
                                                <label for="numREG" class="col-form-label">Numero de registro en Profesiones</label>
                                                <input type="number" name="numREG" id="numREG" class="form-control" pattern="\d{6}" min="000000" max="999999" title="Ingresa 6 dígitos" placeholder="Ingresa 6 digitos" required>
                                            </div>        
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="correo" class="col-form-label">Correo Electrónico</label>
                                                <input type="email" id="correo" name="correo" class="form-control" required placeholder="Correo Electrónico del Posgrado" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}">
                                            </div>
                                        </div>

                                        <div class="col">
                                            <div class="form-group">
                                                <label for="telefono" class="col-form-label">Teléfono</label>
                                                <input type="tel" name="telefono" id="telefono" class="form-control" title="Ingresa un número de teléfono a 10 dígitos" placeholder="Ingresa 10 dígitos" required>
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="extension" class="col-form-label">Extensión</label>
                                                <input type="number" name="extension" id="extension" class="form-control" pattern="\d{4}" min="0000" max="9999" title="Ingresa un número de extension de 4 digitos" placeholder="Ingresa 4 dígitos">
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="estadoposgrado" class="col-form-label">Estado actual del posgrado</label>
                                                <select name="estadoposgrado" id="estadoposgrado" class="form-select" required>
                                                    <option selected disabled value="">elige una opción...</option>
                                                    <?php
                                                    $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                    $res = mysqli_query($conexion, $sql);
                                                    while ($row = mysqli_fetch_array($res)) {
                                                        $estado_posgrado = $row['estado_posgrado'];
                                                        if(!$estado_posgrado==""){ //esto ayuda para que en caso de que en la base de datos este algun dato abajo vacio o null
                                                        //no se muestren en los select
                                                    ?>
                                                            <option value="<?php echo $estado_posgrado; ?>"><?php echo $estado_posgrado; ?></option>

                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group"><!--'grado'-->
                                            <label for="grado" class="col-form-label">Grado de Estudio</label>
                                                <select name="grado" id="grado" class="form-select" onchange="gradoMedico()" required>
                                                    <option selected disabled value="">elige una opción...</option>
                                                    <option value="especialidad médica">Especialidad Médica</option>
                                                    <?php
                                                    $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                    $res = mysqli_query($conexion, $sql);

                                                    while ($row = mysqli_fetch_array($res)) {
                                                        $grado = $row['grado'];
                                                        if(!$grado=="" && $grado!="Especialidad Médica"){ //esto ayuda para que en caso de que en la base de datos este algun dato abajo vacio o null
                                                        //no se muestren en los select
                                                    ?>
                                                            <option value="<?php echo $grado; ?>"><?php echo $grado; ?></option>

                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                                <div id="campoMedico" style="display: none;">
                                                    <div class="form-group">
                                                        <label for="sedeMedico" class="col-form-label">Sede Médico</label>
                                                        <select name="sedeMedico" id="sedeMedico" class="form-select">
                                                        <option selected disabled value="">elige una opción...</option>
                                                        <?php
                                                            $sql = "SELECT * FROM `sedeshospital`";
                                                            $res = mysqli_query($conexion, $sql);
                                                            while ($row = mysqli_fetch_array($res)) {
                                                                $sedes = $row['sede'];
                                                                if(!$sedes==""){
                                                            ?>
                                                                <option value="<?php echo $sedes; ?>"><?php echo $sedes; ?></option>
                                                            <?php
                                                                }

                                                                
                                                            }
                                                            ?>
                                                        </select>
                                                    </div>   
                                                </div>   
                                            </div>
                                        </div>

                                        <div class="col">
                                            <div class="form-group"><!--'orientacion'-->
                                                <label for="orientacion" class="col-form-label">Orientación del Posgrado</label>
                                                <select name="orientacion" id="orientacion" class="form-select" required>
                                                    <option selected disabled value="">elige una opción...</option>
                                                    <?php
                                                    $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                    $res = mysqli_query($conexion, $sql);
                                                    while ($row = mysqli_fetch_array($res)) {
                                                        $orientacion = $row['orientacion'];
                                                        if(!$orientacion==""){ //esto ayuda para que en caso de que en la base de datos este algun dato abajo vacio o null
                                                        //no se muestren en los select
                                                    ?>
                                                            <option value="<?php echo $orientacion; ?>"><?php echo $orientacion; ?></option>

                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                            
                                    <div class="row">

                                        <div class="col">
                                            <div class="form-group"><!--'areaEstudio'-->
                                                <label for="areaEstudio" class="col-form-label">Área de estudio(áreas SNI)</label>
                                                <select name="areaEstudio" id="areaEstudio" class="form-select" required>
                                                    <option selected disabled value="">elige una opción...</option>

                                                    <?php
                                                    $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                    $res = mysqli_query($conexion, $sql);

                                                    while ($row = mysqli_fetch_array($res)) {
                                                        $areaEstudio = $row['areaEstudio'];
                                                        if(!$areaEstudio==""){ //esto ayuda para que en caso de que en la base de datos este algun dato abajo vacio o null
                                                        //no se muestren en los select
                                                    ?>
                                                            <option value="<?php echo $areaEstudio; ?>"><?php echo $areaEstudio; ?></option>

                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>                                                 
                                        </div>

                                        <div class="col">
                                            <div class="form-group"><!--'region'-->
                                                <label for="region" class="col-form-label">Región</label>
                                                <select name="region" id="region" class="form-select" required>
                                                    <option selected disabled value="">elige una opción...</option>
                                                    <?php
                                                    $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                    $res = mysqli_query($conexion, $sql);                                                            
    
                                                    while ($row = mysqli_fetch_array($res)) {
                                                        $region = $row['region'];
                                                        if(!$region==""){ //esto ayuda para que en caso de que en la base de datos este algun dato abajo vacio o null
                                                        //no se muestren en los select
                                                    ?>
                                                        <option value="<?php echo $region; ?>"><?php echo $region; ?></option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>


                                    <div class="row">        
                                        <div class="col">
                                            <div class="form-group"><!--'dependencia'-->
                                                <label for="dependencia" class="col-form-label">Sede</label>
                                                <select name="dependencia" id="dependencia" class="form-select" required>
                                                    <option selected disabled value="">elige una opción...</option>
                                                    <?php
                                                    $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                    $res = mysqli_query($conexion, $sql);
                                                    
                                                    while ($row = mysqli_fetch_array($res)) {
                                                        $dependencia = $row['sedes'];
                                                        if(!$dependencia==""){ //esto ayuda para que en caso de que en la base de datos este algun dato abajo vacio o null
                                                        //no se muestren en los select
                                                    ?>
                                                            <option value="<?php echo $dependencia; ?>"><?php echo $dependencia; ?></option>
                                                    <?php
                                                        }
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="nombreCoord" class="col-form-label">Nombre del Coordinador</label>
                                                <input type="text" name="nombreCoord" id="nombreCoord" class="form-control" required placeholder="Nombre del Coordinador del Posgrado" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s\.]+" title="Solo se permiten letras">
                                                
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="apellidoPCoord" class="col-form-label">Primer Apellido</label>
                                                <input type="text" name="apellidoPCoord" id="apellidoPCoord" class="form-control" required placeholder="Apellido Paterno del Coordinador" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                            </div>
                                        </div>
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="apellidoMCoord" class="col-form-label">Segundo Apellido</label>
                                                <input type="text" name="apellidoMCoord" id="apellidoMCoord" class="form-control" required placeholder="Apellido Materno del Coordinador" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group"><!--'grado del coordinador'-->
                                                <label for="gradoCoord" class="col-form-label">Grado del Coordinador</label>
                                                    <select name="gradoCoord" id="gradoCoord" class="form-select" required>
                                                        <option selected disabled value="">elige una opción...</option>
                                                        <?php
                                                        $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                        $res = mysqli_query($conexion, $sql);
                                                        
                                                        while ($row = mysqli_fetch_array($res)) {
                                                            $gradoCoord = $row['grado'];
                                                            if(!$gradoCoord==""){ //esto ayuda para que en caso de que en la base de datos este algun dato abajo vacio o null
                                                            //no se muestren en los select
                                                        ?>
                                                                <option value="<?php echo $gradoCoord; ?>"><?php echo $gradoCoord; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                            </div>
                                                    
                                        </div>
                                        <div class="col">
                                            <br>
                                            <label for="sexo">Sexo:</label><br>
                                            <label for="masculino">Masculino</label>
                                            <input type="radio" name="sexo" id="masculino" value="Masculino">
                                
                                            <label for="femenino">Femenino</label>
                                            <input type="radio" name="sexo" id="femenino" value="Femenino">
                                        </div>

                                        <div class="col">
                                            <div class="form-group">
                                                <label for="anioInicio" class="col-form-label">Año de inicio de la coordinación</label>
                                                <input type="number" name="anioInicio" id="anioInicio" class="form-control" pattern="^(19|20)\d{2}$" title="Ingresa un año válido (entre 1900 y 2024)" min="1900" max="2024" placeholder="Ingresa 4 digitos" required>
                                            </div>        
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <label for="pagWeb" class="col-form-label">Página Web del posgrado</label>
                                                <input type="url" name="pagWeb" id="pagWeb" required class="form-control" pattern="https?://.+" placeholder="Ejemplo: https://example.com">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
<!---------------------------------FIN PRIMER ACORDEON(DATOS GENERALES)----------------------------------------------------------------------------------------------->

<!---------------------------------------------------SEGUNDO ACORDEON(EVALUACION)----------------------------------------------------------------------------------------------->
<!--ESTE ACORDEON PIDE UNICAMENTE 3 DATOS
1.- Instancia evaluadora del posgrado
2.- Año de la última evaluación 
3.- Núcleo Académico
-->
                    <div class="accordion-item"><!------BOOTSTRAP DEL ACORDEON 2 -------------->
                        <h1 class="accordion-header" id="headingTwo"><!---TITULO--->
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                Evaluación 
                            </button>
                        </h1>

                        <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExample"><!---------collapseTwo-------->
                            <div class="accordion-body"><!---------accordionBody-------->
                                <div class="row"><!--FILA 1-->

                                    <div class="col"><!--COLUMNA 1 FILA 1-->
                                        <div class="form-group">
                                            <label for="instPos" class="col-form-label">Instancia evaluadora del posgrado</label>
                                            <select name="instPos" id="instPos" class="form-select" onchange="mostrarOtraInst()" required>
                                                <option selected disabled value="">elige una opción...</option>
                                                <option value="SNP(PNPC)">SNP(PNPC)</option>
                                                <option value="SEIP-UAgro">SEIP-UAgro</option>
                                                <option value="CIFRHS">CIFRHS</option>
                                                <option value="otro">Otro</option>
                                            </select>
                                            <div class="col">
                                                <div id="campoSnp" style="display: none;">   
                                                </div> 
                                                <div id="campoSeip" style="display: none;">
                                                </div>
                                                <div id="campoCifrhs" style="display: none;">
                                                </div> 
                                                <div id="campoOtraInst" style="display: none;">
                                                    <div class="col">
                                                        <label for="otraInst">Ingresa la Instancia:</label>
                                                        <input type="text" id="otraInst" name="otraInst" placeholder="Nombre de la Instancia">
                                                    </div>
                                                    
                                                </div>  

                                            </div><!--FIN COLUMNA 1 FILA 1-->                                                                       
                                        </div>

                                    </div>

                                    <!--<div class="col">
                                        div class="form-group">
                                            <label for="doc" class="col-form-label">Documento HCU</label>
                                            <input type="file" name="doc" id="doc" class="form-control" required>
                                        </div>
                                    </div>-->

                                    <div class="col">
                                        <div class="form-group"><!--GRUPO DE FORMULARIO-->
                                            <label for="actualizacion" class="col-form-label">¿Tiene Actualización?</label>
                                            <select name="actualizacion" id="actualizacion" class="form-select" onchange="actualizacionhcu()" required>
                                                <option selected disabled value="">elige una opción...</option><!--Opcion previa, que despues de dar click, no se puede elegir nuevamente-->
                                                <option value="no">No</option>
                                                <option value="si">Si</option>
                                            </select>  
                                            <div id="campoOtroHcu" style="display: none;">
                                                <div class="row">
                                                    <div class="col">
                                                        <div class="form-group">
                                                            <label for="anioAct" class="col-form-label">Año de actualización</label>
                                                            <input type="number" id="anioAct" name="anioAct" class="form-control" placeholder="Año de actualicación(4 Digitos)">
                                                        </div>   
                                                    </div>           
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div><!--FIN FILA 1-->
                                <!---------------------------------------------------------------------------------->
                                <div class="row"><!--FILA 2-->
                                    <div class="col"><!--COLUMNA 1 FILA 2-->
                                        <div class="form-group">
                                            <label for="inicioposg" class="col-form-label">Año de inicio del posgrado </label>
                                            <input type="number" name="inicioposg" id="inicioposg" required class="form-control" min="1900-01-01" max="2024-12-31">
                                        </div>
                                    </div><!--FIN COLUMNA 1 FILA 2-->

                                    <div class="col"><!--COLUMNA 1 FILA 2-->
                                        <div class="form-group">
                                            <label for="ultEva" class="col-form-label">Año de la última evaluación </label>
                                            <input type="number" name="ultEva" id="ultEva" required class="form-control" min="1900-01-01" max="2024-12-31">
                                        </div>
                                    </div><!--FIN COLUMNA 1 FILA 2-->

                                    <div class="col"><!--COLUMNA 1 FILA 2-->
                                        <!--<div class="form-group">
                                            <label for="nucleoAcademico" class="col-form-label">Núcleo Académico</label>
                                            <input type="file" name="nucleoAcademico" id="nucleoAcademico" class="form-control" required>
                                        </div>-->
                                    </div>

                                </div><!--FIN FILA 2-->

                            </div><!---------FIN accordionBody-------->
                        </div><!---------collapseTwo-------->
                    </div><!------FIN BOOTSTRAP DEL ACORDEON 2-------------->
<!---------------------------------------------------FIN SEGUNDO ACORDEON(EVALUACION)----------------------------------------------------------------------------------------------->

<!---------------------------------------------------TERCER ACORDEON(FICHA TECNICA)----------------------------------------------------------------------------------------------->
                    <div class="accordion-item"><!------BOOTSTRAP DEL ACORDEON 3-------------->
                        <h1 class="accordion-header" id="headingThree"><!---TITULO--->
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                Ficha Técnica
                            </button>
                        </h1><!-------------------------------FIN TITULO------------->

                        <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample"><!--collapseThree-->
                            <div class="accordion-body"><!---------accordionBody-------->

                                <div class="row"><!--FILA 1-->
                            <!--FIN COLUMNA 1 FILA 1-->

                                    <!--<div class="col"> //ARCHIVO NUEVO FICHA TECNICA
                                        <div class="form-group">
                                            <label for="docft" class="col-form-label">Ficha Técnica</label>
                                            <input type="file" name="docft" id="docft" class="form-control" required>
                                        </div>
                                    </div> fin ft-->

                                </div><!--FIN FILA 1-->
                            <!----------------------------------------------------------------------------------------------------------->
                                <div class="row"><!--FILA 2-->        <div class="col"><!--COLUMNA 1 FILA 1-->
                                        <div class="form-group"><!--GRUPO DE FORMULARIO-->
                                            <label for="periocidad" class="col-form-label">Periodicidad</label>
                                            <select name="periocidad" id="periocidad" class="form-select" required>
                                                <option selected disabled value="">elige una opción...</option>

                                                <?php
                                                                    
                                                $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                $res = mysqli_query($conexion, $sql);

                                                while ($row = mysqli_fetch_array($res)) {
                                                    $periocidad = $row['periocidad'];
                                                    if(!$periocidad==""){
                                                ?>

                                                <option value="<?php echo $periocidad; ?>"><?php echo $periocidad; ?></option>

                                                <?php
                                                    }                
                                                }
                                                ?>
                                            </select> 
                                                                                 
                                        </div><!--FIN DEL GRUPO DE FORMULARIO-->
                                    </div>
                                    <div class="col"><!--COLUMNA 1 FILA 2-->
                                        <div class="form-group"><!--GRUPO DE FORMULARIO-->
                                            <label for="durPos" class="col-form-label">Duración del Posgrado</label>
                                            <select name="durPos" id="durPos" class="form-select" required>
                                                <option selected disabled value="">elige una opción...</option>

                                                <?php
                                                                    
                                                $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                $res = mysqli_query($conexion, $sql);

                                                while ($row = mysqli_fetch_array($res)) {
                                                    $durPos = $row['durPos'];
                                                    if(!$durPos==""){
                                                ?>

                                                <option value="<?php echo $durPos; ?>"><?php echo $durPos; ?></option>

                                                <?php
                                                    }                
                                                }
                                                ?>
                                            </select>                                      
                                        </div><!--FIN DEL GRUPO DE FORMULARIO-->
                                    </div><!--FIN COLUMNA 1 FILA 2-->
                                    <!------------------------------------->
                                    <div class="col"><!--COLUMNA 2 FILA 2-->
                                        <div class="form-group"><!--GRUPO DE FORMULARIO-->
                                            <label for="credito" class="col-form-label">Créditos</label><!--RANGO ENTRE 45 Y 400-->
                                            <input type="number" name="credito" id="credito" class="form-control" min="45" max="400" title="Ingresa entre 2 y 3 dígitos" placeholder="Ingresa los creditos(Minimo 45)" required>
                                        </div><!--FIN GRUPO DE FORMULARIO-->
                                    </div>><!--FIN COLUMNA 2 FILA 2-->
                                </div><!--FIN FILA 2-->

                            </div><!---------FIN accordionBody-------->
                        </div><!--FIN collapseThree-->
                    </div><!------FIN BOOTSTRAP DEL ACORDEON 3-------------->

<!---------------------------------------------------FIN TERCER ACORDEON(FICHA TECNICA)----------------------------------------------------------------------------------------------->

<!---------------------------------------------------CUARTO ACORDEON(ASISTENTES)----------------------------------------------------------------------------------------------->
                    <div class="accordion-item"><!------BOOTSTRAP DEL ACORDEON 4-------------->
                        <h1 class="accordion-header" id="headingFour"><!---TITULO--->
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                Asistentes
                            </button>
                        </h1><!-------------------------------FIN TITULO------------->

                        <div id="collapseFour" class="accordion-collapse collapse" data-bs-parent="#accordionExample"><!--collapseFour-->
                            <div class="accordion-body"><!---------accordionBody-------->

                                <div class="row"><!--FILA 1 -->

                                    <div class="col"><!-- COLUMNA 1 FILA 1-->
                                        <div class="form-group">
                                            <label for="nombreAsis" class="col-form-label">Nombre del Asistente</label>
                                            <input type="text" name="nombreAsis" id="nombreAsis" class="form-control" required placeholder="Nombre del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s\.]+" title="Solo se permiten letras">           
                                        </div>
                                    </div><!-- FIN COLUMNA 1 FILA 1-->

                                    <div class="col"><!-- COLUMNA 2 FILA 1-->
                                        <div class="form-group">
                                            <label for="apellidoPAsis" class="col-form-label">Primer Apellido</label>
                                            <input type="text" name="apellidoPAsis" id="apellidoPAsis" class="form-control" required placeholder="Apellido Paterno del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                        </div>
                                    </div><!-- FIN COLUMNA 2 FILA 1-->

                                    <div class="col"><!-- COLUMNA 3 FILA 1-->
                                        <div class="form-group">
                                            <label for="apellidoMAsis" class="col-form-label">Segundo Apellido</label>
                                            <input type="text" name="apellidoMAsis" id="apellidoMAsis" class="form-control" required placeholder="Apellido Materno del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                        </div>
                                    </div><!-- FIN COLUMNA 3 FILA 1-->

                                </div><!--FIN FILA 1 -->      
                                <!--------------------------------------------------------------->
                                <div class="row"><!--FILA 2 -->

                                    <div class="col"><!-- COLUMNA 1 FILA 2-->
                                        <div class="form-group">
                                            <label for="correoAsis" class="col-form-label">Correo Electrónico</label>
                                            <input type="email" id="correoAsis" name="correoAsis" class="form-control" required placeholder="Correo Electronico del Profesor" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}">
                                        </div>
                                    </div><!-- FIN COLUMNA 1 FILA 2-->

                                    <div class="col"><!-- COLUMNA 2 FILA 2-->
                                        <div class="form-group">
                                            <label for="telefonoAsis" class="col-form-label">Teléfono</label>
                                            <input type="tel" name="telefonoAsis" id="telefonoAsis" class="form-control" title="Ingresa un número de teléfono de 10 dígitos" placeholder="Ingresa 10 dígitos" required>
                                        </div>
                                    </div><!-- FIN COLUMNA 2 FILA 2-->

                                    <div class="col"><!-- COLUMNA 3 FILA 2-->
                                        <div class="form-group"><!--GRUPO DE FORMULARIO-->
                                            <label for="tipoTrabajo" class="col-form-label">Tipo de trabajo</label>
                                            <select name="tipoTrabajo" id="tipoTrabajo" class="form-select" onchange="mostrarOtroTrabajo()" required>
                                                <option selected disabled value="">elige una opción...</option><!--Opcion previa, que despues de dar click, no se puede elegir nuevamente-->

                                                <!--
                                                    Se hace una consulta en la tabla `generalposgradosconcentrado`, se guarda
                                                    Se busca el campo 'tipoTrabajo' 
                                                    tiene 3 opciones, y un campo para comentar otro trabajo
                                                -->
                                                <?php
                                                                    
                                                $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                $res = mysqli_query($conexion, $sql);

                                                while ($row = mysqli_fetch_array($res)) {
                                                    $tipoTrabajo = $row['tipoTrabajo'];
                                                    if(!$tipoTrabajo==""){
                                                ?>

                                                <option value="<?php echo $tipoTrabajo; ?>"><?php echo $tipoTrabajo; ?></option>

                                                <?php
                                                    }                
                                                }
                                                ?>
                                                <option value="otro">Otro</option>
                                            </select>  
                                            <!--
                                                En caso de que se dio en select "otro", se hace funcion script para mostrar el campo para escribir el otro trabajp
                                                *Los script se encuentran al final(hasta abajo) de este archivo para ver su funcion*
                                            -->
                                                <div id="campoOtroTrabajo" style="display: none;">
                                                    <label for="otroTrabajo">Ingresa el otro trabajoooo:</label>
                                                    <input type="text" id="otroTrabajo" name="otroTrabajo" placeholder="Nombre del Trabajo">
                                                </div>                                        
                                        </div><!--FIN DEL GRUPO DE FORMULARIO-->
                                    </div><!-- FIN COLUMNA 3 FILA 2-->

                                </div>

                                <div class="row">

                                    <div class="col"><!-- COLUMNA 3 FILA 2-->
                                        <div class="form-group"><!--GRUPO DE FORMULARIO-->
                                            <!--<label for="tipoTrabajo2" class="col-form-label">Tipo de trabaaaajo</label>
                                            <select name="tipoTrabajo2" id="tipoTrabajo2" class="form-select" onchange="mostrarOtroTrabajo()">
                                                <option selected disabled value="">elige una opción...</option><!--Opcion previa, que despues de dar click, no se puede elegir nuevamente

                                                
                                                    Se hace una consulta en la tabla `generalposgradosconcentrado`, se guarda
                                                    Se busca el campo 'tipoTrabajo' 
                                                    tiene 3 opciones, y un campo para comentar otro trabajo
                                                
                                                <?php
                                                                    
                                                $sql = "SELECT * FROM `generalposgradosconcentrado`";
                                                $res = mysqli_query($conexion, $sql);

                                                while ($row = mysqli_fetch_array($res)) {
                                                    $tipoTrabajo = $row['tipoTrabajo'];
                                                    if(!$tipoTrabajo==""){
                                                ?>

                                                <option value="<?php echo $tipoTrabajo; ?>"><?php echo $tipoTrabajo; ?></option>

                                                <?php
                                                    }                
                                                }
                                                ?>
                                                <option value="otro">Otro</option>
                                            </select> --> 
                                            <!--
                                                En caso de que se dio en select "otro", se hace funcion script para mostrar el campo para escribir el otro trabajp
                                                *Los script se encuentran al final(hasta abajo) de este archivo para ver su funcion*
                                            
                                                <div id="campoOtroTrabajo2" style="display: none;">
                                                    <label for="otroTrabajo2">Ingresa el otro trabajo:</label>
                                                    <input type="text" id="otroTrabajo2" name="otroTrabajo2" placeholder="Nombre del Trabajo">
                                                </div>   -->                                     
                                        </div>
                                    </div>
                                    <div class="col"><!-- COLUMNA 1 FILA 1-->
                                        <div class="form-group"><!--GRUPO DE FORMULARIO-->
                                            <label for="otroAsistente" class="col-form-label">¿Agregar otro Asistente?</label>
                                            <select name="otroAsistente" id="otroAsistente" class="form-select" onchange="mostrarOtroAsistente()" required>
                                                <option selected disabled value="">elige una opción...</option><!--Opcion previa, que despues de dar click, no se puede elegir nuevamente-->
                                                <option value="no">No</option>
                                                <option value="si">Si</option>
                                            </select>  
                                            <!--
                                                En caso de que se dio en select "otro", se hace funcion script para mostrar el campo para escribir el otro trabajp
                                                *Los script se encuentran al final(hasta abajo) de este archivo para ver su funcion*
                                            -->
                                                <div id="campoOtroAsistente" style="display: none;">
                                                    <div class="row">
                                                        <div class="col">
                                                            <div class="form-group">
                                                                <label for="nombreAsis2" class="col-form-label">Ingresa el nombre del Segundo Asistente:</label>
                                                                <input type="text" id="nombreAsis2" name="nombreAsis2" class="form-control" placeholder="Nombre del Segundo Asistente">
                                                            </div>   
                                                        </div>                                                         
                                                        
                                                        <div class="col"><!-- COLUMNA 2 FILA 1-->
                                                            <div class="form-group">
                                                                <label for="apellidoPAsis2" class="col-form-label">Primer pellido</label>
                                                                <input type="text" name="apellidoPAsis2" id="apellidoPAsis2" class="form-control" placeholder="Apellido Paterno del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                                            </div>
                                                        </div><!-- FIN COLUMNA 2 FILA 1-->

                                                        <div class="col"><!-- COLUMNA 3 FILA 1-->
                                                            <div class="form-group">
                                                                <label for="apellidoMAsis2" class="col-form-label">Segundo Apellido</label>
                                                                <input type="text" name="apellidoMAsis2" id="apellidoMAsis2" class="form-control" placeholder="Apellido Materno del Asistente" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras">
                                                            </div>
                                                        </div><!-- FIN COLUMNA 3 FILA 1-->
                                                    </div>

                                                    <div class="row">
                                                        <div class="col"><!-- COLUMNA 1 FILA 2-->
                                                            <div class="form-group">
                                                                <label for="correoAsis2" class="col-form-label">Correo Electrónico</label>
                                                                <input type="email" id="correoAsis2" name="correoAsis2" class="form-control" placeholder="Correo Electronico del Profesor" pattern="[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}">
                                                            </div>
                                                        </div><!-- FIN COLUMNA 1 FILA 2-->

                                                        <div class="col"><!-- COLUMNA 2 FILA 2-->
                                                            <div class="form-group">
                                                                <label for="telefonoAsis2" class="col-form-label">Teléfono</label>
                                                                <input type="tel" name="telefonoAsis2" id="telefonoAsis2" class="form-control" title="Ingresa un número de teléfono de 10 dígitos" placeholder="Ingresa 10 dígitos">
                                                            </div>
                                                        </div><!-- FIN COLUMNA 2 FILA 2-->

                                                    </div>
                                                </div>                                        
                                        </div><!--FIN DEL GRUPO DE FORMULARIO-->
                                    </div><!-- FIN COLUMNA 3 FILA 2-->
                                </div>

                            </div><!---------FIN accordionBody-------->
                        </div><!--FIN collapseFour-->


                    </div><!------FIN BOOTSTRAP DEL ACORDEON 4-------------->
                    
                    
                </div><!----ACORDEON---->
                            <div class="modal-footer"><!--BOTONES-->
                                            <button type="button" class="btn btn-secondary" data-bs-toggle="modal">Cerrar</button>
                                            <button type="submit" class="btn btn-primary">Guardar</button>
                            </div><!--FIN BOTONES-->
            </form>

        </div>
    </div>
</div>

<script src="../js/evaluarPosgrado.js"></script>