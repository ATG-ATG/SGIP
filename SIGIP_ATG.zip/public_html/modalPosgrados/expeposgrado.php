
<?php
session_cache_expire(1);
session_start ();

if (empty($_SESSION['login']))
{
    header('Location:../login.php');
    die;
}

if (isset($_GET['idposgdo'])){
    $idPosgrado = $_GET['idposgdo'];
}
else {
    print ("No se envio la clave del posgrado");
}

require_once '../conexion/conexion.php';
require_once '../dao/daoexpeposgrado.php';
$expe = new Expediente();

?>
<!DOCTTYPE html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    <!--    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" media="screen" title="no title" charset="utf-8">
        <script src="js/jquery-3.2.1.min.js" charset="utf-8"></script>
        <script src="bootstrap/js/bootstrap.min.js" charset="utf-8"></script>
    -->  
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
        <script>
            $(document).ready(function(){
               $("#usuarios").click(function(){
                   listarUsuarios();
                    
                });
            });

            function buscarDatos(){
                var Busca = $('#busca').val();
                // alert ('Buscar datos = '+ Busca);
                listarUsuarios(Busca);
            }
              
              function buscarUsuarios(){
                var Busca = $('#busca').val();  
                // alert ('Buscar usuarios'+Busca);
                listarUsuarios(Busca);
                  
              }
              
              function listarExpediente(filtro = ''){
                      //alert ('listar usuarios = '+ filtro);
                     var  Accion = 'Listar';
                     var Filtro =filtro;
                     
                    $.ajax({
                        url:'controlador.php',
                        method: "POST",
                        data: {'accion':Accion, 'filtro':Filtro},
                        cache:"false",
 
                        success:  function (respuesta) {
                            $('#datos').html(respuesta);
                            
                                // alert ('Filtro = '+Filtro);
                                $('#busca').val(Filtro);
                                $('#busca').focus();
                            
                        }
                    });
                 }
               
               $("#modalForm").on('hidden.bs.modal', function () {
                     // alert('The modal is now hidden.');
                     $('#inputTipo').val('');
                     $('#inputDescri').val('');
                     $('#inputArchivo').val('');
                     $("#modalMsg").text('');
                });
          
            
           function mostrarModal() {
               $(document).ready(function(){
                    alert ("Insertar archivo");
                    $('.statusMsg').html('');
                    $("#modalForm").modal();
               });
               
           }
/*el jqery detecte el botón
           $(document).ready(function(){
            $("#addarchivo").click(function(){
                alert("agregar archivo");
            }
            );

           }

           );*/
           
            function mostrarModalEdita(boton) {
               $(document).ready(function(){
                   // alert ("Insertar usuario");
                   var Iduser = $(boton).data('id');
                   var Nomuser = $(boton).data('nomuser');
                   var Clave   = $(boton).data('clave');
                   var Correo  = $(boton).data('correo');
                   var Tel     = $(boton).data('tel')
                   // alert (Iduser);
                    $('#editaId').val(Iduser);
                    $('#editaName').val(Nomuser);
                     $('#editaClave').val(Clave);
                     $('#editaEmail').val(Correo);
                     $('#editaTel').val(Tel);
                    $("#editaForm").modal();
               });
               
           }
           
            function mostrarModalEliminar(boton) {
                  $(document).ready(function(){
                    /*
                    $('#eliminaMsg').html('');
                   var IdExpe = $(boton).data('idexpe');
                   var NoemplExpe = $(boton).data('noemplexpe');
                   var TipoExpe   = $(boton).data('tipoexpe');
                   var DescriExpe  = $(boton).data('descriexpe');
                   var ArchiExpe    = $(boton).data('archiexpe');
                   var srcImagen  ='uploads/'+ArchiExpe;
                   // alert (Iduser);
                    $('#eliminaId').val(IdExpe);
                    $('#eliminaNoempl').val(NoemplExpe);
                     $('#eliminaTipo').val(TipoExpe);
                     $('#eliminaDescri').val(DescriExpe);idexpeposgrado */
                     //var ArchiExpe    = $(boton).data('archiexpe');
                     //var IdExpe    = $(boton).data('idexpe');
                      var Accion = "Borrar";
                      var IdExpe = $(boton).data('idexpe');
                      var IdPosgrado = $(boton).data('idposgrado');
                      var EliminaArchi = $(boton).data('archiexpe');
                      var resp = confirm("¿Desea borrar archivo: "+ EliminaArchi + " ?");
                     if (resp == true){
                        //window.location.assign("controarchi.php?eliminaarchi="+ArchiExpe+"&id="+IdExpe+"&accion=Borrar");
                                        
                   alert (IdExpe);
                        // alert ('Archivo:' + EliminaArchi) ;             
                        $.ajax({
                            type:'POST',
                            url:'controarchi.php',
                            data:{'accion':Accion, 'id':IdExpe, 'eliminaarchi': EliminaArchi, 'idposgrado': IdPosgrado},
                           
                            success:function(msg){
                                if(msg === 'OK'){
                                    alert ("el archivo se borro correctamente");
                                    window.location.assign("expeposgrado.php?idposgdo="+IdPosgrado);
                                }else{
                                    alert ("Error: "+msg);
                                   // $('#eliminaMsg').html('<span style="color:red;">Ocurrio un problema, por favor intente  otra vez.</span>');
                                }
                              }
                        });
                        
                      }
               });
               
           }
                            
           function insertarExpediente(idPosgrado){
               $(document).ready(function(){
                    alert ("ID posgrado: " +idPosgrado);
                   $('.statusMsg').html('');
                   var InputArchivo = document.getElementById("inputArchivo");
                   var file = InputArchivo.files[0];
                   var comentario = $('#inputComentario').val();
                    if (InputArchivo.files.length == 0){
                       alert ("Debe seleccionar un archivo a subir");
                       return false;
                   }
                   var patron = /^[a-zA-Z\s0-9-_.]*$/;
                   var nombreArchivo = InputArchivo.files[0].name;
				   var sizeArchivo = InputArchivo.files[0].size;
				   if (sizeArchivo > 3145728){ //checar tamano 3MB * 1048576 bytes
				   		alert('Error: El tamanio del archivo no puede ser mayor de 3 MB');
						return false;
					}	
				    // alert ('tamaño: '+ sizeArchivo);
                   if (nombreArchivo.length > 50){
                       alert ('Error: La longitud del nombre del archivo no debe exceder de 50 caracteres.');
                       return false;
                   }
                   if (!patron.test(nombreArchivo)){
                       alert('Error: El nombre de archivo solo puede tener letras, espacios y guiones');
                       return false;
                   }
                  // alert (InputArchivo);
					var datos = new FormData();
                   
                   var Accion = "Insertar";
                   //var TipoExpe = $('#inputTipo').val();
                   //var DescriExpe   = $('#inputDescri').val();
                   
                   datos.append('accion', Accion);
                   datos.append('idposgrado', idPosgrado);
                   //datos.append('tipoExpe', TipoExpe);
                   //datos.append('descriExpe', DescriExpe);
                   datos.append('archivo', file);
                   datos.append('comentario', comentario);
                    // alert ("Nombre de archivo: "+nombreArchivo);
                   /* if(TipoExpe.trim() == '' ){
                        alert('Por favor seleccione un tipo de archivo.');
                        $('#inputTipo').focus();
                        return false;
                    }else if(DescriExpe.trim() == ''){
                        alert('Por favor introduzca una descripcion.');
                        $('#inputDescri').focus();
                        return false;
                    }
                    */
									
                     // alert ("Nombre de archivo: "+nombreArchivo+", Tipo expe: "+TipoExpe+", Descrip: "+ DescriExpe);
                        $.ajax({
                           type:'POST',
                            url:'controarchi.php',
                            data:datos,
                            contentType: false,
                            cache: false, 
                            processData:false, 
                            beforeSend: function () {
                                $('.submitBtn').attr("disabled","disabled");
                                $('.modal-body').css('opacity', '.5');
                            },
                            success:function(msg){
                                //$('#inputTipo').val('');
                                //$('#inputDescri').val('');
                                $('#inputArchivo').val('');
                               // alert(msg);
                                $('.statusMsg').html(msg);
                                $('.submitBtn').removeAttr("disabled");
                                $('.modal-body').css('opacity', '');
                                
                            }
                        });
                        // listarExpediente();
                   
               });
            }
           
  
           //funcion para eliminar usuario
           
           function eliminarExpediente(){
               $(document).ready(function(){
                   
                   
                   var Accion = "Borrar";
                   var IdExpe = $('#eliminaId').val();
                   var EliminaArchi = $('#eliminaArchi').val();
                        // alert ('Archivo:' + EliminaArchi) ;             
                        $.ajax({
                            type:'POST',
                            url:'controlador.php',
                            data:{'accion':Accion, 'id':IdExpe, 'eliminaarchi': EliminaArchi},
                            beforeSend: function () {
                                $('#btneliminar').attr("disabled","disabled");
                                $('.modal-body').css('opacity', '.5');
                            },
                            success:function(msg){
                                if(msg === 'OK'){
                                    $('#eliminaId').val('');
                                    $('#eliminaNoempl').val('');
                                    $('#eliminaTipo').val('');
                                    $('#eliminaDescri').val('');
                                    $('#eliminaArchi').val('');
                                    alert ("El registro se borro con exito");
                                    $('#eliminaFormulario').modal('hide');
                                    // listarUsuarios();
                                    //$('#editarMsg').html('<span style="color:green;">El registro se actualizo con exito.</p>');
                                }else{
                                    alert ("Error: "+msg);
                                    $('#eliminaMsg').html('<span style="color:red;">Ocurrio un problema, por favor intente  otra vez.</span>');
                                }
                                $('#btneliminar').removeAttr("disabled");
                                $('.modal-body').css('opacity', '');
                            }
                        });
                        $('#eliminaMsg').html('');
               });
                  
           }
        </script>   
        <style>
            /* Set height of the grid so .sidenav can be 100% (adjust if needed) */
            .row.content {height: 1400px}

            /* Set gray background color and 100% height */
            .sidenav {
              background-color: #f1f1f1;
              height: 100%;
            }

            /* Set black background color, white text and some padding */
            footer {
              background-color: #555;
              color: white;
              padding: 15px;
            }

            /* On small screens, set height to 'auto' for sidenav and grid */
            @media screen and (max-width: 767px) {
              .sidenav {
                height: auto;
                padding: 15px;
              }
              .row.content {height: auto;} 
            }
        </style>
    </head>
    <body>

      <div class="container-fluid text-center">    
        <div class="row content">
            <div class="col-sm-2 sidenav"><br>
                <p><a id="usuarios" href="../index.php" class="btn btn-info">
                
                    <span class="glyphicon glyphicon-home "></span> Regresar al inicio
                  
                  </a>
                </p>
            
          </div>
          <div class="col-sm-8 text-left"> 
            <h1>Expediente electr&oacute;nico del posgrado</h1>
            <?php 
                $expediente = $expe->obtenerExpediente($idPosgrado);
            ?>
            
            <div align="center" id="datos">
                <?php
                    print '<button id="addarchivo" type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modalForm"><span class="glyphicon glyphicon-plus"></span>Agregar archivo digital</button> ';
                    print '&nbsp; &nbsp; <a href="expeposgrado.php?idposgdo='.$idPosgrado.'"'. ' class="btn btn-info btn-lg"';
                    print '><span class="glyphicon glyphicon-refresh"></span>&nbsp Refrescar</a></p>';
                    print "<table class=\"table table-bordered table-striped\">";
                    print '<tr> <th> ID del Posgrado </th> <th> Archivo digital </th> <th style="text-align:center;"> Acciones </th> </tr>';
                    
                    
                    while ($regisposgrado = mysqli_fetch_array($expediente,MYSQLI_ASSOC))
                    {
                    $tabla = "<tr> <td>". $regisposgrado['idposgrados'];
                    
                        $tabla .= "</td> <td>". $regisposgrado['archivo'];
                                      
                    
                    $tabla .= '</td> <td>';
                    $tabla .= '&nbsp; <button id="eliminarposgrado" type="button" class="btn btn-danger" onclick="mostrarModalEliminar(this)"';
                    //$tabla .= ' data-idexpe="'. $regis['idexpe'].'" ';
                    //$tabla .= ' data-noemplexpe="'. $regis['noemplexpe'].'" ';
                    //$tabla .= ' data-tipoexpe="'. $TipoDocum[$regis['tipoexpe']].'" ';
                    //$tabla .= ' data-descriexpe="'. $regis['descriexpe'].'" ';
                    $tabla .= ' data-archiexpe="'. $regisposgrado['archivo'].'" ';
                    $tabla .= ' data-idexpe="'. $regisposgrado['idexpeposgrado'].'" ';
                    $tabla .= ' data-idposgrado="'. $regisposgrado['idposgrados'].'" ';
                    //$tabla .= ' data-tmimeexpe="'. $regis['tmimeexpe'].'" ';
                    $tabla .= '><span class="glyphicon glyphicon-trash"></span>Eliminar</button>';

                    $tabla .= '&nbsp; <a href="'.'filesposgrado/'.$regisposgrado['archivo'].'"'. ' class="btn btn-success" target="_blank"';
                    $tabla .= '><span class="glyphicon glyphicon-picture"></span>&nbsp Mostrar</a></td></tr>';
                    //$tabla.='<button id="edituser"  type="button" class="btn btn-info" onclick="editarUsuario()"> Editar</button>';
                    //$tabla .= '&nbsp; <button id="btnelimina" type="button" class="btn btn-danger"  onclick="eliminarUsuario(this)"> Borrar</button> ';
                    print $tabla;
                    }
                    print "</table>";
					
                ?>  
					<div class="alert alert-info">
					<p><strong>Atenci&oacute;n: </strong> &nbsp; Se recomienda subir archivos en formato PDF.
					</p>
					</div>
					<!--<div class="alert alert-info" align="left">
					<p><strong>De acuerdo a la gu&iacute;a los documentos que debe subir a su expediente son: </strong> 
					</p>
					<p> 1) T&iacute;tulo del &uacute;ltimo grado (m&iacute;nimo maestr&iacute;a o especialidad.). </p>
					<p> 2) C&eacute;dula profesional del &uacute;ltimo grado. </p>
					<p> 3) Solicitud al ESDEPED firmada </p>
					<p> 4) Declaraci&oacute;n de exclusividad firmada.  </p>
					<p>  5) Convenio bilateral (becarios, a&ntilde;o sab&aacute;tico o ests. de posgrado)
					<p>6) Cerificado de un segundo idioma (en caso de tenerlo) 
					</div>-->

            </div>
            <!-- Codigo para ventana modal de altas -->
            <!-- Modal -->
            <div class="modal" id="modalForm">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Subir archivos</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <p class="statusMsg" id="modalMsg"></p>
        <form role="form">
          <div class="form-group">
            <label for="inputArchivo">Archivo digital a subirr</label>
            <input type="file" class="form-control" id="inputArchivo" accept=".pdf" />
          </div>
          <div class="form-group">
            <label for="inputComentario">Asunto o comentario</label>
            <input type="text" class="form-control" id="inputComentario" placeholder="Ingrese un asunto o comentario">
          </div>
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" onclick="insertarExpediente(<?php print $idPosgrado ?>)">Subir</button>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
      </div>

    </div>
  </div>


            <!-- Fin del codigo del modal de altas -->
            
            <!--Formulario para eliminar registros-->
<div class="modal" id="eliminaFormulario">
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Subir archivos</h4>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <p class="statusMsg" id="modalMsg"></p>
        <form role="form">
          <div class="form-group">
            <label for="inputArchivo">Archivo digital a subirr</label>
            <input type="file" class="form-control" id="inputArchivo" accept=".pdf" />
          </div>
          <div class="form-group">
            <label for="inputComentario">Asunto o comentario</label>
            <input type="text" class="form-control" id="inputComentario" placeholder="Ingrese un asunto o comentario">
          </div>
        </form>
      </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" onclick="insertarExpediente(<?php print $idPosgrado ?>)">Subir</button>
      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cerrar</button>
      </div>

    </div>
  </div>
                <!--fin modal eliminar-->
                
                <!-- Codigo para el formulario modal mostrar imagen  -->
                <div class="modal fade" id="mostrarImagen" role="dialog">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <!-- Modal Header -->
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">
                                    <span aria-hidden="true">X</span>
                                    <span class="sr-only">Close</span>
                                </button>
                                <h4 class="modal-title" id="myModalLabel">Muestra archivo digital</h4>
                            </div>

                            <!-- Modal Body -->
                            <div class="modal-body">

                                <form role="form">
                                    <div id="paraImagen">
                                        
                                    </div>
                                </form>
                            </div>

                            <!-- Modal Footer -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                            </div>
                        </div>
                    </div>
                </div>

                
                <!--fin modal mostrar -->
          </div>

        </div>
      </div>

      <footer class="container-fluid text-center">
        <p>Expediente de posgrados UAGro</p>
      </footer>


    </body>
    
</html>
