<?php 
include('../conexion/conexion.php');

$id = $_REQUEST['id'];

//codigo para obtener los valores previos del select
//grado academico
$sql = "SELECT * FROM academicosprofesor WHERE profid='" . $id . "'"; //se traeran el valor guardado en esta tabla(ir a codigo de linea: 237 )
$res = mysqli_query($conexion, $sql);
$datos = mysqli_fetch_assoc($res);
$gradoAcademico_previo = $datos['gradoAcademico'] ?? ''; // Aquí obtienes el valor previo del grado academico
$insUltimoGrado_previo = $datos['insUltimoGrado'] ?? ''; // Aquí obtienes el valor previo del	Institución de obtención del último grado
$areaEstudios_previo = $datos['areaEstudios'] ?? ''; // Aquí obtienes el valor previo del area de estudios
$sni_previo = $datos['sni'] ?? ''; // Aquí obtienes el valor previo del sni

//primero mandamos a traer los datos del select a traves de la id del profesor de datos cademicos
$sql = "SELECT * FROM academicosProfesor WHERE profid='" . $id . "'";
$anioObtGrado = $datos['anioObtGrado'] ?? '';
$cvun_previo = $datos['cvun'] ?? '';
$cvu_previo = $datos['cvu'] ?? '';
$vigenciaSNI = $datos['vigenciaSNI'] ?? '';
$urlProductividad = $datos['urlProductividad'] ?? '';
$nacionalidad2_antiguo =   $datos['nacionalidad2'] ?? '';

//consulta de los datos laborales
$sql2 = "SELECT * FROM laboralesprofesor WHERE profid='" . $id . "'"; 
$res2 = mysqli_query($conexion, $sql2);
$datos2 = mysqli_fetch_assoc($res2);
$adscripcion_previo = $datos2['adscripcion'] ?? '';
$posgrados_previo = $datos2['posgrados'] ?? '';
$tiempoPosgrado_previo = $datos2['tiempoPosgrado'] ?? '';

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <!-- boostraps -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Editar Maestro</title>

    <link rel="stylesheet" href="../css/editar.css">
</head>
<!--  -->

<?php include_once('../menu.php');?><!--INCLUIR EL MENU-->


<?php
include('../conexion/conexion.php');


$id = $_GET['id'];
$sql = "SELECT * FROM `profesores` WHERE profid='" . $id . "'";
$res = mysqli_query($conexion, $sql);
$row = mysqli_fetch_assoc($res);

$nacionalidad_antiguo =   $row['nacionalidad'] ?? '';
?>

<!--ventana para actualizar--->


<div style="width: 80%; margin: auto;">

  <form method="POST" action="../crudProfesorExterno/editar.php">
    <div class="modal-body" id="cont_modal">
        <h4>Datos Generales de: <?php echo $row['nombre']. " ". $row['apellidoPaterno']. " ". $row['apellidoMaterno'];?></h4>
        <div class="row">
            <div class="col">
            <div class="form-group">
                <input type="hidden" name="id" value="<?php echo $row['profid']; ?>">
                <label for="nombre" class="col-form-label">Nombre</label>
                <input type="text" name="nombre" id="nombre" class="form-control" required value="<?php echo $row['nombre'] ?>">
            </div>
            </div>

            <div class="col">
                <div class="form-group">
                    <label for="apellidoPaterno" class="col-form-label">Primer Apellido</label>
                    <input type="text" name="apellidoPaterno" id="apellidoPaterno" class="form-control" required value="<?php echo $row['apellidoPaterno'] ?>">
                </div>
            </div>
            <div class="col">
                <div class="form-group">
                    <label for="apellidoMaterno" class="col-form-label">Segundo Apellido</label>
                    <input type="text" name="apellidoMaterno" id="apellidoMaterno" class="form-control" required value="<?php echo $row['apellidoMaterno'] ?>">
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col">
            <div class="form-group">
                <label for="claveTrabajador" class="col-form-label">Clave de Trabajador</label>
                <input type="number" name="claveTrabajador" id="claveTrabajador" class="form-control" required value="<?php echo $row['claveTrabajador'] ?>">
            </div>
            </div>
            <div class="col">
            <div class="correo">
                <label for="correo" class="col-form-label">Correo Electrónico</label>
                <input type="email" name="correo" id="correo" class="form-control" required value="<?php echo $row['correo'] ?>">
            </div>
            </div>
            <div class="col">
            <div class="form-group">
                <label for="telefono" class="col-form-label">Teléfono</label>
                <input type="tel" name="telefono" id="telefono" class="form-control" required value="<?php echo $row['telefono'] ?>">
            </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="form-group">
                    <label for="">Sexo:</label>
                    <label for="masculino">Masculino</label>
                    <input type="radio" name="sexo" id="masculino" value="Masculino" <?php echo ($row['sexo'] === 'Masculino') ? 'checked' : ''; ?>>
                                        
                    <label for="femenino">Femenino</label>
                    <input type="radio" name="sexo" id="femenino" value="Femenino" <?php echo ($row['sexo'] === 'Femenino') ? 'checked' : ''; ?>>
                </div>
            </div>

            <div class="col">
            <label for="nacionalidad">Nacionalidad del Profesor:</label><br>
            <input type="hidden" name="nacionalidad" value="<?php echo $nacionalidad_antiguo; ?>">
            <?php
            if($nacionalidad_antiguo === 'Mexicana'){
                echo "Nacionalidad anterior: ";
                echo "<td>". $nacionalidad_antiguo . "</td><br>";
                $estado_antiguo = $row['estado'];
                echo "<th>Estado:</th>";
                // Mostrar select de estado con la opción seleccionada según el estado anterior
                echo "<select name='estado'>";
                echo "<option value=''>Seleccione un estado...</option>";
                $estados = array("Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas", "Chihuahua", "Coahuila", "Colima", "Ciudad de México", "Durango", "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "México", "Michoacán", "Morelos", "Nayarit", "Nuevo León", "Oaxaca", "Puebla", "Querétaro", "Quintana Roo", "San Luis Potosí", "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas");
                foreach ($estados as $estado) {
                    $selected = ($estado == $estado_antiguo) ? 'selected' : '';
                    echo "<option value='$estado' $selected>$estado</option>";
                }
                echo "</select>";
            } else if ($nacionalidad_antiguo === 'Extranjera') {
                echo "Nacionalidad anterior: ";
                echo "<td>". $nacionalidad_antiguo . "</td><br>";
                $pais_antiguo = $row['pais'];
                echo "<th>País:</th>";
                echo "<td>". $pais_antiguo . "</td>";
                // Mostrar select de país con la opción seleccionada según el país anterior
                echo "<select name='pais'>";
                echo "<option value=''>Seleccione un país...</option>";
                $paises = array("Alemania", "Argentina", "Belice", "Bolivia", "Brasil", 'Canadá', "Colombia", "Costa Rica", "Cuba", "Chile", "Ecuador", "El Salvador", "España", "Estados Unidos", "Guatemala", "Honduras", "Nicaragua", "Paraguay", "Perú", "Republica Dominicana", "Trinidad y Tobago", "Uruguay", "Venezuela");
                foreach ($paises as $pais) {
                    $selected = ($pais == $pais_antiguo) ? 'selected' : '';
                    echo "<option value='$pais' $selected>$pais</option>";
                }
                echo "</select>";
            }
            ?>
            </div>  
        </div>

<!--DATOS ACADEMICOS---------------------------------------------------------------------------------->
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
            <h4>Datos Académicos</h4> <br>
        </button>
        </h2>       
            <?php 
            //grado academico
            //En php y haces una consulta en la tabla de concentrados
                $sql = "SELECT * FROM `concentradoacademico`";//datos que estan en esa tabla para evaluar similitudes
                $res = mysqli_query($conexion, $sql);
                
                //se hizo en php por que en html da errores
                echo '<div class="form-group">';
                echo '<label for="gradoAcademico" class="col-form-label">Grado Academico</label>';
                echo '<select name="gradoAcademico" id="gradoAcademico" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                //no mover lo de arriba, unicamente cambiar el nombre de las variables
                
                while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                    $gradoAcademico = $row['gradoAcademico'];//se obtiene el dato de la tabla concentradoacademico
                    if(!$gradoAcademico==""){//que en caso de editar, no muestre los valores nulos
                            // Verificar si el valor actual coincide con el valor previo
                        $selected = ($gradoAcademico == $gradoAcademico_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                        //si coinciden, se deja seleccionado, sino evalua el otro
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo "<option value=\"$gradoAcademico\" $selected>$gradoAcademico</option>";
                    }
                }
                echo '</select>';
                echo '</div>';
            ?>
                

            <div class="form-group">
                <hr>
                Nota: Para el campo "Institución de obtención del último grado" no es necesario volver a elegir el campo <br>
                <hr>
                instituto Previo: <?php echo "$insUltimoGrado_previo";?><br>
                <input type="hidden" name="instGrado" id="instGrado" value="<?php echo $insUltimoGrado_previo; ?>">
                <label for="instGrado" class="col-form-label">Institución de obtención del último grado</label>
                <select name="instGrado" id="instGrado" class="form-select" onchange="mostrarOtraInst()">
                    <option selected disabled value="">elige una opción...</option>

                    <?php
                    $sql = "SELECT * FROM `concentradoacademico`";
                    $res = mysqli_query($conexion, $sql);
                    while ($row = mysqli_fetch_array($res)) {
                        $instGrado = $row['instGrado'];
                        if(!$instGrado==""){
                    ?>
                            <option value="<?php echo $instGrado; ?>"><?php echo $instGrado; ?></option>
                    <?php
                        }    
                    }
                    ?>
                    <option value="otro">Otro</option>
                </select>

                <div id="campoOtraInst" style="display: none;">
                    <label for="otraInst">Ingresa la institución externa:</label>
                    <input type="text" id="otraInst" name="otraInst" placeholder="Nombre de la Institución">
                </div>
            </div>



            <div class="form-group">
                <div class="col">
                <label for="nacionalidad2">Nacionalidad Academico</label><br>
                <input type="hidden" name="nacionalidad2" value="<?php echo $nacionalidad2_antiguo; ?>">
                <?php
                if($nacionalidad2_antiguo === 'Mexicana'){
                    echo "Nacionalidad anterior: ";
                    echo "<td>". $nacionalidad2_antiguo . "</td><br>";
                    $estado_antiguo = $datos['estado2'];
                    echo "<th>Estado:</th>";
                    // Mostrar select de estado con la opción seleccionada según el estado anterior
                    echo "<select name='estado2'>";
                    echo "<option value=''>Seleccione un estado...</option>";
                    $estados = array("Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas", "Chihuahua", "Coahuila", "Colima", "Ciudad de México", "Durango", "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "México", "Michoacán", "Morelos", "Nayarit", "Nuevo León", "Oaxaca", "Puebla", "Querétaro", "Quintana Roo", "San Luis Potosí", "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas");
                    foreach ($estados as $estado) {
                        $selected = ($estado == $estado_antiguo) ? 'selected' : '';
                        echo "<option value='$estado' $selected>$estado</option>";
                    }
                    echo "</select>";
                } else if ($nacionalidad2_antiguo === 'Extranjera') {
                    echo "Nacionalidad anterior: ";
                    echo "<td>". $nacionalidad2_antiguo . "</td><br>";
                    $pais_antiguo = $datos['pais2'];
                    echo "<th>País:</th>";
                    echo "<td>". $pais_antiguo . "</td>";
                    // Mostrar select de país con la opción seleccionada según el país anterior
                    echo "<select name='pais2'>";
                    echo "<option value=''>Seleccione un país...</option>";
                    $paises = array("Alemania", "Argentina", "Belice", "Bolivia", "Brasil", 'Canadá', "Colombia", "Costa Rica", "Cuba", "Chile", "Ecuador", "El Salvador", "España", "Estados Unidos", "Guatemala", "Honduras", "Nicaragua", "Paraguay", "Perú", "Republica Dominicana", "Trinidad y Tobago", "Uruguay", "Venezuela");
                    foreach ($paises as $pais) {
                        $selected = ($pais == $pais_antiguo) ? 'selected' : '';
                        echo "<option value='$pais' $selected>$pais</option>";
                    }
                    echo "</select>";
                }
                ?>
            </div>
<!---------------------------NACIONALIDAD 2--------------------------->
                                    
<!--------------------------------FIN DE Nacionalidad---->
            <div class="form-group">
                <label for="anioObtGrado" class="col-form-label">Año de obtencion de Grado(dd/mm/aa)</label>
                <input type="number" name="anioObtGrado" id="anioObtGrado" class="form-control" pattern="^(19|20)\d{2}$" title="Ingresa un año válido (entre 1900 y 2024)" min="1900" max="2024" placeholder="Ingresa 4 digitos" value="<?php echo $datos['anioObtGrado'] ?>" required>
            </div>

            <input type="hidden" name="cvu" id="cvu" value="<?php echo $cvu_previo; ?>">
                                                    
            <div class="form-group">
                <label for="cvun" class="col-form-label">Número de CVU CONACyT</label>
                <input type="number" name="cvun" id="cvun" class="form-control" title="Ingresa un numero válido" placeholder="Ingresa 6 digitos" value="<?php echo $cvun_previo;?>" required>
            </div> 

<!-----------oculto el archivod de CVU eb Editar------------------------
                                <div class="form-group">
                                    <label for="cvu" class="col-form-label">CVU CONAHCyT</label>
                                    <p>Archivo previo: <?php echo $cvu_previo; ?></p>
                                    <input type="file" name="cvu" id="cvu" class="form-control" required>
                                </div>-->

            <?php 
            //Area de estudios
                $sql = "SELECT * FROM `generalposgradosconcentrado`";
                $res = mysqli_query($conexion, $sql);
                
                echo '<div class="form-group">';
                echo '<label for="areaEstudios" class="col-form-label">Area de estudio</label>';
                echo '<select name="areaEstudios" id="areaEstudios" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                
                while ($row = mysqli_fetch_array($res)) {
                    $areaEstudios = $row['areaEstudio'];
                    if(!$areaEstudios==""){
                            // Verificar si el valor actual coincide con el valor previo
                        $selected = ($areaEstudios == $areaEstudios_previo) ? 'selected' : '';
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo " <option value=\"$areaEstudios\" $selected>$areaEstudios</option>";
                    }
                }
                
                echo '    </select>';
                echo '</div>';
            ?>

            <?php 
            //SNI
                $sql = "SELECT * FROM `concentradoacademico`";
                $res = mysqli_query($conexion, $sql);
                
                echo '<div class="form-group">';
                echo '<label for="sni" class="col-form-label">SNI</label>';
                echo '<select name="sni" id="sni" class="form-select" required>';
                echo '<option selected disabled value="">elige una opción...</option>';
                
                while ($row = mysqli_fetch_array($res)) {
                    $sni = $row['sni'];
                    if(!$sni==""){
                            // Verificar si el valor actual coincide con el valor previo
                        $selected = ($sni == $sni_previo) ? 'selected' : '';
                    
                        // Generar la opción con el atributo selected si coincide con el valor previo
                        echo " <option value=\"$sni\" $selected>$sni</option>";
                    }
                }
                
                echo '    </select>';
                echo '</div>';
            ?>


            <div class="form-group">
                <label for="vigenciaSNI" class="col-form-label">Vigencia del SNI</label>
                <input type="date" name="vigenciaSNI" id="vigenciaSNI" min="1900-01-01" max="2050-12-31" value="<?php echo $vigenciaSNI; ?>">
            </div>

            <div class="form-group">
                <label for="url" class="col-form-label">Productividad (URL)</label>
                <input type="url" name="url" id="url" required class="form-control" pattern="https?://.+"  value="<?php echo $urlProductividad; ?>">
            </div>

<!---------------------------------------------------------------------DATOS LABORALES----------------------------------------------------------------------------------------->
            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                <h4> Datos Laborales</h4>
            </button>
            </h2>
            <div class="accordion-body">
                <?php 
                    //grado academico
                    //En php y haces una consulta en la tabla de concentrados
                        $sql = "SELECT * FROM `generalposgradosconcentrado`";//datos que estan en esa tabla para evaluar similitudes
                        $res = mysqli_query($conexion, $sql);
                        
                        //se hizo en php por que en html da errores
                        echo '<div class="form-group">';
                        echo '<label for="adscripcion" class="col-form-label">Adscripcion Actual</label>';
                        echo '<select name="adscripcion" id="adscripcion" class="form-select" required>';
                        echo '<option selected disabled value="">elige una opción...</option>';
                        //no mover lo de arriba, unicamente cambiar el nombre de las variables
                        
                        while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                            $sedes = $row['sedes'];//se obtiene el dato de la tabla concentradoacademico
                            if(!$sedes==""){//que en caso de editar, no muestre los valores nulos
                                    // Verificar si el valor actual coincide con el valor previo
                                $selected = ($sedes == $adscripcion_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                                //si coinciden, se deja seleccionado, sino evalua el otro
                            
                                // Generar la opción con el atributo selected si coincide con el valor previo
                                echo "<option value=\"$sedes\" $selected>$sedes</option>";
                            }
                        }
                    echo '</select>';
                    echo '</div>';
                ?>

                <?php 
                //grado academico
                //En php y haces una consulta en la tabla de concentrados
                    $sql = "SELECT * FROM `generalposgrados`";//datos que estan en esa tabla para evaluar similitudes
                    $res = mysqli_query($conexion, $sql);
                    
                    //se hizo en php por que en html da errores
                    echo '<div class="form-group">';
                    echo '<label for="posgrados" class="col-form-label">Posgrado en el que participa</label>';
                    echo '<select name="posgrados" id="posgrados" class="form-select" required>';
                    echo '<option selected disabled value="">elige una opción...</option>';
                    //no mover lo de arriba, unicamente cambiar el nombre de las variables
                    
                    while ($row = mysqli_fetch_array($res)) {//recorre los datos hasta dar con el parecido
                        $nombrePosgrado = $row['nombre'];//se obtiene el dato de la tabla concentradoacademico
                        if(!$nombrePosgrado==""){//que en caso de editar, no muestre los valores nulos
                                // Verificar si el valor actual coincide con el valor previo
                            $selected = ($nombrePosgrado == $posgrados_previo) ? 'selected' : '';//compara el resultado de ambas opciones,
                            //si coinciden, se deja seleccionado, sino evalua el otro
                        
                            // Generar la opción con el atributo selected si coincide con el valor previo
                            echo "<option value=\"$nombrePosgrado\" $selected>$nombrePosgrado</option>";
                        }
                    }
                        echo '</select>';
                        echo '</div>';
                    ?>

                    <?php 
                    //Area de estudios

                        $sql = "SELECT * FROM `concentradoacademico`";
                        $res = mysqli_query($conexion, $sql);
                        echo '<div class="form-group">';
                        echo '<label for="tiempoPosgrado" class="col-form-label">Dedicacion en el Posgrado</label>';
                        echo '<select name="tiempoPosgrado" id="tiempoPosgrado" class="form-select" required>';
                        echo '<option selected disabled value="">elige una opción...</option>';
                        
                        while ($row = mysqli_fetch_array($res)) {
                            $tiempoPosgrado = $row['tiempoPosgrado'];
                            if(!$tiempoPosgrado==""){
                                    // Verificar si el valor actual coincide con el valor previo
                                $selected = ($tiempoPosgrado == $tiempoPosgrado_previo) ? 'selected' : '';
                            
                                // Generar la opción con el atributo selected si coincide con el valor previo
                                echo " <option value=\"$tiempoPosgrado\" $selected>$tiempoPosgrado</option>";
                            }
                        }
                        

                        
                        echo '    </select>';
                        echo '</div>';
                    ?>                             


            </div>     
    </div>

    <div class="modal-footer">
      <a href="../principales/generalesProfesor.php"> 
        <button type="button" class="btn btn-secondary" data-bs-toggle="modal">Cerrar</button>
      </a>
      
      <button type="submit" class="btn btn-primary">Guardar</button>
    </div>
  </form>

</div>

<script src="../js/evaluarProfesor.js"></script>

