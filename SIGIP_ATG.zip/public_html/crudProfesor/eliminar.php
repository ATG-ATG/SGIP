<?php
include('../conexion/conexion.php');
$id = $_REQUEST['id'];

$DeleteRegistro = "DELETE FROM profesores WHERE profid='" . $id . "'";
mysqli_query($conexion, $DeleteRegistro);

$DeleteRegistro2 = "DELETE FROM academicosprofesor WHERE profid='" . $id . "'";
mysqli_query($conexion, $DeleteRegistro2);

$DeleteRegistro3 = "DELETE FROM laboralesprofesor WHERE profid='" . $id . "'";
mysqli_query($conexion, $DeleteRegistro3);

header("location: ../principales/generalesProfesor.php");

?>