
<?php
include('../conexion/conexion.php');
$id = $_POST['id'];
//----------------------------Datos Personales---------------------------------------->
$nombre =  mysqli_real_escape_string($conexion, $_POST['nombre']);
$apellidoPaterno =  mysqli_real_escape_string($conexion, $_POST['apellidoPaterno']);
$apellidoMaterno =  mysqli_real_escape_string($conexion, $_POST['apellidoMaterno']);
$claveTrabajador =  mysqli_real_escape_string($conexion, $_POST['claveTrabajador']);
$correo =  mysqli_real_escape_string($conexion, $_POST['correo']);
$telefono =  mysqli_real_escape_string($conexion, $_POST['telefono']);
$sexo =  mysqli_real_escape_string($conexion, $_POST['sexo']);
$nacionalidad = mysqli_real_escape_string($conexion, $_POST['nacionalidad']);
//------------------------------datos academicos--------------------------------------->
$gradoAcademico =  mysqli_real_escape_string($conexion, $_POST['gradoAcademico']);
$instGrado = mysqli_real_escape_string($conexion, $_POST['instGrado']);
$anioObtGrado = mysqli_real_escape_string($conexion, $_POST['anioObtGrado']);
$url = mysqli_real_escape_string($conexion, $_POST['url']);
$cvun = mysqli_real_escape_string($conexion, $_POST['cvun']);
$expediente_profesor = $_FILES['expediente_profesor']['name'];
//$cvu = $_FILES['cvu']['name'];
$vigenciaSNI = mysqli_real_escape_string($conexion, $_POST['vigenciaSNI']);
$areaEstudios = mysqli_real_escape_string($conexion, $_POST['areaEstudios']);
$sni = mysqli_real_escape_string($conexion, $_POST['sni']);
$nacionalidad2 = mysqli_real_escape_string($conexion, $_POST['nacionalidad2']);
//-----------------------------obtencion de Datos Laborales---------------------------->
$adscripcion = mysqli_real_escape_string($conexion, $_POST['adscripcion']);
$posgrados = mysqli_real_escape_string($conexion, $_POST['posgrados']);
$tiempoPosgrado = mysqli_real_escape_string($conexion, $_POST['tiempoPosgrado']);


$nombre = ucwords(strtolower($nombre));
$apellidoPaterno = ucwords(strtolower($apellidoPaterno));
$apellidoMaterno = ucwords(strtolower($apellidoMaterno));

if (isset ($_POST['archiante'])){
    $archiante=$_POST['archiante'];
}
else {
    $archiante='';

}

$agregar = "";
$agregar2 = "";
$agregar3 = "";

if ($expediente_profesor !=''){

    $resultguarda = guardarArchivo($claveTrabajador);
    if ($resultguarda!='OK'){
            print ('ocurrio un error al guardar archivo: ');
            print ($resultguarda);
            exit ();
    }
    
    $cvu=$claveTrabajador.'_'.$expediente_profesor;
    }
    else {
            $cvu=$archiante;
    }



//Validacion de la primera nacionalidad
if ($nacionalidad === 'Mexicana') {
    $estado = mysqli_real_escape_string($conexion, $_POST['estado']);
    $agregar = "UPDATE profesores SET 
        nombre='" . $nombre . "', 
        apellidoPaterno='" . $apellidoPaterno . "', 
        apellidoMaterno='" . $apellidoMaterno . "', 
        claveTrabajador='" . $claveTrabajador . "', 
        correo='" . $correo . "',
        telefono='" . $telefono . "', 
        nacionalidad='" . $nacionalidad . "',
        estado='" . $estado . "',
        sexo='" . $sexo ."',
        sede='interno',
        pais = NULL WHERE profid='" . $id . "'";
} else if ($nacionalidad === 'Extranjera') {
    $pais = mysqli_real_escape_string($conexion, $_POST['pais']);
    if ($pais === 'otro') {//si se eligio otro como pais
        $otroPais = mysqli_real_escape_string($conexion, $_POST['otroPais']);//obtener dato escrito en la casilla
        $agregar = "UPDATE profesores SET nombre='" . $nombre . "', 
            apellidoPaterno='" . $apellidoPaterno . "', 
            apellidoMaterno='" . $apellidoMaterno . "', 
            claveTrabajador='" . $claveTrabajador . "', 
            correo='" . $correo . "',
            telefono='" . $telefono . "', 
            nacionalidad='" . $nacionalidad . "',
            pais='" . $otroPais . "',
            sexo='" . $sexo ."',
            sede='interno',
            estado = NULL WHERE profid='" . $id . "'";
    } else {//si se eligio un pais de la lista...
        $agregar = "UPDATE profesores SET nombre='" . $nombre . "', 
        apellidoPaterno='" . $apellidoPaterno . "', 
        apellidoMaterno='" . $apellidoMaterno . "', 
        claveTrabajador='" . $claveTrabajador . "', 
        correo='" . $correo . "',
        telefono='" . $telefono . "', 
        nacionalidad='" . $nacionalidad . "',
        pais='" . $pais . "',
        sexo='" . $sexo ."',
        sede='interno',
        estado = NULL WHERE profid='" . $id . "'";
    }
}

if ($nacionalidad2 === 'Mexicana') {
    $estado2 = mysqli_real_escape_string($conexion, $_POST['estado2']);

    if ($instGrado === 'UAGro') {
        $agregar2 = "UPDATE academicosprofesor SET 
            gradoAcademico='" . $gradoAcademico . "', 
            insUltimoGrado='" . $instGrado . "',
            nacionalidad2='" . $nacionalidad2 . "',
            estado2='" . $estado2 . "',
            anioObtGrado='" . $anioObtGrado . "',
            cvun='" . $cvun . "',
            cvu='" . $cvu . "',
            areaEstudios='" . $areaEstudios . "',
            sni='" . $sni . "',
            vigenciaSNI='" . $vigenciaSNI . "',
            urlProductividad='" . $url . "',
            sede='interno',
            pais2=NULL WHERE profid='" . $id . "'";
    } else if ($instGrado === 'otro') {
        $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);
        $agregar2 = "UPDATE academicosprofesor SET 
            gradoAcademico='" . $gradoAcademico . "', 
            insUltimoGrado='" . $otraInst . "',
            nacionalidad2='" . $nacionalidad2 . "',
            estado2='" . $estado2 . "',
            anioObtGrado='" . $anioObtGrado . "',
            cvun='" . $cvun . "',
            cvu='" . $cvu . "',
            areaEstudios='" . $areaEstudios . "',
            sni='" . $sni . "',
            vigenciaSNI='" . $vigenciaSNI . "',
            urlProductividad='" . $url . "',
            sede='interno',
            pais2=NULL WHERE profid='" . $id . "'";
    }
} else if ($nacionalidad2 === 'Extranjera') {
    $pais2 = mysqli_real_escape_string($conexion, $_POST['pais2']);

    if ($pais2 === 'otro') {
        $otroPais2 = mysqli_real_escape_string($conexion, $_POST['otroPais2']);
        $agregar2 = "UPDATE academicosprofesor SET 
            gradoAcademico='" . $gradoAcademico . "', 
            insUltimoGrado='" . $instGrado . "',
            nacionalidad2='" . $nacionalidad2 . "',
            pais2='" . $otroPais2 . "',
            anioObtGrado='" . $anioObtGrado . "',
            cvun='" . $cvun . "',
            cvu='" . $cvu . "',
            areaEstudios='" . $areaEstudios . "',
            sni='" . $sni . "',
            vigenciaSNI='" . $vigenciaSNI . "',
            urlProductividad='" . $url . "',
            sede='interno',
            estado2=NULL WHERE profid='" . $id . "'";
    } else {
        $agregar2 = "UPDATE academicosprofesor SET 
            gradoAcademico='" . $gradoAcademico . "', 
            insUltimoGrado='" . $instGrado . "',
            nacionalidad2='" . $nacionalidad2 . "',
            pais2='" . $pais2 . "',
            anioObtGrado='" . $anioObtGrado . "',
            cvun='" . $cvun . "',
            cvu='" . $cvu . "',
            areaEstudios='" . $areaEstudios . "',
            sni='" . $sni . "',
            vigenciaSNI='" . $vigenciaSNI . "',
            urlProductividad='" . $url . "',
            sede='interno',
            estado2=NULL WHERE profid='" . $id . "'";
    }
}

$agregar3 = "UPDATE laboralesprofesor SET 
    posgrados ='" . $posgrados . "',
    adscripcion ='" . $adscripcion . "',
    tiempoPosgrado='" . $tiempoPosgrado . "',
    sede='interno' WHERE profid='" . $id . "'";



$res = mysqli_query($conexion, $agregar);
$res2 = mysqli_query($conexion, $agregar2);
$res3 = mysqli_query($conexion, $agregar3);

echo "<script type='text/javascript'>
        window.location='../principales/generalesProfesor.php';
    </script>";


    function guardarArchivo($idProf)
    {
            //  ***   Codigo para guardar archivo
            $target_dir = "filesprofesor/";
            $carpeta=$target_dir;
            if (!file_exists($carpeta)) {
                mkdir($carpeta, 0777, true);
            }
            $target_file = $carpeta . $idProf.'_'. basename($_FILES['expediente_profesor']['name']);
            $archiExpe = $idProf.'_'.$_FILES['expediente_profesor']['name'];
            $tamaExpe = $_FILES['expediente_profesor']['size'];
            $uploadOk = 1;
            $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
            // Check if image file is a actual image or fake image
            /*
            $check = getimagesize($_FILES["archivo"]["tmp_name"]);
            if($check !== false) {
                $messages[]= "OK: El archivo es una imagen - " . $check["mime"] . ".";
                $uploadOk = 1;
            } else {
                $errors[]= "Error: El archivo no es una imagen.";
                $uploadOk = 0;
            }
       
             */
            // Check if file already exists
            if (file_exists($target_file)) {
                $errors[]="Error: El archivo ya existe.";
                $uploadOk = 0;
            }
            
            if ($tamaExpe ==0){
                $errors[]="Error: el archivo es demasiado grande.  Tama&ntilde;o m&aacute;ximo admitido: 1.2 MB";
                $uploadOk = 0;
            }
            // Check file size //se obtiene la cant 5MB * 1048576 bytes
            if ($_FILES["expediente_profesor"]["size"] > 5242880) {
                $errors[]= "Error: el archivo es demasiado grande. Tama&ntilde;o m&aacute;ximo admitido: 5 MB";
                $uploadOk = 0;
            }
            // Allow certain file formats
            if($imageFileType != "pdf" ) {
                $errors[]= "Error: S&oacute;lo archivos PDF son permitidos.";
                $uploadOk = 0;
            }
            // Check if $uploadOk is set to 0 by an error
            
            if ($uploadOk == 0) {
                $errors[]= "Error: ocurri&oacute; un problema.";
            // if everything is ok, try to upload file
            } else {
                if (move_uploaded_file($_FILES['expediente_profesor']['tmp_name'], $target_file)) {
                    $messages[]= "OK: El Archivo se guardo correctamente.";
                   $uploadOk =1;
    
                } else {
                   $errors[]= "Error: no se pudo guardar el archivo.";
                }
            }
            //   *******
    
            if ($uploadOk == 0) {
                if (isset($errors)){           
                    foreach ($errors as $error){
                            print '<p class="alert alert-danger">'.$error. '</p>';
                    }            
                }
                exit();
            }
            if ($uploadOk == 1){
                    return "OK";
            }
        
        }
    

    
?>