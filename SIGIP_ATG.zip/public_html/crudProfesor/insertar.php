<?php
include('../conexion/conexion.php');
//-----------------------------Obtencion de Datos Generales del Profesor--------------------->
$nombre =  mysqli_real_escape_string($conexion, $_POST['nombre']);
$apellidoPaterno =  mysqli_real_escape_string($conexion, $_POST['apellidoPaterno']);
$apellidoMaterno =  mysqli_real_escape_string($conexion, $_POST['apellidoMaterno']);
$claveTrabajador =  mysqli_real_escape_string($conexion, $_POST['claveTrabajador']);
$correo =  mysqli_real_escape_string($conexion, $_POST['correo']);
$telefono =  mysqli_real_escape_string($conexion, $_POST['telefono']);
$sexo =  mysqli_real_escape_string($conexion, $_POST['sexo']);
//----------------------------Obtencion de Datos Academicos--------------------------->
$gradoAcademico =  mysqli_real_escape_string($conexion, $_POST['gradoAcademico']);
$instGrado = mysqli_real_escape_string($conexion, $_POST['instGrado']);
$anioObtGrado = mysqli_real_escape_string($conexion, $_POST['anioObtGrado']);
$url = mysqli_real_escape_string($conexion, $_POST['url']);
$cvun = mysqli_real_escape_string($conexion, $_POST['cvun']);//agregar en bd
//$cvu = $_FILES['cvu']['name'];
$expediente_profesor = $_FILES['cvu']['name'];
$vigenciaSNI = mysqli_real_escape_string($conexion, $_POST['vigenciaSNI']);
$areaEstudios = mysqli_real_escape_string($conexion, $_POST['areaEstudios']);
$sni = mysqli_real_escape_string($conexion, $_POST['sni']);
$nacionalidad = mysqli_real_escape_string($conexion, $_POST['nacionalidad']);
$nacionalidad2 = mysqli_real_escape_string($conexion, $_POST['nacionalidad2']);//obtiene la nacionalidad2
//-----------------------------obtencion de Datos Laborales----------------------------->
$adscripcion = mysqli_real_escape_string($conexion, $_POST['adscripcion']);
$posgrados = mysqli_real_escape_string($conexion, $_POST['posgrados']);
$tiempoPosgrado = mysqli_real_escape_string($conexion, $_POST['tiempoPosgrado']);



$agregar = "";
$agregar2 = "";
$agregar3 = "";

if ($expediente_profesor!=''){

$resultguarda = guardarArchivo($claveTrabajador);
if ($resultguarda!='OK'){
        print ('ocurrio un error al guardar archivo: ');
        print ($resultguarda);
}

$expediente_profesor=$claveTrabajador.'_'.$expediente_profesor;
}
else {
        $expediente_profesor=$archiante;
}

//----------------------------------------------------------VALIDACIONES-----------------------------------------------------------
// Convertir la primera letra de cada palabra a mayúscula
$nombre = ucwords(strtolower($nombre));
$apellidoPaterno = ucwords(strtolower($apellidoPaterno));
$apellidoMaterno = ucwords(strtolower($apellidoMaterno));//ucwords(primera letra en mayusculas), strtolower(las demas letras en minusculas)


//Validacion de la primera nacionalidad
if ($nacionalidad === 'Mexicana') {//si nacionalidad 1 es mexicana
        $estado = mysqli_real_escape_string($conexion, $_POST['estado']);//Se obtiene el dato que tiene estado 1
//-----no mover
                $agregar = "INSERT INTO profesores (nombre, apellidoPaterno, apellidoMaterno, claveTrabajador, correo, telefono, nacionalidad, estado, sexo, sede)
                VALUES ('$nombre', '$apellidoPaterno', '$apellidoMaterno', '$claveTrabajador', '$correo', '$telefono', '$nacionalidad', '$estado',  '$sexo', 'interno')";
//-----arriba no mover
} else if ($nacionalidad === 'Extranjera') { //Si es extranjera
        $pais = mysqli_real_escape_string($conexion, $_POST['pais']);//obtener dato pais
        if ($pais === 'otro') {//si se eligio otro como pais
            $otroPais = mysqli_real_escape_string($conexion, $_POST['otroPais']);//obtener dato escrito en la casilla
            $agregar = "INSERT INTO profesores (nombre,apellidoPaterno,apellidoMaterno,claveTrabajador,correo,telefono,nacionalidad, pais, sexo, sede)
                VALUES ('$nombre','$apellidoPaterno','$apellidoMaterno','$claveTrabajador','$correo','$telefono','$nacionalidad','$otroPais','$sexo', 'interno')";
        } else {//si se eligio un pais de la lista...
                $agregar = "INSERT INTO profesores (nombre, apellidoPaterno, apellidoMaterno, claveTrabajador, correo, telefono, nacionalidad, pais, sexo, sede)
                VALUES ('$nombre', '$apellidoPaterno', '$apellidoMaterno', '$claveTrabajador', '$correo', '$telefono', '$nacionalidad', '$pais', '$sexo', 'interno')";
        }
}
//Esta dividido en dos por que da problemas al separarlos, y que flojera la verdad(validacion de la nacionalidad 2)
if($nacionalidad2 === 'Mexicana') {//si nacionalidad 2 es mexicana
        $estado2 = mysqli_real_escape_string($conexion, $_POST['estado2']);//Se obtiene el dato que tiene estado 2
        if($instGrado === 'UAGro'){
                if($sni == 'Ninguno'){
                        $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                        VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', '$estado2', null, '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', null, '$url', 'interno')";
                }else{
                        $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                        VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', '$estado2', null, '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'interno')";
                }  
        }else{
                $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);//Se obtiene el dato que escribio en otra institucion
                if($sni == 'Ninguno'){
                        $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun,  cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                        VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', '$estado2', null, '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', null, '$url', 'interno')";
                }else{
                        $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun,  cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                        VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', '$estado2', null, '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'interno')";
                }
                
                 
        }
        
}else if($nacionalidad2 === 'Extranjera'){//Si nacionalidad 2 es extranjera
        $pais2 = mysqli_real_escape_string($conexion, $_POST['pais2']);//se obtiene el valor de pais 2
        if ($pais2 === 'otro') {//si se ha seleccionando en la opcion de otro
                $otroPais2 = mysqli_real_escape_string($conexion, $_POST['otroPais2']);//obtiene el dato del pais escrito en el input
                //Aqui es para insertar los datos academicos-------------->
                if($instGrado === 'UAGro'){
                        if($sni == 'Ninguno'){
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', null, '$otroPais2', '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', null, '$url', 'interno')";  
                        }else{
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', null, '$otroPais2', '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'interno')";  
                        }
                }else{
                        $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);//Se obtiene el dato que escribio en otra institucion
                        if($sni == 'Ninguno'){
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', null, '$otroPais2', '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', null, '$url', 'interno')";  
                        }else{
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', null, '$otroPais2', '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'interno')";  
                        }
                        
                        //-----------------------------<
                }
        }else{
                //Aqui es para insertar los datos academicos-------------->
                //se ingresa el pais2
                if($instGrado === 'UAGro'){
                        if($sni == 'Ninguno'){
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', null, '$pais2', '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', null, '$url', 'interno')";  
                        }else{
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                        VALUES ('$gradoAcademico', '$instGrado', '$nacionalidad2', null, '$pais2', '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'interno')";  
                        }
                        
                }else{
                        $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);//Se obtiene el dato que escribio en otra institucion
                        if($sni == 'Ninguno'){
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', null, '$pais2', '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', null, '$url', 'interno')"; 
                        }else{
                                $agregar2 = "INSERT INTO academicosprofesor (gradoAcademico, insUltimoGrado, nacionalidad2, estado2, pais2, anioObtGrado, cvun, cvu, areaEstudios, sni, vigenciaSNI, urlProductividad, sede)
                                VALUES ('$gradoAcademico', '$otraInst', '$nacionalidad2', null, '$pais2', '$anioObtGrado', '$cvun', '$expediente_profesor', '$areaEstudios', '$sni', '$vigenciaSNI', '$url', 'interno')"; 
                        }
                         
                        //-----------------------------<
                }
                
        }
}

$agregar3 = "INSERT INTO laboralesprofesor (posgrados, adscripcion, tiempoPosgrado, sede)
VALUES ('$posgrados', '$adscripcion', '$tiempoPosgrado', 'interno')"; 

try { $inserInmueble = mysqli_query($conexion, $agregar);

}
catch (Exception $e){
        print "ocurrio un error: 1" . $e->getMessage();
}

try { $inserInmueble2 = mysqli_query($conexion, $agregar2);

}
catch (Exception $e){
        print "ocurrio un error: 2" . $e->getMessage();
}


try { $inserInmueble3 = mysqli_query($conexion, $agregar3);

}
catch (Exception $e){
        print "ocurrio un error: 3" . $e->getMessage();
}



//-----------------------------Obtencion de Datos Academicos del Profesor--------------------->



header("Location: ../principales/generalesProfesor.php");
function guardarArchivo($idprof)
{
        //  ***   Codigo para guardar archivo
        $target_dir = "filesprofesor/";
        $carpeta=$target_dir;
        if (!file_exists($carpeta)) {
            mkdir($carpeta, 0777, true);
        }
        $target_file = $carpeta . $idprof.'_'. basename($_FILES['cvu']['name']);
        $archiExpe = $idprof.'_'.$_FILES['cvu']['name'];
        $tamaExpe = $_FILES['cvu']['size'];
        $uploadOk = 1;
        $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
        // Check if image file is a actual image or fake image
        /*
        $check = getimagesize($_FILES["archivo"]["tmp_name"]);
        if($check !== false) {
            $messages[]= "OK: El archivo es una imagen - " . $check["mime"] . ".";
            $uploadOk = 1;
        } else {
            $errors[]= "Error: El archivo no es una imagen.";
            $uploadOk = 0;
        }
   
         */
        // Check if file already exists
        if (file_exists($target_file)) {
            $errors[]="Error: El archivo ya existe.";
            $uploadOk = 0;
        }
		
		if ($tamaExpe ==0){
			$errors[]="Error: el archivo es demasiado grande.  Tama&ntilde;o m&aacute;ximo admitido: 1.2 MB";
            $uploadOk = 0;
		}
        // Check file size //se obtiene la cant 5MB * 1048576 bytes
        if ($_FILES["cvu"]["size"] > 5242880) {
            $errors[]= "Error: el archivo es demasiado grande. Tama&ntilde;o m&aacute;ximo admitido: 5 MB";
            $uploadOk = 0;
        }
        // Allow certain file formats
        if($imageFileType != "pdf" ) {
            $errors[]= "Error: S&oacute;lo archivos PDF son permitidos.";
            $uploadOk = 0;
        }
        // Check if $uploadOk is set to 0 by an error
        
        if ($uploadOk == 0) {
            $errors[]= "Error: ocurri&oacute; un problema.";
        // if everything is ok, try to upload file
        } else {
            if (move_uploaded_file($_FILES['cvu']['tmp_name'], $target_file)) {
                $messages[]= "OK: El Archivo se guardo correctamente.";
               $uploadOk =1;

            } else {
               $errors[]= "Error: no se pudo guardar el archivo.";
            }
        }
        //   *******

        if ($uploadOk == 0) {
            if (isset($errors)){           
                foreach ($errors as $error){
                        print '<p class="alert alert-danger">'.$error. '</p>';
                }            
            }
            exit();
        }
        if ($uploadOk == 1){
                return "OK";
        }
    
    }

?>
