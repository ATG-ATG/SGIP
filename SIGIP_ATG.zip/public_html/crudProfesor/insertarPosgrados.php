<?php
include('../conexion/conexion.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Recibe la ID del profesor desde el formulario
    $profesorId = isset($_POST['idProfesor']) ? $_POST['idProfesor'] : null;

    if ($profesorId === null) {
        echo "Error: No se ha proporcionado una ID válida de profesor.";
        exit;
    }

    $posgrados = [];
    $tiemposPosgrado = [];

    function filtrarValores($datos)
    {
        return array_filter($datos, function ($valor) {
            return $valor !== '' && !is_null($valor);
        });
    }

    for ($i = 1; $i <= 5; $i++) {
        if (!empty($_POST["posgrado$i"])) {
            $posgrados[] = $_POST["posgrado$i"];
        }

        if (!empty($_POST["tiempoPosgrado$i"])) {
            $tiemposPosgrado[] = $_POST["tiempoPosgrado$i"];
        }
    }

    $posgradosFiltrados = filtrarValores($posgrados);
    $tiemposPosgradoFiltrados = filtrarValores($tiemposPosgrado);
    $numPosgrados = count($posgradosFiltrados);
    $numTiemposPosgrado = count($tiemposPosgradoFiltrados);

    // Verificar si ya existen registros para este profesor
    $query_check = "SELECT * FROM masposgrados WHERE idProfesor = ?";
    $stmt_check = $conexion->prepare($query_check);
    $stmt_check->bind_param("i", $profesorId);
    $stmt_check->execute();
    $result = $stmt_check->get_result();

    if ($result->num_rows > 0) {
        // Actualizar registros existentes
        $query_update = "UPDATE masposgrados SET posgrado1 = ?, posgrado2 = ?, posgrado3 = ?, posgrado4 = ?, posgrado5 = ?, tiempoPosgrado1 = ?, tiempoPosgrado2 = ?, tiempoPosgrado3 = ?, tiempoPosgrado4 = ?, tiempoPosgrado5 = ? WHERE profesor_id = ?";
        $stmt_update = $conexion->prepare($query_update);

        $datosUpdate = array_merge($posgradosFiltrados, array_fill(0, 5 - $numPosgrados, null), $tiemposPosgradoFiltrados, array_fill(0, 5 - $numTiemposPosgrado, null));
        $datosUpdate[] = $profesorId; // Añadir la ID del profesor al final

        $stmt_update->bind_param("ssssssssssi", ...$datosUpdate);
        $stmt_update->execute();

        if ($stmt_update->affected_rows > 0) {
            header("Location: ../principales/generalesProfesor.php");
        } else {
            header("Location: ../principales/generalesProfesor.php?error=update_failed");
        }

        $stmt_update->close();
    } else {
        // Insertar nuevo registro
        $query_insert = "INSERT INTO masposgrados (idProfesor, posgrado1, posgrado2, posgrado3, posgrado4, posgrado5, tiempoPosgrado1, tiempoPosgrado2, tiempoPosgrado3, tiempoPosgrado4, tiempoPosgrado5) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert = $conexion->prepare($query_insert);

        $datosInsert = array_merge([$profesorId], $posgradosFiltrados, array_fill(0, 5 - $numPosgrados, null), $tiemposPosgradoFiltrados, array_fill(0, 5 - $numTiemposPosgrado, null));

        $stmt_insert->bind_param("issssssssss", ...$datosInsert);
        $stmt_insert->execute();

        if ($stmt_insert->affected_rows > 0) {
            header("Location: ../principales/generalesProfesor.php");
        } else {
            header("Location: ../principales/generalesProfesor.php?error=insert_failed");
        }

        $stmt_insert->close();
    }

    $stmt_check->close();
}
?>
