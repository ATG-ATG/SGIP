<?php
    session_cache_expire(1);
    session_start ();
   
    include_once 'dao/daouser.php';

    if (isset($_POST['user'])) {
        $reg['user'] = addslashes($_POST['user']);
    }

    else {
        print "No se recibio el parametro usuario";
        exit();
    }

    if (isset($_POST['passuser'])) {
        $reg['passuser'] = addslashes($_POST['passuser']);
    }

    else {
        print "No se recibio el parametro password";
        exit();
    }

    $user = new User();
   
        $RegUser = $user->validarUser($reg['user'], $reg['passuser']);
   
        // $RegUser = $user->validarUser($reg);


if ($RegUser->num_rows > 0){
    $registro= $RegUser->fetch_assoc();
        
        $_SESSION['login']	= "YES";
		$_SESSION['user']	= $registro['user'];
		$_SESSION['usernom']	= $registro['nomuser'];
        $_SESSION['usernivel']	= $registro['niveluser'];
        print ( $_SESSION['loginuser']);
	 	$redirigir = 'Location: '.'index.php';
	 // print $username. '<br>';
	 // print $clave;
	 	header ($redirigir);
	 	die;
     
 }
 else {
    $redirigir = 'Location: '.'login.php?codigo=1';
    // print $error;
    header ($redirigir);
    die;
 }


?>