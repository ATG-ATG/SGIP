<script>
    function eliminar() {
        return confirm('¿Estás seguro de querer Eliminarlo?');
    }
</script>

<?php
include('../conexion/conexion.php');
include('../conexion/key.php');

// Obtiene el término de búsqueda del formulario
$keyword = $_POST['keyword'];

// Realiza la consulta a la base de datos
$sql = "SELECT * FROM profesores WHERE nombre LIKE '%$keyword%'";
$result = mysqli_query($conexion, $sql);

// Muestra los resultados
if ($result->num_rows > 0) { ?>
    <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Primer Apellido</th>
                    <th scope="col">Email</th>
                    <th scope="col">Telefono</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Eliminar</th>
                    <th scope="col">Detalles</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['profid']; ?></td>
                        <td><?php echo $row['nombre']; ?></td>            
                        <td><?php echo $row['apellidoPaterno']; ?></td>
                        <td><?php echo $row['correo']; ?></td>
                        <td><?php echo $row['telefono']; ?></td>
                        <td style="text-align: center;">
                            <?php
                            echo '<a href="../modalProfesor/editarProfesor.php?id=' . $row['profid'] . '"><button class="btn btn-outline-success">Editar</button></a>';
                            ?>


                        </td>
                        <td style="text-align: center;">
                            <?php
                            echo '<a href="../crudProfesor/eliminar.php?id=' . $row['profid'] . '"><button class="btn btn-outline-danger">Eliminar</button></a>';
                            ?>
                        </td>

                    
                        
                        <td style="text-align: center;">
                            <div class="btn-group">
                                <a href="../modalProfesor/detalles.php?id=<?php echo $row['profid']; ?>&token=<?php echo hash_hmac('sha256', $row['profid'], KEY_TOKEN);?>" class="btn btn-primary">
                                    Detalles
                                </a>
                            </div>
                        </td>

                    </tr>

                <?php } ?>

        </table>
<?php
} else {
    echo "No se encontraron resultados.";
}

?>