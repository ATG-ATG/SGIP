<script>
    function eliminar() {
        return confirm('¿Estas seguro de querer Eliminarlo?');
    }
</script>

<?php
include('../conexion/conexion.php');
include('../conexion/key.php');

// Obtiene el término de búsqueda del formulario
$keyword = $_POST['keyword'];

// Realiza la consulta a la base de datos
$sql = "SELECT * FROM generalposgrados WHERE nombre LIKE '%$keyword%'";
$result = mysqli_query($conexion, $sql);

// Muestra los resultados
if ($result->num_rows > 0) { ?>
    <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                <th scope="col">Id</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Número de registro SNP</th>
                    <th scope="col">Región</th>
                    <th scope="col">Año de registro</th>
                    <th scope="col">Editar</th>
                    <th scope="col">Eliminar</th>
                    <th scope="col">Detalles</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['idPosgrados']; ?></td>
                        <td><?php echo $row['nombre']; ?></td>           
                        <td><?php echo $row['numSPN']; ?></td>
                        <td><?php echo $row['region']; ?></td>
                        <td><?php echo $row['anioInicio']; ?></td>

                        <!--BOTON DE EDITAR POSGRADOS, el archivo se llama "editar2.php" en la carpeta modalPosgrados-->
                        <td style="text-align: center;">
                            <?php
                                echo '<a href="../modalPosgrados/expeposgrado.php?idposgdo=' . $row['idPosgrados'] . '"><button class="btn btn-outline-success">Archivos</button></a>';
                            ?>
                        </td>

                        <!--BOTON DE EDITAR POSGRADOS, el archivo se llama "editar2.php" en la carpeta modalPosgrados-->
                        <td style="text-align: center;">
                            <?php
                                echo '<a href="../modalPosgrados/editarPosgrado.php?id=' . $row['idPosgrados'] . '"><button class="btn btn-outline-success">Editar</button></a>';
                            ?>
                        </td>

                        <!--BOTON DE ELIMINAR POSGRADOS-->
                        <td style="text-align: center;">
                            <?php
                            echo '<a href="../baseDatosPos/eliminarPos.php?id=' . $row['idPosgrados'] . '"><button class="btn btn-outline-danger"  onclick="return confirmacion()">Eliminar</button></a>';
                            ?>
                        </td>

                    
                        <!--BOTON DE DETALLES POSGRADOS-->
                        <td style="text-align: center;">
                            <div class="btn-group">
                                <a href="../modalPosgrados/detalles.php?id=<?php echo $row['idPosgrados']; ?>&token=<?php echo hash_hmac('sha256', $row['idPosgrados'], KEY_TOKEN);?>" class="btn btn-primary">
                                    Detalles
                                </a>
                            </div>
                        </td>

                    </tr>

                <?php } ?>

        </table>
<?php
} else {
    echo "No se encontraron resultados.";
}

?>