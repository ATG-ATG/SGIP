<script>
    function eliminar() {
        return confirm('¿Estas seguro de querer Eliminarlo?');
    }
</script>


<?php
include('../conexion/conexion.php');
include('../conexion/key.php');

$keyword = $_POST['keyword'];


$sql = "SELECT * FROM ingresoestudiante WHERE nombreEst LIKE '%$keyword%'";
$result = mysqli_query($conexion, $sql);

?>


<?php if($result->num_rows > 0) {?>

    <div id='search-results'>
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr style="text-align: center;" >
                    <th scope="col">Id</th>
                    <th scope="col">Matrícula</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Número de CVU CONAHCyT</th>
                    <th scope="col">Generación</th>
                    <th scope="col">Posgrado al que Pertenece</th>
                    <th scope="col">Editar General</th>
                    <th scope="col">Eliminar</th>
                    <th scope="col">Detalles</th>

                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($result)) { ?>
                    <tr>
                        <td><?php echo $row['idEstudiante']; ?></td>
                        <td><?php echo $row['matricula']; ?></td>           
                        <td><?php echo $row['nombreEst']; ?></td>           
                        <td><?php echo $row['numCVU']; ?></td>
                        <td><?php echo $row['generacion']; ?></td>
                        <td><?php echo $row['nombre']; ?></td>


                        <!--BOTON PARA EDITAR ESTUDIANTES-->
                        <td style="text-align: center;">
                            <?php
                                echo '<a href="../modalEstudiantes/editarEstudiante.php?id=' . $row['idEstudiante'] . '"><button class="btn btn-outline-success">Editar</button></a>';
                            ?>
                        </td>

                        <!--BOTON DE ELIMINAR ESTUDIANTES-->
                        <td style="text-align: center;">
                            <?php
                            echo '<a href="../baseDatosEst/eliminarEst.php?id=' . $row['idEstudiante'] . '"><button class="btn btn-outline-danger"  onclick="return confirmacion()">Eliminar</button></a>';
                            ?>
                        </td>

                    
                        <!--BOTON DE DETALLES-->
                        <td style="text-align: center;">
                            <div class="btn-group">
                                <a href="../modalEstudiantes/detallesEstudiante.php?id=<?php echo $row['idEstudiante']; ?>&token=<?php echo hash_hmac('sha256', $row['idEstudiante'], KEY_TOKEN);?>" class="btn btn-primary">
                                    Detalles
                                </a>
                            </div>
                        </td>
                        

                    </tr>
                <?php } ?>

        </table>
    </div>
    
</div>
<?php
}else{
    echo "No se encontraron resultados.";
}
include('../modalEstudiantes/agregarEstudiante.php');


?>