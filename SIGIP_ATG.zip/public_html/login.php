<?php
    session_cache_expire(1);
    session_start ();
?>

<!DOCTYPE html>
<?php

?>
<html lang="es">
<head>
  <title>Inicio de sesión Indicadores</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="estilos.css">
    <!-- Latest compiled and minified CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
<!--logo -     
<div class="container">                         
            encabezado
                    <div class="container-fluid p-5 bg-primary text-white text-center">
                        <img src="img/logo_pr.png" height="90" width="130" class="float-start img-fluid" alt="logo posgrado">
                        <h1>Universidad Autónoma de Guerrero</h1>
                        <h3>Dirección de Posgrado</h3> 
                      </div> --> 
              
    <!--encabezado para agregar el banner principal  -->     
            <div class="container">
            <img src="img/INDICADORES.jpg" height="300" width="1300" class="float-start img-fluid" alt="logo indicadores">
            &nbsp
            &nbsp
            &nbsp
    <div class ="container col-md-6 col-md-offset-3">
           
    <div class="mt-3 p-2 bg-secondary text-white text-center rounded">
    <h1>Inicio de sesi&oacute;n<div class="d-none">
        
    </div>
    </h1>
        </div>
            <p></p>
        <div class="panel panel-default ">
            <div class="panel-heading">
            <h4> Introduzca sus datos de usuario: </h4>
            </div>
            <div class="panel-body">
                <form action="validarlogin.php" method="post">
                <div class="form-group" id="nomusuario">
                    <label for="usuario">Usuario:</label>
                    <input type="text" class="form-control" id="usuario" name="user" required>
                </div>
                <div class="form-group" id="contrase">
                    <label for="pwd">Contrase&ntilde;a:</label>
                    <input type="password" class="form-control" id="pwd" name="passuser" required>
                </div>
    <br>
    <input type="submit" class="btn btn-outline-primary" name="enviar" value="Iniciar sesi&oacute;n" id="enviar">
       </form>
            
        </div>
        </div> 
        

        <?php
        if (isset($_GET['codigo'])) {
            if ($_GET['codigo'] == 1) {
               
                print '<div class="alert alert-danger alert-dismissible">';
                print '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
                print '<strong>Error: </strong>  Usuario o contrase&ntilde;a incorrectos';
                print '</div>';
               
            }

            if ($_GET['codigo'] == 2) {
                print '<div class="alert alert-danger alert-dismissible fade in id="alerta">';
                print ' <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
                print ' Usuario o contrase&ntilde;a incorrectos';
                print '</div>';
            }

            if ($_GET['codigo'] == 3) {
                print '<div class="alert alert-danger alert-dismissible fade in"  id="alerta">';
                print ' <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>';
                print ' Usuario o contrase&ntilde;a incorrectos';
                print '</div>';
            }
        }
                    
        ?> 
    </div>

    

</body>
</html>
