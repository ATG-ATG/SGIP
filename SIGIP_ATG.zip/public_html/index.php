<?php
session_cache_expire(1);
session_start();

if (empty($_SESSION['login']))
{
    header('Location:login.php');
    die;
}
$user = $_SESSION['user'];
$niveluser = $_SESSION['usernivel'];
?>

<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Indicadores Posgrados DP</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1">

    </head>
    
    <body>
         <!--logo         
        <div class="container">                         
                    <div class="container-fluid p-5 bg-primary text-white text-center">
                        <img src="img/INDICADORES.jpg" height="90" width="130" class="float-start img-fluid" alt="logo posgrado">
                        <h1>Universidad Autónoma de Guerrero</h1>
                        <h3>Dirección de Posgrado</h3> 
                        <h2>Sistema Generador de Indicadores de Posgrados</h2>
                      </div>-->

                <div class="container">
                        <img src="img/INDICADORES.jpg" height="300" width="1600" class="float-start img-fluid" alt="logo indicadores">

            <!--menú superior-->
                    <div class="row">
                        <div class="col-sm-2"></div>
                        <div class="col-sm-6 text-center"></div>
                        <ul class="nav justify-content-end" class="nav nav-tabs">
                            <li class="nav-item">
                            <li class="nav-item">
                            <a class="nav-link active" href="index.php">Inicio</a>
                                </li>
                            <li class="nav-item">
                                <a class="nav-link" href="principales/generalesProfesor.php">Profesores</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="principales/generalesPosgrados.php">Posgrados</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="principales/generalesEstudiantes.php">Estudiantes</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link disabled" href="#">Administrativo</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="indicador/indicador.php">Indicadores</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="login.php">Salir</a>
                            </li>
                        </ul>
                    </div> 
            </div>                               
         <!--container sistema-->
         <br>
         <div class="row">
             <div class="container p-5 col-sm-9 border">
            
                 <h1>Sistema Generador de Indicadores de Posgrados</h1>
                 <p>Aplicación web que permite recolectar y almacenar información de programas de posgrado, profesores y estudiantes de los posgrados de la UAGro.</p>
                 <br><br>
                 <div class="row">    
                            
                     <div class="col-3"><a class="btn btn-outline-secondary" href="principales/generalesProfesor.php">Información Profesores</a></div>
                     
                     <div class="col-3"><a class="btn btn-outline-secondary" href="principales/generalesPosgrados.php">Información Posgrados</a></div>
                     
                     <div class="col-3"><a class="btn btn-outline-secondary" href="principales/generalesEstudiantes.php">Información Estudiantes</a></div>
                 <!--modal close-->
                    </div>
                  </div>  
             </div>        
         </div>
        </div>
    </body>
    <br>
    
    <div class="row">
    <footer class="container-fluid text-center">
    <div class="alert alert-secondary">
    <strong>SGIP</strong> ... Sistema Generador de Indicadores UAGro ... </p>
      </footer>
        </div>
    </div>
</html>