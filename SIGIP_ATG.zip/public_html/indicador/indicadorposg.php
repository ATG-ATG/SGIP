<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Indicadores Posgrados DP</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>
  <?php include('../menu.php');
  include('../conexion/conexion.php');
  include('../conexion/key.php');
  ?>

  <!--inicio de indicadores particulares de POSGRADOS-->
  <br>
  <div class="row">
    <div class="container p-5 col-sm-9 border">
      <div class="col-3">
        <h3><span class="label label-default">POSGRADOS</span></h3>
      </div>
      <h3>Indicadores particulares de cada posgrado</h3>
      <br>
      <div class="row">
        <!-- barra de busqueda Posgrados-->
        <?php
        if (isset($_POST['buscar'])) {
          $searchTerm = $_POST['buscar'];

          // Consulta SQL con búsqueda (adapta a tu estructura de tabla)
          //$sql = "SELECT * FROM generalposgrados a INNER JOIN academicosprofesor b on a.profid = b.profid WHERE nombre LIKE '%" . $searchTerm . "%'";
          //$sql = "SELECT * FROM generalposgrados a INNER JOIN evaluacionposgrado b INNER JOIN fichatecnicapos c on a.idPosgrados = b.idPosgrados = c.idPosgrados  WHERE nombre LIKE '%" . $searchTerm . "%'";
          $sql = "SELECT t1.idPosgrados, t1.nombre, t1.numREG, t1.inicioposg, t2.instPos, t1.nombreCoord,
          t3.periocidad, t3.durPos, t3.credito, t1.anioInicio, t1.dependencia
          FROM generalposgrados t1 
          INNER JOIN evaluacionposgrado t2 on t1.idPosgrados = t2.idPosgrados 
          INNER JOIN fichatecnicapos t3 ON t1.idPosgrados = t3.idPosgrados 
          WHERE nombre LIKE '%" . $searchTerm . "%'";

          $result = $conexion->query($sql);
        }
        ?>
        <br>
        <div>
          <form method="post" action="">  
            <input type="text" name="buscar" id="buscar" placeholder="Buscar por nombre...">
            <button type="submit" class="btn btn-secondary">Buscar</button>
          </form>
        </div>
        <!--  -->
        <br><br>
        <div id="resultados">
          <?php if (isset($result) && $result->num_rows > 0): ?>
            <div class="table-responsive">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Registro DGP</th>
                    <th>Año de Inicio</th>
                    <th>Tipo de Evaluación</th>
                    <th>Nombre Coord.</th>
                    <th>Periodicidad</th>
                    <th>Duración</th>
                    <th>Créditos</th>
                    <th>Sede</th>
                    <th>Fecha de Aprob. HCU</th>
                    <th>Fecha de Inicio</th>
                  </tr>
                </thead>
                <tr>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                  <tr>
                    <td><?php echo $row['idPosgrados']; ?></td>
                    <td><?php echo $row['nombre']; ?></td>
                    <td><?php echo $row['numREG']; ?></td>
                    <td><?php echo $row['inicioposg']; ?></td>
                    <td><?php echo $row['instPos']; ?></td>
                    <td><?php echo $row['nombreCoord']; ?></td>
                    <td><?php echo $row['periocidad']; ?></td>
                    <td><?php echo $row['durPos']; ?></td>
                    <td><?php echo $row['credito']; ?></td>
                    <td><?php echo $row['dependencia']; ?></td>
                    <td><?php echo $row['inicioposg']; ?></td>
                    <td><?php echo $row['anioInicio']; ?></td>
                  </tr>
                <?php endwhile; ?>
              </table>
            </div>
          <?php else: ?>
            <p>No se encontraron resultados.</p>
          <?php endif; ?>
        </div>

        <script>
          // JavaScript para búsqueda en tiempo real (opcional)
          $(document).ready(function() {
            $("#buscar").on("keyup", function() {
              // Aquí puedes implementar una búsqueda en tiempo real usando AJAX para evitar recargar la página
              // ...
            });
          });
        </script>
        <!-- barra de busqueda Termina Posgrados -->
      </div>
    </div>
  </div>
  <br>
  <!--inicio indicadores generales-->
  <div class="row">
    <div class="container p-5 col-sm-9 border">
      <div class="container mt-3">
        <h2>Indicadores generales cuantitativos de los Posgrados</h2>
        <br>
        <!--ONE
        <button type="button" class="btn btn-secondary">Listado de Posgrados vigentes</button>
        <p>IMP PDF del listado de los posgrados</p>
        <br>-->

        <div id="accordion">
          <!--ONE-->
          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
                Evaluación
              </a>
            </div>
            <div id="collapseOne" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">


                <div class="row">
                  <div class="col">
                    <div class="form-group">
                      <label class="col-form-label" style="width: 50%;">Elige el tipo de evaluación de los posgrados a cuantificar</label>
                      <form>

                        <select class="form-select" id="select" style="width: 50%;">
                          <option>Seleccionar...</option>
                          <option value="opcion1">SNP (PNPC)</option>
                          <option value="opcion2">SEIP-UAGro</option>
                          <option value="opcion3">CIFRHS</option>
                        </select>

                      </form>
                    </div>
                  </div>
                  <div class="">
                    <p id="resultado"></p>

                    <script>
                      function mostrarResultado(select) {
                        var valor = select.value;
                        var resultado = document.getElementById("resultado");

                        resultado.innerHTML = 'valor';
                      }
                      select.addEventListener("change", function(e) {
                        var valor = e.target.value;
                        var resultado = document.getElementById("resultado");

                        //seleccion de evalucion 
                        //contador de SNP(PNPC)
                        if (select.value === "opcion1") {
                          resultado.innerHTML = `<?php
                                                  // Consulta SQL modificada para seleccionar todos los datos
                                                  $sqlc = "SELECT * FROM `evaluacionposgrado` WHERE instPos  = 'SNP(PNPC)'";
                                                  $res = mysqli_query($conexion, $sqlc);
                                                  $contador = mysqli_num_rows($res);

                                                  $sql = "SELECT * FROM evaluacionposgrado a INNER JOIN generalposgrados b on a.idPosgrados = b.idPosgrados WHERE instPos = 'SNP(PNPC)'";
                                                  $result = mysqli_query($conexion, $sql);

                                                  // Crear la estructura de la tabla HTML en PHP
                                                  echo '<h4>TOTAL</h4>';
                                                  echo '<h4>' . $contador . '</h4>';
                                                  echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                  // Iterar sobre los resultados y crear filas
                                                  while ($row = mysqli_fetch_assoc($result)) {
                                                    echo '<tr>';
                                                    echo '<td>' . $row['idPosgrados'] . '</td>';
                                                    echo '<td>' . $row['nombre'] . '</td>';
                                                    echo '</tr>';
                                                  }
                                                  echo '</tbody></table>';
                                                  ?>`;

                        }
                        //contador de SEIP-UAgro
                        else if (select.value === "opcion2") {
                          resultado.innerHTML = `<?php
                                                  // Consulta SQL modificada para seleccionar todos los datos
                                                  $sql = "SELECT * FROM evaluacionposgrado a INNER JOIN generalposgrados b on a.idPosgrados = b.idPosgrados WHERE instPos = 'SEIP-UAGro'";
                                                  $result = mysqli_query($conexion, $sql);

                                                  $sqlc = "SELECT * FROM `evaluacionposgrado` WHERE instPos  = 'SEIP-UAGro'";
                                                  $res = mysqli_query($conexion, $sqlc);
                                                  $contador = mysqli_num_rows($res);

                                                  // Crear la estructura de la tabla HTML en PHP
                                                  echo '<h4>TOTAL</h4>';
                                                  echo '<h4>' . $contador . '</h4>';
                                                  echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                  // Iterar sobre los resultados y crear filas
                                                  while ($row = mysqli_fetch_assoc($result)) {
                                                    echo '<tr>';
                                                    echo '<td>' . $row['idPosgrados'] . '</td>';
                                                    echo '<td>' . $row['nombre'] . '</td>';
                                                    echo '</tr>';
                                                  }
                                                  echo '</tbody></table>';
                                                  ?>`;
                        } else if (select.value === "opcion3") {
                          resultado.innerHTML = `<?php
                                                  // Consulta SQL modificada para seleccionar todos los datos
                                                  $sql = "SELECT * FROM evaluacionposgrado a INNER JOIN generalposgrados b on a.idPosgrados = b.idPosgrados WHERE instPos = 'CIFRHS'";
                                                  $result = mysqli_query($conexion, $sql);

                                                  $sqlc = "SELECT * FROM `evaluacionposgrado` WHERE instPos  = 'CIFRHS'";
                                                  $res = mysqli_query($conexion, $sqlc);
                                                  $contador = mysqli_num_rows($res);

                                                  // Crear la estructura de la tabla HTML en PHP
                                                  echo '<h4>TOTAL</h4>';
                                                  echo '<h4>' . $contador . '</h4>';
                                                  echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                  // Iterar sobre los resultados y crear filas
                                                  while ($row = mysqli_fetch_assoc($result)) {
                                                    echo '<tr>';
                                                    echo '<td>' . $row['idPosgrados'] . '</td>';
                                                    echo '<td>' . $row['nombre'] . '</td>';
                                                    echo '</tr>';
                                                  }
                                                  echo '</tbody></table>';
                                                  ?>`;
                        }
                        //si no seleccina ninguno
                        else {
                          resultado.innerHTML = "No hay ninguna opción seleccionada";
                        }
                      });
                    </script>
                  </div>
                </div>


              </div>
            </div>
          </div>
          <!--Two-->
          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseTwo">
                Grados
              </a>
            </div>
            <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">
                <div class="row">
                  <div class="col">
                    <div class="form-group">
                      <label class="col-form-label">Elige el grado de los posgrados a cuantificar</label>
                      <form>
                        <select class="form-select" id="select2">
                          <option>Seleccionar...</option>
                          <option value="opcion1">Especialidad</option>
                          <option value="opcion2">Especilidad Médica</option>
                          <option value="opcion3">Maestría</option>
                          <option value="opcion4">Doctorado</option>
                          <option value="opcion5">Posdoctorado</option>
                        </select>
                      </form>
                    </div>
                  </div>

                  <br>

                  <p id="resultado2"></p>

                  <!-- Scrip de validacion -->
                  <script>
                    function mostrarResultado(select2) {
                      var valor2 = select2.value;
                      var resultado2 = document.getElementById("resultado2");

                      resultado2.innerHTML = 'valor2';
                    }
                    select2.addEventListener("change", function(e) {
                      var valor2 = e.target.value;
                      var resultado2 = document.getElementById("resultado2");

                      //seleccion de Grados
                      //contador de Especialidad
                      if (select2.value === "opcion1") {
                        resultado2.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE grado  = 'Especialidad'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE grado = 'Especialidad'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                      //contador de 
                      else if (select2.value === "opcion2") {
                        resultado2.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE grado  = 'Especialidad Médica'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE grado = 'Especialidad Médica'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                      //contador de Maestría
                      else if (select2.value === "opcion3") {
                        resultado2.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE grado  = 'Maestría'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE grado = 'Maestría'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                      //contador de Doctorado
                      else if (select2.value === "opcion4") {
                        resultado2.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE grado  = 'Doctorado'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE grado = 'Doctorado'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                      //contador de Posdoctorado
                      else if (select2.value === "opcion5") {
                        resultado2.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE grado  = 'Posdoctorado'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE grado = 'Posdoctorado'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                      //si no seleccina ninguno
                      else {
                        resultado2.innerHTML = "No hay ninguna opción seleccionada";
                      }
                    });
                  </script>
                  <!-- Termina Scrip de validacion -->
                </div>
              </div>
            </div>
          </div>
          <!--three-->
          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseThree">
                Orientación
              </a>
            </div>
            <div id="collapseThree" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">
                <div class="row">
                  <div class="col">
                    <div class="form-group">
                      <label class="col-form-label">Elige orientación de los posgrados a cuantificar</label>
                      <form>
                        <select class="form-select" id="select3">
                          <option>Seleccionar...</option>
                          <option value="opcion1">Profesional</option>
                          <option value="opcion2">Investigación</option>
                          <option value="opcion3">Tecnológico</option>
                        </select>
                      </form>
                    </div>
                  </div>
                    <br>
                    <p id="resultado3"></p>

                    <script>
                      function mostrarResultado(select3) {
                        var valor3 = select3.value;
                        var resultado3 = document.getElementById("resultado3");

                        resultado3.innerHTML = 'valor3';
                      }
                      select3.addEventListener("change", function(e) {
                        var valor3 = e.target.value;
                        var resultado3 = document.getElementById("resultado3");

                        //seleccion de Orientacion
                        //contador de Profesional
                        if (select3.value === "opcion1") {
                        resultado3.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE orientacion  = 'Profesional'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE orientacion = 'Profesional'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de Investigación
                        else if (select3.value === "opcion2") {
                        resultado3.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE orientacion  = 'Investigación'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE orientacion = 'Investigación'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de Tecnológico
                        else if (select3.value === "opcion3") {
                        resultado3.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE orientacion  = 'Tecnológico'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE orientacion = 'Tecnológico'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //si no seleccina ninguno
                        else {
                          resultado3.innerHTML = "No hay ninguna opción seleccionada";
                        }
                      });
                    </script>

                  
                </div>
              </div>
            </div>
          </div>
          <!--Four-->
          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseFour">
                Área
              </a>
            </div>
            <div id="collapseFour" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">
                <div class="row">
                  <div class="col">
                    <div class="form-group">
                      <label class="col-form-label">Elige el área de los posgrados a cuantificar</label>
                      <form>
                        <select class="form-select" id="select4">
                          <option>Seleccionar...</option>
                          <option value="opcion1">I.Físico-Matemáticas y Ciencias de la Tierra</option>
                          <option value="opcion2">II.Biología y Química</option>
                          <option value="opcion3">III.Medicina y Ciencias de la Salud</option>
                          <option value="opcion4">IV.Ciencias de la Conducta y la Educación</option>
                          <option value="opcion5">V.Humanidades</option>
                          <option value="opcion6">VI.Ciencias Sociales</option>
                          <option value="opcion7">VII.Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas</option>
                          <option value="opcion8">VIII.Ingenierías y Desarrollo Tecnológico</option>
                          <option value="opcion9">IX.Interdisciplinaria</option>
                        </select>
                      </form>
                    </div>
                  </div>
                    <br>

                    <p id="resultado4"></p>

                    <script>
                      function mostrarResultado(select4) {
                        var valor4 = select4.value;
                        var resultado4 = document.getElementById("resultado4");

                        resultado4.innerHTML = 'valor4';
                      }
                      select4.addEventListener("change", function(e) {
                        var valor4 = e.target.value;
                        var resultado4 = document.getElementById("resultado4");

                        //seleccion de Area
                        //contador de I.Físico-Matemáticas y Ciencias de la Tierra
                        if (select4.value === "opcion1") {
                        resultado4.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE areaEstudio  = 'I.Físico-Matemáticas y Ciencias de la Tierra'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE areaEstudio = 'I.Físico-Matemáticas y Ciencias de la Tierra'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de II.Biología y Química
                        else if (select4.value === "opcion2") {
                        resultado4.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE areaEstudio  = 'II.Biología y Química'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE areaEstudio = 'II.Biología y Química'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de III.Medicina y Ciencias de la Salud
                        else if (select4.value === "opcion3") {
                        resultado4.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE areaEstudio  = 'III.Medicina y Ciencias de la Salud'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE areaEstudio = 'III.Medicina y Ciencias de la Salud'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de IV.Ciencias de la Conducta y la Educación
                        else if (select4.value === "opcion4") {
                        resultado4.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE areaEstudio  = 'IV.Ciencias de la Conducta y la Educación'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE areaEstudio = 'IV.Ciencias de la Conducta y la Educación'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de V.Humanidades
                        else if (select4.value === "opcion5") {
                        resultado4.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE areaEstudio  = 'V.Humanidades'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE areaEstudio = 'V.Humanidades'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de VI.Ciencias Sociales
                        else if (select4.value === "opcion6") {
                        resultado4.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE areaEstudio  = 'VI.Ciencias Sociales'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE areaEstudio = 'VI.Ciencias Sociales'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de VII.Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas
                        else if (select4.value === "opcion7") {
                        resultado4.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE areaEstudio  = 'VII.Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE areaEstudio = 'VII.Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de VIII.Ingenierías y Desarrollo Tecnológico
                        else if (select4.value === "opcion8") {
                        resultado4.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE areaEstudio  = 'VIII.Ingenierías y Desarrollo Tecnológico'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE areaEstudio = 'VIII.Ingenierías y Desarrollo Tecnológico'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de IX.Interdisciplinaria 
                        else if (select4.value === "opcion9") {
                        resultado4.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE areaEstudio  = 'IX.Interdisciplinaria'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE areaEstudio = 'IX.Interdisciplinaria'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //si no seleccina ninguno
                        else {
                          resultado4.innerHTML = "No hay ninguna opción seleccionada";
                        }
                      });
                    </script>
                  
                </div>
              </div>
            </div>
          </div>
          <!--five-->
          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseFive">
                Región
              </a>
            </div>
            <div id="collapseFive" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">
                <div class="row">
                  <div class="col">
                    <div class="form-group">
                      <label class="col-form-label">Elige la región de los posgrados a cuantificar</label>
                      <form>
                        <select class="form-select" id="select5">
                          <option>Seleccionar...</option>
                          <option value="opcion1">Acapulco</option>
                          <option value="opcion2">Centro</option>
                          <option value="opcion3">Costa Chica</option>
                          <option value="opcion4">Costa Grande</option>
                          <option value="opcion5">Norte</option>
                          <option value="opcion6">Montaña</option>
                          <option value="opcion7">Tierra Caliente</option>
                          <option value="opcion8">Sierra</option>
                        </select>
                      </form>
                    </div>
                  </div>

                    <br>

                    <p id="resultado5"></p>

                    <script>
                      function mostrarResultado(select5) {
                        var valor5 = select5.value;
                        var resultado5 = document.getElementById("resultado5");

                        resultado5.innerHTML = 'valor5';
                      }
                      select5.addEventListener("change", function(e) {
                        var valor5 = e.target.value;
                        var resultado5 = document.getElementById("resultado5");

                        //seleccion de Area
                        //contador de Acapulco
                        if (select5.value === "opcion1") {
                        resultado5.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE region  = 'Acapulco'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE region = 'Acapulco'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de Centro
                        else  if (select5.value === "opcion2") {
                        resultado5.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE region  = 'Centro'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE region = 'Centro'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de Costa Chica
                        else  if (select5.value === "opcion3") {
                        resultado5.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE region  = 'Costa Chica'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE region = 'Costa Chica'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de Costa Grande
                        else  if (select5.value === "opcion4") {
                        resultado5.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE region  = 'Costa Grande'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE region = 'Costa Grande'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de Norte
                        else if (select5.value === "opcion5") {
                        resultado5.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE region  = 'Norte'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE region = 'Norte'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de Montaña
                        else  if (select5.value === "opcion6") {
                        resultado5.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE region  = 'Montaña'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE region = 'Montaña'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de Tierra Caliente
                        else  if (select5.value === "opcion7") {
                        resultado5.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE region  = 'Tierra Caliente'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE region = 'Tierra Caliente'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }
                        //contador de Sierra
                        else  if (select5.value === "opcion8") {
                        resultado5.innerHTML = `<?php
                                                // Consulta SQL modificada para seleccionar todos los datos
                                                $sqlc = "SELECT * FROM `generalposgrados` WHERE region  = 'Sierra'";
                                                $res = mysqli_query($conexion, $sqlc);
                                                $contador = mysqli_num_rows($res);

                                                $sql = "SELECT * FROM generalposgrados WHERE region = 'Sierra'";
                                                $result = mysqli_query($conexion, $sql);

                                                // Crear la estructura de la tabla HTML en PHP
                                                echo '<h4>TOTAL</h4>';
                                                echo '<h4>' . $contador . '</h4>';
                                                echo '<table id="resultado_tabla" class="table table-bordered">
                                                  <thead>
                                                  <tr>
                                                  <th>ID</th>
                                                  <th>Nombre</th>
                                                  </tr>
                                                  </thead>
                                                  <tbody>';

                                                // Iterar sobre los resultados y crear filas
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                  echo '<tr>';
                                                  echo '<td>' . $row['idPosgrados'] . '</td>';
                                                  echo '<td>' . $row['nombre'] . '</td>';
                                                  echo '</tr>';
                                                }
                                                echo '</tbody></table>';
                                                ?>`;

                      }

                        //si no seleccina ninguno
                        else {
                          resultado5.innerHTML = "No hay ninguna opción seleccionada";
                        }
                      });
                    </script>
                  
                </div>
              </div>
            </div>
          </div>
          <!--final-->


        </div>
      </div>
    </div>
  </div>
</body>

</html>