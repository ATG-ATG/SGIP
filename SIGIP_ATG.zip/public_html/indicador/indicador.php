<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Indicadores Posgrados DP</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    
    <body>
         <!--logo         
        <div class="container">                         
                    <div class="container-fluid p-5 bg-primary text-white text-center">
                        <img src="img/INDICADORES.jpg" height="90" width="130" class="float-start img-fluid" alt="logo posgrado">
                        <h1>Universidad Autónoma de Guerrero</h1>
                        <h3>Dirección de Posgrado</h3> 
                        <h2>Sistema Generador de Indicadores de Posgrados</h2>
                      </div>-->

            <?php include('../menu.php');?>
<!--menu para indicadores-->
<br>
<div class="row">
             <div class="container p-5 col-sm-9 border">
            
                 <h1>Sistema Generador de Indicadores</h1>
                 <br><br>
                 <div class="row">    
                     <div class="col-3"><a class="btn btn-secondary" href="/indicador/indicadorprof.php">Indicadores Profesores</a></div>
                     <div class="col-3"><a class="btn btn-secondary" href="/indicador/indicadorposg.php">Indicadores Posgrados</a></div>
                     <div class="col-3"><a class="btn btn-secondary" href="/indicador/indicadorest.php">Indicadores Estudiantes</a></div>
                     
                 </div>  
             </div>        
         </div>