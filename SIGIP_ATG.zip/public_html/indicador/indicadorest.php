<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Indicadores Posgrados DP</title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>

</head>

<body>

  <?php include('../menu.php');
  include('../conexion/conexion.php');
  include('../conexion/key.php');
  ?>

  <!--inicio de indicadores particulares de ESTUDIANTES-->
  <br>
  <div class="row">
    <div class="container p-5 col-sm-9 border">
      <div class="col-3">
        <h3><span class="label label-default">Estudiantes</span></h3>
      </div>
      <h3>Indicadores particulares de Estudiantes de los posgrados</h3>
      <br>
      <div class="row">
        <!-- barra de busqueda Estudiantes-->
        <?php
        if (isset($_POST['buscar']) && isset($_POST['generacion'])) {
          $searchTerm = $_POST['buscar'];
          $generacion = $_POST['generacion'];


          // Consulta SQL con búsqueda (adapta a tu estructura de tabla) CONTADOR
          $sql = "SELECT COUNT(*) AS total_registros FROM ingresoestudiante 
            WHERE nombre LIKE '%" . $searchTerm . "%' 
            AND generacion = '" . $generacion . "'";
          $cResult = $conexion->query($sql);

          if ($cResult) {
            $row = $cResult->fetch_assoc();
            $total_registros = $row['total_registros'];
        } else {
            echo "Error en la consulta: " . $conexion->error;
        }
        //-----------------------------------------------

        //ARRAY DE LOS ESTUDIANTES
          $sql = "SELECT * FROM ingresoestudiante  
          WHERE nombre LIKE '%" . $searchTerm . "%' 
            AND generacion = '" . $generacion . "'";
          $result = $conexion->query($sql);
        }
        ?>


        <br>


        <div>
          <form method="post" action="">
            <?php
            // Consulta para obtener los datos únicos de un campo específico (por ejemplo, "nombre") y ordenarlos alfabéticamente
            $sqln = "SELECT DISTINCT nombre FROM ingresoestudiante ORDER BY nombre ASC";
            $resn = $conexion->query($sqln);

            $sqlg = "SELECT DISTINCT generacion FROM ingresoestudiante ORDER BY generacion ASC";
            $resg = $conexion->query($sqlg);
            ?>

            <select class="form-select" aria-label="Default select example" name="buscar" id="buscar" style="width: 40%;">
              <option value="">Selecciona una opción</option>
              <?php
              while ($row = $resn->fetch_assoc()) {
                $nombre = $row['nombre'];
                $selected = ($nombre == $_POST['buscar']) ? 'selected' : '';
                echo "<option value='$nombre' $selected>$nombre</option>";
              }
              ?>
            </select>

            <select class="form-select" aria-label="Default select example" name="generacion" id="generacion" style="width: 40%";>
              <option value="">Selecciona una generación</option>
              <?php
              while ($row = $resg->fetch_assoc()) {
                $generacion = $row['generacion'];
                $selected = ($generacion == $_POST['generacion']) ? 'selected' : '';
                echo "<option value='$generacion' $selected>$generacion</option>";
              }
              ?>
            </select>
            <br>
            <button type="submit" class="btn btn-secondary">Buscar</button>
          </form>

        </div>
        <!--  -->
        <br><br>
        <div id="resultados">
          <?php if (isset($result) && $result->num_rows > 0): ?>
            <div class="table-responsive">
              <table class="table table-bordered">
              <thead>
                  <tr>
                    <th>Total</th>
                    <th><?php echo $total_registros; ?></th>
                  </tr>
                </thead>

                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Generación</th>

                  </tr>
                </thead>
                <tr>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                  <tr>
                    <td><?php echo $row['idEstudiante']; ?></td>
                    <td><?php echo $row['nombreEst']; ?></td>
                    <td><?php echo $row['generacion']; ?></td>
                  </tr>
                <?php endwhile; ?>
              </table>
            </div>
          <?php else: ?>
            <p>No se encontraron resultados.</p>
          <?php endif; ?>
        </div>

        <script>
          // JavaScript para búsqueda en tiempo real (opcional)
          $(document).ready(function() {
            $("#buscar").on("keyup", function() {
              // Aquí puedes implementar una búsqueda en tiempo real usando AJAX para evitar recargar la página
              // ...
            });
          });
        </script>
        <!-- barra de busqueda Termina Estudiante -->
      </div>

    </div>
  </div>
  <br>
  <!--inicio indicadores generales-->
  <div class="row">
    <div class="container p-5 col-sm-9 border">
      <div class="col-3"></div>
      <!-- <h4>Imprimir listas de estudiantes por posgrado</h4>
      <br>
      <div class="row">
        barra de busqueda
        <br>
        <div>
          <input type="text" id="search" placeholder="Buscar posgrado...">
          <button type="button" class="btn btn-secondary">Imprimir</button>
        </div>
        <br>
         -->
        <br>
        <div id="accordion">



          <!-- Inicio de Nacionalidad de estudiante -->

          <!-- SQL -->

          <?php
          //Contador de Nacionalidad de estudiante
          $sql = "SELECT * FROM `ingresoestudiante`";
          $res = mysqli_query($conexion, $sql);
          $conEst = mysqli_num_rows($res);
          //Termina Contador

          // Contador Nacionalidad Mexicana
          $sql = "SELECT * FROM `ingresoestudiante` WHERE nacionalidad  = 'Mexicana'";
          $res = mysqli_query($conexion, $sql);
          $NaciM = mysqli_num_rows($res);
          // Contador de mujeres
          $sql = "SELECT * FROM ingresoestudiante WHERE nacionalidad = 'Mexicana' AND sexo = 'Femenino'";
          $res = mysqli_query($conexion, $sql);
          $NaciM_F = mysqli_num_rows($res);
          // Contador de hombres
          $sql = "SELECT * FROM ingresoestudiante WHERE nacionalidad = 'Mexicana' AND sexo = 'Masculino'";
          $res = mysqli_query($conexion, $sql);
          $NaciM_M = mysqli_num_rows($res);
          // Termina contador Nacionalidad Mexicana

          // Contador Nacionalidad Extranjera
          $sql = "SELECT * FROM `ingresoestudiante` WHERE nacionalidad  = 'Extranjera'";
          $res = mysqli_query($conexion, $sql);
          $NaciE = mysqli_num_rows($res);
          // Contador de mujeres
          $sql = "SELECT * FROM ingresoestudiante WHERE nacionalidad = 'Extranjera' AND sexo = 'Femenino'";
          $res = mysqli_query($conexion, $sql);
          $NaciE_F = mysqli_num_rows($res);
          // Contador de hombres
          $sql = "SELECT * FROM ingresoestudiante WHERE nacionalidad = 'Extranjera' AND sexo = 'Masculino'";
          $res = mysqli_query($conexion, $sql);
          $NaciE_M = mysqli_num_rows($res);
          // Termina contador Nacionaliadd Extranjera

          ?>
          <!-- Termina SQL -->
          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseSix">
                Nacionalidad
              </a>
            </div>
            <div id="collapseSix" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">

                <div class="col">
                  <br>
                  <label class="col-form-label">Nacionalidad de Profesor </label>

                  <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                      <thead>
                        <tr>
                          <th scope="col">Total</th>
                          <th scope="col">Mexicana</th>
                          <th scope="col">Extranjera</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><?php echo $conEst ?></td>
                          <td><?php echo $NaciM ?></td>
                          <td><?php echo $NaciE ?></td>

                        </tr>
                        <tr>
                          <td>Hombres</td>
                          <td><?php echo $NaciM_M ?></td>
                          <td><?php echo $NaciE_M ?></td>

                        </tr>
                        <tr>
                          <td>Mujeres</td>
                          <td><?php echo $NaciM_F ?></td>
                          <td><?php echo $NaciE_F ?></td>

                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Termina Nacionalidad de estudiante -->



          <!-- Inicio de Nivel de estudiante -->

          <!-- SQL -->

          <?php
          //Contador de Nivel de estudiante
          $sql = "SELECT * FROM `ingresoestudiante`";
          $res = mysqli_query($conexion, $sql);
          $conNivel = mysqli_num_rows($res);
          //Termina Contador

          // Contador Nivel Maestría
          $sql = "SELECT * FROM `ingresoestudiante` WHERE nombre LIKE '%" . "Maestría" . "%'";
          $res = mysqli_query($conexion, $sql);
          $conNivel1 = mysqli_num_rows($res);
          // Contador de mujeres
          $sql = "SELECT * FROM ingresoestudiante WHERE nombre LIKE '%" . "Maestría" . "%' AND sexo = 'Femenino'";
          $res = mysqli_query($conexion, $sql);
          $nivel1_F = mysqli_num_rows($res);
          // Contador de hombres
          $sql = "SELECT * FROM ingresoestudiante WHERE nombre LIKE '%" . "Maestría" . "%' AND sexo = 'Masculino'";
          $res = mysqli_query($conexion, $sql);
          $nivel1_M = mysqli_num_rows($res);
          // Termina contador Nivel Maestría

          // Contador Nivel Doctorado
          $sql = "SELECT * FROM `ingresoestudiante` WHERE nombre LIKE '%" . "Doctorado" . "%'";
          $res = mysqli_query($conexion, $sql);
          $conNivel2 = mysqli_num_rows($res);
          // Contador de mujeres
          $sql = "SELECT * FROM ingresoestudiante WHERE nombre LIKE '%" . "Doctorado" . "%' AND sexo = 'Femenino'";
          $res = mysqli_query($conexion, $sql);
          $nivel2_F = mysqli_num_rows($res);
          // Contador de hombres
          $sql = "SELECT * FROM ingresoestudiante WHERE nombre LIKE '%" . "Doctorado" . "%' AND sexo = 'Masculino'";
          $res = mysqli_query($conexion, $sql);
          $nivel2_M = mysqli_num_rows($res);
          // Termina contador Nivel Doctorado en Derecho

          // Contador Nivel Especialidad
          $sql = "SELECT * FROM `ingresoestudiante` WHERE nombre LIKE '%" . "Especialidad" . "%'";
          $res = mysqli_query($conexion, $sql);
          $conNivel3 = mysqli_num_rows($res);
          // Contador de mujeres
          $sql = "SELECT * FROM ingresoestudiante WHERE nombre LIKE '%" . "Especialidad" . "%' AND sexo = 'Femenino'";
          $res = mysqli_query($conexion, $sql);
          $nivel3_F = mysqli_num_rows($res);
          // Contador de hombres
          $sql = "SELECT * FROM ingresoestudiante WHERE nombre LIKE '%" . "Especialidad" . "%' AND sexo = 'Masculino'";
          $res = mysqli_query($conexion, $sql);
          $nivel3_M = mysqli_num_rows($res);
          // Termina contador Nivel Especialidad

          ?>
          <!-- Termina SQL -->
          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseTwo">
                Estudiantes por nivel de posgrado
              </a>
            </div>
            <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">

                <div class="col">
                  <br>
                  <label class="col-form-label">Estudiantes por nivel de posgrado </label>

                  <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                      <thead>
                        <tr>
                          <th scope="col">Total</th>
                          <th scope="col">Maestría</th>
                          <th scope="col">Doctorado</th>
                          <th scope="col">Especialidad</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><?php echo $conNivel ?></td>
                          <td><?php echo $conNivel1 ?></td>
                          <td><?php echo $conNivel2 ?></td>
                          <td><?php echo $conNivel3 ?></td>

                        </tr>
                        <tr>
                          <td>Hombres</td>
                          <td><?php echo $nivel1_M ?></td>
                          <td><?php echo $nivel2_M ?></td>
                          <td><?php echo $nivel3_M ?></td>
                        </tr>
                        <tr>
                          <td>Mujeres</td>
                          <td><?php echo $nivel1_F ?></td>
                          <td><?php echo $nivel2_F ?></td>
                          <td><?php echo $nivel3_F ?></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Termina Nivel de estudiante -->


          <!--ONE-->
          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
                Estadística de estudiantes
              </a>
            </div>
            <div id="collapseOne" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">
                <div class="row">
                  <div class="col">
                    <div class="form-group">
                      <label class="col-form-label">Estudiantes</label>
                      <form>
                        <select class="form-select" id="select">
                          <option>Seleccionar...</option>
                          <option value="opcion1">Estudiantes</option>
                          <option value="opcion2">Vulnerable</option>
                        </select>
                      </form>
                    </div>
                  </div>
                  <div class="col">
                    <br>
                    <label class="col-form-label">Datos</label>
                    <div class="table-responsive">

                      <p id="resultado"></p>
                      <script>
                        function mostrarResultado(select) {
                          var valor = select.value;
                          var resultado = document.getElementById("resultado");

                          resultado.innerHTML = 'valor';
                        }
                        select.addEventListener("change", function(e) {
                          var valor = e.target.value;
                          var resultado = document.getElementById("resultado");

                          //seleccion de Estudiantes
                          //contador de Estudiantes
                          if (select.value === "opcion1") {
                            <?php
                            $sql = "SELECT * FROM `ingresoestudiante`";
                            $res = mysqli_query($conexion, $sql);
                            $contador = mysqli_num_rows($res);

                            $sql = "SELECT * FROM `ingresoestudiante` WHERE sexo = 'Masculino'";
                            $res = mysqli_query($conexion, $sql);
                            $contadorH = mysqli_num_rows($res);

                            $sql = "SELECT * FROM `ingresoestudiante` WHERE sexo = 'Femenino'";
                            $res = mysqli_query($conexion, $sql);
                            $contadorM = mysqli_num_rows($res);
                            ?>
                            resultado.innerHTML = `<?php echo '<table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">Total</th>
                    <th scope="col">Estudiantes </th>
                </tr>
            </thead>
            <tbody>
            <tr>
            <td>' . $contador . '</td>
            </tr>
                <tr>
                <td>Hombres</td>
                <td>' . $contadorH . '</td>


                </tr>
                <tr> 
                <td>Mujeres</td>
                <td>' . $contadorM . '</td>
                </tr>
            </tbody>
        </table>'
                                                    ?>`;
                          }
                          //contador de Vulnerabilidad
                          else if (select.value === "opcion2") {
                            <?php
                            $sql = "SELECT * FROM `ingresoestudiante`";
                            $res = mysqli_query($conexion, $sql);
                            $contador = mysqli_num_rows($res);

                            $sql = "SELECT * FROM `ingresoestudiante` WHERE grupoVulnerable = 'Ninguno'";
                            $res = mysqli_query($conexion, $sql);
                            $ninguno = mysqli_num_rows($res);

                            $sql = "SELECT * FROM `ingresoestudiante` WHERE grupoVulnerable = 'Discapacidad'";
                            $res = mysqli_query($conexion, $sql);
                            $discapacidad = mysqli_num_rows($res);

                            $sql = "SELECT * FROM `ingresoestudiante` WHERE grupoVulnerable = 'Indígena'";
                            $res = mysqli_query($conexion, $sql);
                            $indigena = mysqli_num_rows($res);

                            $sql = "SELECT * FROM `ingresoestudiante` WHERE grupoVulnerable = 'Afrodescendiente'";
                            $res = mysqli_query($conexion, $sql);
                            $afrodescendiente = mysqli_num_rows($res);
                            ?>
                            resultado.innerHTML = `<?php echo '<table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">Total</th>
                    <th scope="col">Estudiantes </th>
                </tr>
            </thead>
            <tbody>
            <tr>
            <td>' . $contador . '</td>
            </tr>
                <tr>
                <td>Ninguno</td>
                <td>' . $ninguno . '</td>

                </tr>
                <tr> 
                <td>Indígena</td>
                <td>' . $indigena . '</td>
                </tr>

                </tr>
                <tr> 
                <td>Afrodescendiente</td>
                <td>' . $afrodescendiente . '</td>
                </tr>

                </tr>
                <tr> 
                <td>Discapacidad</td>
                <td>' . $discapacidad . '</td>
                </tr>
            </tbody>
        </table>'
                                                    ?>`;
                          }
                          //contador de CIFRHS

                          //si no seleccina ninguno
                          else {
                            resultado.innerHTML = "No hay ninguna opción seleccionada";
                          }
                        });
                      </script>

                      <!-- <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">Total</th>
                    <th scope="col">Estudiantes </th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td>Hombres</td>
                <td></td>


                </tr>
                <tr> 
                <td>Mujeres</td>
                <td></td>

                </tr>
            </tbody>
        </table>
            </div>
        </div>
          </div>
          </div>
        </div>
      </div> -->

                      <!--Two
<div class="card">
      <div class="card-header">
        <a class="btn" data-bs-toggle="collapse" href="#collapseTwo">
          Grados Académicos
        </a>
      </div>
      <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
        <div class="card-body">
          <div class="row">
          <div class="col">                                       
          <div class="form-group">
          <label class="col-form-label">Profesores por nivel académico en el SNI</label>
           <form>
            <select class="form-select">
                <option>Seleccionar...</option>
                <option>Especialidad</option>
                <option>Especialidad Médica</option>
                <option>Maestría</option>
                <option>Doctorado</option>
                <option>Posdoctorado</option>
            </select>
            </form>                                               
            </div>
            <button type="button" class="btn btn-secondary">Imprimir</button>
            </div>
           <div class="col">                                            
             <br>
             <label class="col-form-label">Cantidad de profesores por nivel académico en posgrados</label>
            <div class="table-responsive">
       <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">Total</th>
                    <th scope="col">Especialidad</th>
                    <th scope="col">Especialidad Médica</th>
                    <th>Maestría</th>
                    <th scope="col">Doctorado</th>
                    <th scope="col">Posdoctorado</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td>200</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                </tr>
                <tr>
                <td>Hombres</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>-</td>
                </tr>
                <tr> 
                <td>Mujeres</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>-</td>
                </tr>
            </tbody>
        </table>
            </div>
        </div>
          </div>
          </div>
        </div>
      </div>-->
                      <!--three
<div class="card">
      <div class="card-header">
        <a class="btn" data-bs-toggle="collapse" href="#collapseThree">
          Orientación
        </a>
      </div>
      <div id="collapseThree" class="collapse" data-bs-parent="#accordion">
        <div class="card-body">
          <div class="row">
          <div class="col">                                       
          <div class="form-group">
           <label class="col-form-label">Elige orientación de los posgrados a cuantificar</label>
           <form>
            <select class="form-select">
                <option>Seleccionar...</option>
                <option>Profesional</option>
                <option>Investigación</option>
                <option>Tecnológico</option>
            </select>
            </form>                                              
            </div>
            </div>
           <div class="col">                                            
             <br>
            <label>Indicador</label><br>
            <label>Cantidad</label>
        </div>
          </div>
          </div>
        </div>
      </div>
      -->
                      <!--Four
<div class="card">
      <div class="card-header">
        <a class="btn" data-bs-toggle="collapse" href="#collapseFour">
          Área de estudio
        </a>
      </div>
      <div id="collapseFour" class="collapse" data-bs-parent="#accordion">
        <div class="card-body">
          <div class="row">
          <div class="col">                                       
          <div class="form-group">
           <label class="col-form-label">Elije el área de estudio de los profesores</label>
           <form>
            <select class="form-select">
            <option>Seleccionar...</option>
            <option>I.Físico-Matemáticas y Ciencias de la Tierra</option>
            <option>II.Biología y Química</option>
            <option>III.Medicina y Ciencias de la Salud</option>
            <option>IV.Ciencias de la Conducta y la Educación</option>
            <option>V.Humanidades</option>
            <option>VI.Ciencias Sociales</option>  
            <option>VII.Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas</option>
            <option>VIII.Ingenierías y Desarrollo Tecnológico</option>
            <option>IX.Interdisciplinaria</option>
            </select>
            </form>                                               
            </div>
            <button type="button" class="btn btn-secondary">Imprimir</button>
            </div>
           <div class="col">                                            
             <br>
             <div class="table-responsive">
       <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">Total</th>
                    <th scope="col">Área I</th>
                    <th scope="col">Área II</th>
                    <th>Área III</th>
                    <th scope="col">Área IV</th>
                    <th scope="col">Área V</th>
                    <th>Área VI</th>
                    <th>Área VII</th>
                    <th>Área VIII</th>
                    <th>Área IX</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                <td>200</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                <td>-</td>
                </tr>
                <tr>
                <td>Hombres</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                </tr>
                <tr> 
                <td>Mujeres</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                <td>0</td>
                </tr>
            </tbody>
        </table>
            </div>
        </div>
          </div>
          </div>
        </div>
      </div>-->
                      <!--five
<div class="card">
      <div class="card-header">
        <a class="btn" data-bs-toggle="collapse" href="#collapseFive">
          Región
        </a>
      </div>
      <div id="collapseFive" class="collapse" data-bs-parent="#accordion">
        <div class="card-body">
          <div class="row">
          <div class="col">                                       
          <div class="form-group">
           <label class="col-form-label">Elige la región de los posgrados a cuantificar</label>
           <form>
            <select class="form-select">
                <option>Seleccionar...</option>
                <option>Acapulco</option>
                <option>Centro</option>
                <option>Costa Chica</option>
                <option>Costa Grande</option>
                <option>Norte</option>
                <option>Montaña</option>
                <option>Tierra Caliente</option>
                <option>Sierra</option>
            </select>
            </form>                                               
            </div>
            </div>
           <div class="col">                                            
             <br>
            <label>Indicador</label><br>
            <label>Cantidad</label>
        </div>
          </div>
          </div>
        </div>
      </div>-->
                      <!--final-->


                    </div>
                  </div>
                </div>
              </div>
</body>

</html>