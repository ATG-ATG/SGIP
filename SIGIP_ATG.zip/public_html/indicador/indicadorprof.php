<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Indicadores Posgrados DP</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
</head>

<body>

  <?php include('../menu.php');
  include('../conexion/conexion.php');
  include('../conexion/key.php');
  ?>

  <!--inicio de indicadores particulares de PROFESORES-->
  <br>
  <div class="row">
    <div class="container p-5 col-sm-9 border">
      <div class="col-3">
        <h3><span class="label label-default">PROFESORES</span></h3>
      </div>
      <h3>Indicadores particulares de cada Profesor</h3>
      <br>
      <div class="row">
        <!-- barra de busqueda Profesores-->
        <?php
        if (isset($_POST['buscar'])) {
          $searchTerm = $_POST['buscar'];

          // Consulta SQL con búsqueda (adapta a tu estructura de tabla)
          $sql = "SELECT * FROM profesores a INNER JOIN academicosprofesor b on a.profid = b.profid WHERE nombre LIKE '%" . $searchTerm . "%'";
          $result = $conexion->query($sql);
        }
        ?>
        <br>
        <div>
          <form method="post" action="">  
            <input type="text" name="buscar" id="buscar" placeholder="Buscar por nombre...">
            <button type="submit" class="btn btn-secondary">Buscar</button>
          </form>
        </div>
        <!--  -->
        <br><br>
        <div id="resultados">
          <?php if (isset($result) && $result->num_rows > 0): ?>
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nombre</th>
                  <th>Apellido Paterno</th>
                  <th>Grado Académico</th>
                  <th>Correo</th>
                  <th>Teléfono</th>
                  <th>SNI</th>
                  <th>Área de Estudio</th>
                </tr>
              </thead>
              <tr>
              </tr>
              <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                  <td><?php echo $row['profid']; ?></td>
                  <td><?php echo $row['nombre']; ?></td>
                  <td><?php echo $row['apellidoPaterno']; ?></td>
                  <td><?php echo $row['gradoAcademico']; ?></td>
                  <td><?php echo $row['correo']; ?></td>
                  <td><?php echo $row['telefono']; ?></td>
                  <td><?php echo $row['sni']; ?></td>
                  <td><?php echo $row['areaEstudios']; ?></td>
                </tr>
              <?php endwhile; ?>
            </table>
          <?php else: ?>
            <p>No se encontraron resultados.</p>
          <?php endif; ?>
        </div>

        <script>
          // JavaScript para búsqueda en tiempo real (opcional)
          $(document).ready(function() {
            $("#buscar").on("keyup", function() {
              // Aquí puedes implementar una búsqueda en tiempo real usando AJAX para evitar recargar la página
              // ...
            });
          });
        </script>
        <!-- barra de busqueda Termina Profesores -->
      </div>
    </div>
  </div>
  <br>
  <!--inicio indicadores generales-->
  <div class="row">
    <div class="container p-5 col-sm-9 border">
      <div class="col-3"></div>
      <!--ONE<h4>Imprimir núcleos académicos</h4>
      <br>
      <div class="row">
         barra de busqueda
         <br>
        <div>
          <input type="text" id="search" placeholder="Buscar posgrado...">
          <button type="button" class="btn btn-secondary">Imprimir</button>
        </div>
        <br>-->
        <!--  -->
        <br>
        <div id="accordion">
          <!--ONE-->
          <!-- Inicia SQL -->
          <?php
          // contador total
          $sql = "SELECT * FROM `academicosprofesor`";
          $res = mysqli_query($conexion, $sql);
          $contador = mysqli_num_rows($res);

          //
          // contador nivel 1
          $sql2 = "SELECT * FROM `academicosprofesor` WHERE sni  = 'Nivel I'";
          $res2 = mysqli_query($conexion, $sql2);
          $nivel1 = mysqli_num_rows($res2);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Nivel I' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $nivel1F = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Nivel I' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $nivel1M = mysqli_num_rows($resM);
          //

          //
          // contador Candidatos
          $sql3 = "SELECT * FROM `academicosprofesor` WHERE sni  = 'Candidato'";
          $res3 = mysqli_query($conexion, $sql3);
          $candidatos = mysqli_num_rows($res3);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Candidato' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $candidatoF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Candidato' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $candidatoM = mysqli_num_rows($resM);
          //

          //
          // contador Nivel 2
          $sql4 = "SELECT * FROM `academicosprofesor` WHERE sni  = 'Nivel II'";
          $res4 = mysqli_query($conexion, $sql4);
          $nivel2 = mysqli_num_rows($res4);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Nivel II' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $nivel2F = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Nivel II' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $nivel2M = mysqli_num_rows($resM);
          //

          //
          // contador Nivel 3
          $sql5 = "SELECT * FROM `academicosprofesor` WHERE sni  = 'Nivel III'";
          $res5 = mysqli_query($conexion, $sql5);
          $nivel3 = mysqli_num_rows($res5);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Nivel III' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $nivel3F = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Nivel III' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $nivel3M = mysqli_num_rows($resM);
          //

          //
          // contador Emeritos
          $sql6 = "SELECT * FROM `academicosprofesor` WHERE sni  = 'Ninguno'";
          $res6 = mysqli_query($conexion, $sql6);
          $emerito = mysqli_num_rows($res6);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Ninguno' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $emeritoF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Ninguno' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $emeritoM = mysqli_num_rows($resM);
          //
          ?>
          <!-- Terminar SQL -->

          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
                SNI
              </a>
            </div>
            <div id="collapseOne" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">
                <div class="row">
                  <div class="col">
                    <br>
                    <label class="col-form-label">Cantidad de profesores por nivel en el SNI</label>
                    <div class="table-responsive">
                      <table class="table table-bordered table-striped table-hover">
                        <thead>
                          <tr>
                            <th scope="col">Total</th>
                            <th scope="col">Candidato</th>
                            <th scope="col">Nivel I</th>
                            <th>Nivel II</th>
                            <th scope="col">Nivel III</th>
                            <th scope="col">Ninguna
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td><?php echo $contador ?></td>
                            <td><?php echo $candidatos ?></td>
                            <td><?php echo $nivel1 ?></td>
                            <td><?php echo $nivel2 ?></td>
                            <td><?php echo $nivel3 ?></td>
                            <td><?php echo $emerito ?></td>
                          </tr>
                          <tr>
                            <td>Hombres</td>
                            <td><?php echo $candidatoM ?></td>
                            <td><?php echo $nivel1M ?></td>
                            <td><?php echo $nivel2M ?></td>
                            <td><?php echo $nivel3M ?></td>
                            <td><?php echo $emeritoM ?></td>
                          </tr>
                          <tr>
                            <td>Mujeres</td>
                            <td><?php echo $candidatoF ?></td>
                            <td><?php echo $nivel1F ?></td>
                            <td><?php echo $nivel2F ?></td>
                            <td><?php echo $nivel3F ?></td>
                            <td><?php echo $emeritoF ?></td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!--Two-->
          <!-- Inicia SQL -->
          <?php
          // contador total
          $sql = "SELECT * FROM `academicosprofesor`";
          $res = mysqli_query($conexion, $sql);
          $contador = mysqli_num_rows($res);

          //
          // contador especialidad
          $sql2 = "SELECT * FROM `academicosprofesor` WHERE gradoAcademico  = 'Especialidad'";
          $res2 = mysqli_query($conexion, $sql2);
          $especialidad = mysqli_num_rows($res2);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE gradoAcademico = 'Especialidad' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $especialidadF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE gradoAcademico = 'Especialidad' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $especialidadM = mysqli_num_rows($resM);
          //

          //
          // contador Especialidad Medica
          // $sql3 = "SELECT * FROM `academicosprofesor` WHERE gradoAcademico  = 'Candidato'";
          // $res3 = mysqli_query($conexion, $sql3);
          // $eMedica = mysqli_num_rows($res3);
          // // contador de mujeres
          // $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE gradoAcademico = 'Candidato' AND sexo = 'Femenino'";
          // $resF = mysqli_query($conexion, $sqlF);
          // $eMedicaF = mysqli_num_rows($resF);
          // //contador de hombres
          // $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE gradoAcademico = 'Candidato' AND sexo = 'Masculino'";
          // $resM = mysqli_query($conexion, $sqlM);
          // $eMedicaM = mysqli_num_rows($resM);
          //

          //
          // contador Maestria
          $sql4 = "SELECT * FROM `academicosprofesor` WHERE gradoAcademico = 'Maestria'";
          $res4 = mysqli_query($conexion, $sql4);
          $maestria = mysqli_num_rows($res4);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE gradoAcademico = 'Maestria' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $maestriaF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE gradoAcademico = 'Maestria' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $maestriaM = mysqli_num_rows($resM);
          //

          //
          // contador Doctorado
          $sql5 = "SELECT * FROM `academicosprofesor` WHERE gradoAcademico  = 'Doctorado'";
          $res5 = mysqli_query($conexion, $sql5);
          $doctorado = mysqli_num_rows($res5);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE gradoAcademico = 'Doctorado' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $doctoradoF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE gradoAcademico = 'Doctorado' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $doctoradoM = mysqli_num_rows($resM);
          //

          //
          // // contador Posdoctorado
          // $sql6 = "SELECT * FROM `academicosprofesor` WHERE sni  = 'Ninguno'";
          // $res6 = mysqli_query($conexion, $sql6);
          // $emerito = mysqli_num_rows($res6);
          // // contador de mujeres
          // $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Ninguno' AND sexo = 'Femenino'";
          // $resF = mysqli_query($conexion, $sqlF);
          // $emeritoF = mysqli_num_rows($resF);
          // //contador de hombres
          // $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE sni = 'Ninguno' AND sexo = 'Masculino'";
          // $resM = mysqli_query($conexion, $sqlM);
          // $emeritoM = mysqli_num_rows($resM);
          // //
          ?>
          <!-- Terminar SQL -->

          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseTwo">
                Grados Académicos
              </a>
            </div>
            <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">
                <div class="row">

                  <div class="col">
                    <br>
                    <label class="col-form-label">Cantidad de profesores por nivel académico en posgrados</label>
                    <div class="table-responsive">
                      <table class="table table-bordered table-striped table-hover">
                        <thead>
                          <tr>
                            <th scope="col">Total</th>
                            <th scope="col">Especialidad</th>
                            <th scope="col">Especialidad Médica</th>
                            <th>Maestría</th>
                            <th scope="col">Doctorado</th>
                            <th scope="col">Posdoctorado</th>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td><?php echo $contador ?></td>
                            <td><?php echo $especialidad ?></td>
                            <td>-</td>
                            <td><?php echo $maestria ?></td>
                            <td><?php echo $doctorado ?></td>
                            <td>-</td>
                          </tr>
                          <tr>
                            <td>Hombres</td>
                            <td><?php echo $especialidadM ?></td>
                            <td>-</td>
                            <td><?php echo $maestriaM ?></td>
                            <td><?php echo $doctoradoM ?></td>
                            <td>-</td>
                          </tr>
                          <tr>
                            <td>Mujeres</td>
                            <td><?php echo $especialidadF ?></td>
                            <td>-</td>
                            <td><?php echo $maestriaF ?></td>
                            <td><?php echo $doctoradoF ?></td>
                            <td>-</td>
                          </tr>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!--Three-->

          <!-- Inicia SQL -->
          <?php
          // contador total
          $sql = "SELECT * FROM `academicosprofesor`";
          $res = mysqli_query($conexion, $sql);
          $contador = mysqli_num_rows($res);

          //
          // contador Area I
          $sql2 = "SELECT * FROM `academicosprofesor` WHERE areaEstudios = 'I.Físico-Matemáticas y Ciencias de la Tierra'";
          $res2 = mysqli_query($conexion, $sql2);
          $areaI = mysqli_num_rows($res2);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'I.Físico-Matemáticas y Ciencias de la Tierra' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $areaIF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'I.Físico-Matemáticas y Ciencias de la Tierra' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $areaIM = mysqli_num_rows($resM);
          //

          //
          //contador Area II
          $sql3 = "SELECT * FROM `academicosprofesor` WHERE areaEstudios  = 'II.Biología y Química'";
          $res3 = mysqli_query($conexion, $sql3);
          $areaII = mysqli_num_rows($res3);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'II.Biología y Química' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $areaIIF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'II.Biología y Química' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $areaIIM = mysqli_num_rows($resM);
          //

          //
          // contador area III
          $sql4 = "SELECT * FROM `academicosprofesor` WHERE areaEstudios = 'III.Medicina y Ciencias de la Salud'";
          $res4 = mysqli_query($conexion, $sql4);
          $areaIII = mysqli_num_rows($res4);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'III.Medicina y Ciencias de la Salud' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $areaIIIF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'III.Medicina y Ciencias de la Salud' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $areaIIIM = mysqli_num_rows($resM);
          //

          //
          // contador area IV
          $sql5 = "SELECT * FROM `academicosprofesor` WHERE areaEstudios  = 'IV.Ciencias de la Conducta y la Educación'";
          $res5 = mysqli_query($conexion, $sql5);
          $areaIV = mysqli_num_rows($res5);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'IV.Ciencias de la Conducta y la Educación' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $areaIVF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'IV.Ciencias de la Conducta y la Educación' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $areaIVM = mysqli_num_rows($resM);
          //

          //
          // contador area V
          $sql6 = "SELECT * FROM `academicosprofesor` WHERE areaEstudios  = 'V.Humanidades'";
          $res6 = mysqli_query($conexion, $sql6);
          $areaV = mysqli_num_rows($res6);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'V.Humanidades' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $areaVF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'V.Humanidades' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $areaVM = mysqli_num_rows($resM);
          //

          //
          // contador area VI
          $sql6 = "SELECT * FROM `academicosprofesor` WHERE areaEstudios  = 'VI.Ciencias Sociales'";
          $res6 = mysqli_query($conexion, $sql6);
          $areaVI = mysqli_num_rows($res6);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'VI.Ciencias Sociales' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $areaVIF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'VI.Ciencias Sociales' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $areaVIM = mysqli_num_rows($resM);
          //

          //
          // contador area VII
          $sql6 = "SELECT * FROM `academicosprofesor` WHERE areaEstudios  = 'VII.Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas'";
          $res6 = mysqli_query($conexion, $sql6);
          $areaVII = mysqli_num_rows($res6);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'VII.Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $areaVIIF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'VII.Ciencias de Agricultura, Agropecuarias, Forestales y de Ecosistemas' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $areaVIIM = mysqli_num_rows($resM);
          //

          //
          // contador area VIII
          $sql6 = "SELECT * FROM `academicosprofesor` WHERE areaEstudios  = 'VIII.Ingenierías y Desarrollo Tecnológico'";
          $res6 = mysqli_query($conexion, $sql6);
          $areaVIII = mysqli_num_rows($res6);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'VIII.Ingenierías y Desarrollo Tecnológico' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $areaVIIIF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'VIII.Ingenierías y Desarrollo Tecnológico' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $areaVIIIM = mysqli_num_rows($resM);
          //

          // contador area IX
          $sql6 = "SELECT * FROM `academicosprofesor` WHERE areaEstudios  = 'IX.Interdisciplinaria'";
          $res6 = mysqli_query($conexion, $sql6);
          $areaIX = mysqli_num_rows($res6);
          // contador de mujeres
          $sqlF = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'IX.Interdisciplinaria' AND sexo = 'Femenino'";
          $resF = mysqli_query($conexion, $sqlF);
          $areaIXF = mysqli_num_rows($resF);
          //contador de hombres
          $sqlM = "SELECT a.profid, b.sexo FROM academicosprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE areaEstudios = 'IX.Interdisciplinaria' AND sexo = 'Masculino'";
          $resM = mysqli_query($conexion, $sqlM);
          $areaIXM = mysqli_num_rows($resM);
          //
          ?>
          <!-- Terminar SQL -->

          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseFour">
                Área de estudio
              </a>
            </div>
            <div id="collapseFour" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">

                <div class="col">
                  <br>
                  <label class="col-form-label">Área de estudio de los profesores por niveles
                  </label>

                  <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                      <thead>
                        <tr>
                          <th scope="col">Total</th>
                          <th scope="col">Area I</th>
                          <th scope="col">Area II</th>
                          <th>Área III</th>
                          <th scope="col">Área IV</th>
                          <th scope="col">Área V</th>
                          <th>Área VI</th>
                          <th>Área VII</th>
                          <th>Área VIII</th>
                          <th>Área IX</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><?php echo $contador ?></td>
                          <td><?php echo $areaI ?></td>
                          <td><?php echo $areaII ?></td>
                          <td><?php echo $areaIII ?></td>
                          <td><?php echo $areaIV ?></td>
                          <td><?php echo $areaV ?></td>
                          <td><?php echo $areaVI ?></td>
                          <td><?php echo $areaVII ?></td>
                          <td><?php echo $areaVIII ?></td>
                          <td><?php echo $areaIX ?></td>
                        </tr>
                        <tr>
                          <td>Hombres</td>
                          <td><?php echo $areaIM ?></td>
                          <td><?php echo $areaIIM ?></td>
                          <td><?php echo $areaIIIM ?></td>
                          <td><?php echo $areaIVM ?></td>
                          <td><?php echo $areaVM ?></td>
                          <td><?php echo $areaVIM ?></td>
                          <td><?php echo $areaVIIM ?></td>
                          <td><?php echo $areaVIIIM ?></td>
                          <td><?php echo $areaIXM ?></td>
                        </tr>
                        <tr>
                          <td>Mujeres</td>
                          <td><?php echo $areaIF ?></td>
                          <td><?php echo $areaIIF ?></td>
                          <td><?php echo $areaIIIF ?></td>
                          <td><?php echo $areaIVF ?></td>
                          <td><?php echo $areaVF ?></td>
                          <td><?php echo $areaVIF ?></td>
                          <td><?php echo $areaVIIF ?></td>
                          <td><?php echo $areaVIIIF ?></td>
                          <td><?php echo $areaIXF ?></td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Inicio de Dedicacion de Posgrados -->

          <!-- SQL -->

          <?php
          //Contador de laborales Profesores
           $sql = "SELECT * FROM `laboralesprofesor`";
           $res = mysqli_query($conexion, $sql);
           $conLabPro = mysqli_num_rows($res);
           //Termina Contador

           // Contador Tiempo Completo
          $sql = "SELECT * FROM `laboralesprofesor` WHERE tiempoPosgrado  = 'Tiempo Completo'";
          $res = mysqli_query($conexion, $sql);
          $tiempoC = mysqli_num_rows($res);
          // Contador de mujeres
          $sql = "SELECT a.profid, b.sexo FROM laboralesprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE tiempoPosgrado = 'Tiempo Completo' AND sexo = 'Femenino'";
          $res = mysqli_query($conexion, $sql);
          $tiempoC_F = mysqli_num_rows($res);
          // Contador de hombres
          $sql = "SELECT a.profid, b.sexo FROM laboralesprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE tiempoPosgrado = 'Tiempo Completo' AND sexo = 'Masculino'";
          $res = mysqli_query($conexion, $sql);
          $tiempoC_M = mysqli_num_rows($res);
           // Termina contador Tiempo Completo

            // Contador Tiempo Parcial
          $sql = "SELECT * FROM `laboralesprofesor` WHERE tiempoPosgrado  = 'Tiempo Parcial'";
          $res = mysqli_query($conexion, $sql);
          $tiempoP = mysqli_num_rows($res);
          // Contador de mujeres
          $sql = "SELECT a.profid, b.sexo FROM laboralesprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE tiempoPosgrado = 'Tiempo Parcial' AND sexo = 'Femenino'";
          $res = mysqli_query($conexion, $sql);
          $tiempoP_F = mysqli_num_rows($res);
          // Contador de hombres
          $sql = "SELECT a.profid, b.sexo FROM laboralesprofesor a INNER JOIN profesores b on a.profid = b.profid WHERE tiempoPosgrado = 'Tiempo Parcial' AND sexo = 'Masculino'";
          $res = mysqli_query($conexion, $sql);
          $tiempoP_M = mysqli_num_rows($res);
           // Termina contador Tiempo Parcial

           ?>
          <!-- Termina SQL -->
          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseFive">
                Dedicación al Posgrados
              </a>
            </div>
            <div id="collapseFive" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">

                <div class="col">
                  <br>
                  <label class="col-form-label">Dedicacion al posgrado </label>

                  <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                      <thead>
                        <tr>
                          <th scope="col">Total</th>
                          <th scope="col">T. Completo</th>
                          <th scope="col">T. Parcial</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><?php echo $conLabPro ?></td>
                          <td><?php echo $tiempoC ?></td>
                          <td><?php echo $tiempoP ?></td>
                          
                        </tr>
                        <tr>
                          <td>Hombres</td>
                          <td><?php echo $tiempoC_M ?></td>
                          <td><?php echo $tiempoP_M ?></td>
                          
                        </tr>
                        <tr>
                          <td>Mujeres</td>
                          <td><?php echo $tiempoC_F ?></td>
                          <td><?php echo $tiempoP_F ?></td>
                          
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Termina dedicacion al posgrado -->


          <!-- Inicio de Nacionalidad de profesores -->

          <!-- SQL -->

          <?php
          //Contador de Nacionalidad de profesores
           $sql = "SELECT * FROM `profesores`";
           $res = mysqli_query($conexion, $sql);
           $conPro = mysqli_num_rows($res);
           //Termina Contador

           // Contador Nacionalidad Mexicana
          $sql = "SELECT * FROM `profesores` WHERE nacionalidad  = 'Mexicana'";
          $res = mysqli_query($conexion, $sql);
          $NaciM = mysqli_num_rows($res);
          // Contador de mujeres
          $sql = "SELECT * FROM profesores WHERE nacionalidad = 'Mexicana' AND sexo = 'Femenino'";
          $res = mysqli_query($conexion, $sql);
          $NaciM_F = mysqli_num_rows($res);
          // Contador de hombres
          $sql = "SELECT * FROM profesores WHERE nacionalidad = 'Mexicana' AND sexo = 'Masculino'";
          $res = mysqli_query($conexion, $sql);
          $NaciM_M = mysqli_num_rows($res);
           // Termina contador Nacionalidad Mexicana

            // Contador Nacionalidad Extranjera
          $sql = "SELECT * FROM `profesores` WHERE nacionalidad  = 'Extranjera'";
          $res = mysqli_query($conexion, $sql);
          $NaciE = mysqli_num_rows($res);
          // Contador de mujeres
          $sql = "SELECT * FROM profesores WHERE nacionalidad = 'Extranjera' AND sexo = 'Femenino'";
          $res = mysqli_query($conexion, $sql);
          $NaciE_F = mysqli_num_rows($res);
          // Contador de hombres
          $sql = "SELECT * FROM profesores WHERE nacionalidad = 'Extranjera' AND sexo = 'Masculino'";
          $res = mysqli_query($conexion, $sql);
          $NaciE_M = mysqli_num_rows($res);
           // Termina contador Nacionaliadd Extranjera

           ?>
          <!-- Termina SQL -->
          <div class="card">
            <div class="card-header">
              <a class="btn" data-bs-toggle="collapse" href="#collapseSix">
                Nacionalidad
              </a>
            </div>
            <div id="collapseSix" class="collapse" data-bs-parent="#accordion">
              <div class="card-body">

                <div class="col">
                  <br>
                  <label class="col-form-label">Nacionalidad de Profesor </label>

                  <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover">
                      <thead>
                        <tr>
                          <th scope="col">Total</th>
                          <th scope="col">Mexicana</th>
                          <th scope="col">Extranjera</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td><?php echo $conPro ?></td>
                          <td><?php echo $NaciM ?></td>
                          <td><?php echo $NaciE ?></td>
                          
                        </tr>
                        <tr>
                          <td>Hombres</td>
                          <td><?php echo $NaciM_M ?></td>
                          <td><?php echo $NaciE_M ?></td>
                          
                        </tr>
                        <tr>
                          <td>Mujeres</td>
                          <td><?php echo $NaciM_F ?></td>
                          <td><?php echo $NaciE_F ?></td>
                          
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <!-- Termina Nacionalidad de profesores -->
        </div>
        <!--five
<div class="card">
      <div class="card-header">
        <a class="btn" data-bs-toggle="collapse" href="#collapseFive">
          Región
        </a>
      </div>
      <div id="collapseFive" class="collapse" data-bs-parent="#accordion">
        <div class="card-body">
          <div class="row">
          <div class="col">                                       
          <div class="form-group">
           <label class="col-form-label">Elige la región de los posgrados a cuantificar</label>
           <form>
            <select class="form-select">
                <option>Seleccionar...</option>
                <option>Acapulco</option>
                <option>Centro</option>
                <option>Costa Chica</option>
                <option>Costa Grande</option>
                <option>Norte</option>
                <option>Montaña</option>
                <option>Tierra Caliente</option>
                <option>Sierra</option>
            </select>
            </form>                                               
            </div>
            </div>
           <div class="col">                                            
             <br>
            <label>Indicador</label><br>
            <label>Cantidad</label>
        </div>
          </div>
          </div>
        </div>
      </div>-->
        <!--final-->


      </div>
    </div>
  </div>
  </div>
</body>

</html>