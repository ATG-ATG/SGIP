<?php

include_once '../conexion/bdmysql.php';
class Ptc {

    
    function __construct(){

    }

    public function obtenePtcs(){
        $bd = new bdmysql();
        $conex = $bd->getConexion();
       //  print_r($conex);
       $consulta = 'SELECT * FROM empleadostc WHERE 1 ORDER BY nomtotal';
       $result = $conex->query($consulta);
       if ($result){
           return $result;
       }
       else {
           print "Ocurrio un error al realizar consulta";
       }
       $conex->close();

    }

    
    public function obtenerPtcporNum($numero){
        $bd = new bdmysql();
        $conex = $bd->getConexion();
       //  print_r($conex);
       $consulta = "SELECT * FROM empleadostc WHERE numero=$numero";
       $result = $conex->query($consulta);
       if ($result){
           return $result;
       }
       else {
           print "<h3> Ocurrio un error al realizar consulta </h3> ";
       }
       $conex->close();

    }

}

?>