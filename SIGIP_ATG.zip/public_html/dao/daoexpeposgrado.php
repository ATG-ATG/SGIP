<?php
include_once '../conexion/bdmysql.php';
// include_once 'includes/php-pagination-class.php';
class Expediente {
    // private $conex;
    function __construct() {
        
    }
    
    function obtenerExpediente($filtro){
        $bd = new bdmysql();
        $conex = $bd->getConexion();
        $consulta = "select * from expeposgrado ";
        if (!empty($filtro) ){
                $consulta .=" WHERE idposgrados = $filtro ORDER BY archivo";
        }
        $resul = mysqli_query($conex, $consulta) or die (" Ocurrio un error al realizar consulta");
        return $resul;
    }
    
	function obtenerTotalExpe($filtro){ // no se usa
        $bd = new bdmysql();
        $conex = $bd->getConexion();
        $consulta = "select noemplexpe, count(*) as totalexpe from expediente group by noemplexpe order by noemplexpe  ";
        if (!empty($filtro) ){
                $consulta .=" WHERE noemplexpe = $filtro";
        }
        $resul = mysqli_query($conex, $consulta) or die (" Ocurrio un error al realizar consulta");
        return $resul;
    }
            
    function obtenerExpeporTipDoc($filtro){ // no se usa
       $bd = new bdmysql();
        $conex = $bd->getConexion();
        $consulta = "select * from expediente ";
        if (!empty($filtro) ){
                $consulta .=" WHERE tipoexpe = $filtro ORDER BY tipoexpe";
        }
        $resul = mysqli_query($conex, $consulta) or die (" Ocurrio un error al realizar consulta");
        return $resul;
    }       
    
    function insertarExpediente($idposgrados, $archivo) {
        $bd = new bdmysql();
        $conex = $bd->getConexion();
        $consulta = "INSERT INTO expeposgrado (idposgrados, archivo) VALUES ($idposgrados, '$archivo') ";
        $resul = mysqli_query($conex, $consulta) or die ("Ocurrio un error al tratar de insertar registro");
        if($resul)
        {
            return "OK";
        }
        else
        {
            return "Ha ocurrido un error al insertar un registro";
        }
        
    }
    function actualizarUsuario($idexpe, $noemplexpe, $tipoexpe, $descriexpe, $archiexpe, $tamaexpe) { //no se usa
        $bd2 = new bdmysql();
        $conex2 = $bd2->getConexion();
        $consulta2= "UPDATE expediente SET tipoexpe='$tipoexpe', descriexpe='$descriexpe', archiexpe='$archiexpe', tamaexpe=$tamaexpe WHERE idexpe =$idexpe";
        $resul2 = mysqli_query($conex2, $consulta2) or die ("Ocurrio un error");
         if($resul2)
        {
            echo "ok";
            
        }
        else
        {
            echo "Ha ocurrido un error al intentar guardar cambios";
        }
          
    
    }
    
    function borrarExpediente($idexpe) {
        
        $bd = new bdmysql();
        $conex = $bd->getConexion();
        $consulta3= "DELETE FROM expeposgrado WHERE idexpeposgrado='$idexpe' ";
        $resul3 = mysqli_query($conex, $consulta3) or die ("Ocurrio un error al tratar de eliminar un registro");
        if($resul3)
        {
            return "OK";
            
        }
        else
        {
            return "Ha ocurrido un error al intentar eliminar los datos de la BD";
        }
        
    }
      
}
