<?php

include_once 'conexion/bdmysql.php';
class User {

    
    function __construct(){

    }

    public function obtenerUsers(){
        $bd = new bdmysql();
        $conex = $bd->getConexion();
       //  print_r($conex);
       $consulta = 'SELECT * FROM loginusuarios WHERE 1 ORDER BY iduser';
       $result = $conex->query($consulta);
       if ($result){
           return $result;
       }
       else {
           print "Ocurrio un error al realizar consulta";
       }
       $conex->close();

    }

    public function agregarUser($data){
       
 
        $bd = new bdmysql();
        $conex = $bd->getConexion();
       //  print_r($conex);
      
       $conex->close();

    }

    public function obtenerUserporId($id){
        $bd = new bdmysql();
        $conex = $bd->getConexion();
       //  print_r($conex);
       $consulta = "SELECT * FROM loginusuarios WHERE userid = $id";
       $result = $conex->query($consulta);
       if ($result){
           return $result;
       }
       else {
           print "<h3> Ocurrio un error al realizar consulta </h3> ";
       }
       $conex->close();

    }

    public function actualizarUser($data){
              
        $bd = new bdmysql();
        $conex = $bd->getConexion();
       //  print_r($conex);
       
      
       $conex->close();

    }

    public function borrarUser($id){
        
        $bd = new bdmysql();
        $conex = $bd->getConexion();
       //  print_r($conex);
       
       $consulta = "DELETE FROM loginusuarios  where  userid = $id";
	   // print $consulta;
       // $result = $conex->query($consulta);
       /*
       if ( $conex->query($consulta)){
           header('Location: listarsnis.php?codigo=3');
       }
       else {
           print "Ocurrio un error al tratar de borrar registro " . $conex->error;
       }
       */
       $conex->close();

    }

    public function ObtenerUserPorNomuser($usernom){
        $bd = new bdmysql();
        $conex = $bd->getConexion();
       //  print_r($conex);
       $consulta = "SELECT * FROM loginusuarios WHERE usernom = $usernom";
       $result = $conex->query($consulta);
       if ($result){
           return $result;
       }
       else {
           // print "<h3> Ocurrio un error al realizar consulta </h3> ";
            $dato['status'] = 'ERROR';
            $dato['info']   = 'Ocurrio un error al realizar consulta';
            print_r(json_encode($dato));
       }
       $conex->close();

    }


    public function validarUser($user, $pass){
       // $user = $reg['user'];
       $user = $user;
       //  $userpass = $reg['passuser'];
       $userpass = $pass;
       try{
            $bd = new bdmysql();
             $conex = $bd->getConexion();
       }
       catch (Exception $e) {
            echo "Ocurrio un error: ".$e->getMessage(), "\n";
            exit();
        }
       //  print_r($conex);
      
       
       $consulta = "SELECT * FROM loginusers WHERE user = '$user' and passuser = '$userpass'";
       // print $consulta;
       $result = $conex->query($consulta);
       if ($result){
           return $result;
       }
       else {
           // print "<h3> Ocurrio un error al realizar consulta </h3> ";
            
            $dato['status'] = 'ERROR';
            $dato['info']   = 'Ocurrio un error al realizar consulta';
            print_r(json_encode($dato));
       }
       $conex->close();

    }



}

?>