<!DOCTYPE html>

<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Indicadores Posgrados DP</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    </head>
    
    <body>
        <div class="container">
        <img src="../img/INDICADORES.jpg" height="300" width="1600" class="float-start img-fluid" alt="logo posgrado">
        
        <!--menú superior-->
                <div class="row">
                    <div class="col-sm-2"></div>
                    <div class="col-sm-6 text-center"></div>
                    <ul class="nav justify-content-end" class="nav nav-tabs">
                        <li class="nav-item">
                        <li class="nav-item">
                        <a class="nav-link active" href="/index.php">Inicio</a>
                            </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/principales/generalesProfesor.php">Profesores</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/principales/generalesPosgrados.php">Posgrados</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/principales/generalesEstudiantes.php">Estudiantes</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" href="#">Administrativo</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="/indicador/indicador.php">Indicadores</a>
                        </li>
                        <li class="nav-item">
                                <a class="nav-link" href="/login.php">Salir</a>
                            </li>
                    </ul>
                </div> 
        </div>                               
    </body>
</html>