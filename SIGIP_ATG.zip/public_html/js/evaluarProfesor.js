//---------------------------------------------------------------------NACIONALIDAD DATOS PERSONALES---------------------------------------------------------------------------
function mostrarOpciones() {
    var nacionalidadSelect = document.getElementById("nacionalidad");//OBTIENE LO QUE SE SELECCIONO EN NACIONALIDAD(MEXICANA O EXTRANJERA)
    var opcionesEstados = document.getElementById("opcionesEstados");//OBTIENE LOS DATOS DE LOS ESTADOS
    var opcionesPaises = document.getElementById("opcionesPaises");//OBTIENE LOS DATOS DE LOS PAISES

    opcionesEstados.style.display = "none";//EL CAMPO PARA SELECCIONAR LOS ESTADOS ESTA OCULTO
    opcionesPaises.style.display = "none";//EL CAMPO PARA LOS PAISES ESTA OCULTO
    ocultarCampoOtroPais();//METODO PARA OCULTAR AMBOS 

    if (nacionalidadSelect.value === "Mexicana") {//CONDICIONAL, SI SE ELIGE LA NACIONALIDAD MEXICANA
        opcionesEstados.style.display = "block";//SE MUESTRA EL CAMPO DE LOS ESTADOS
    } else if (nacionalidadSelect.value === "Extranjera") {//SINO DE ELIGIO MEXICANA, ENTONCES ES EXTRANJERA
        opcionesPaises.style.display = "block";//SE MUESTRA EL CAMPO DE LOS PAISES
    }
}

function mostrarOtroPais() {//FUNCION DE MOSTRAR PAISES QUE ESTA EN onchange="mostrarOtroPais2()" DE LOS SELECT´S
    var paisesSelect = document.getElementById("pais");//SE OBTIENE EL DATO ELEGIDO 
    var campoOtroPais = document.getElementById("campoOtroPais");//SE OBTIENE EL DATO DE UN CAMPO ADICIONAL, UN PAIS QUE NO ESTE EN LA LISTA

    if (paisesSelect.value.toLowerCase() === "otro") {//CONDICIONAL, SI SE ELIGIO EN "otro" EN EL SELECT
        campoOtroPais.style.display = "block";//SE MUESTRA EL CAMPO PARA ESCRIBIR EL NOMBRE DEL PAIS
    } else {//CASO CONTRARIO
        ocultarCampoOtroPais();//SE OCULTA EL CAMPO DE OTRO PAIS
    }
}

function ocultarCampoOtroPais() {//FUNCION PARA OCULTAR EL CAMPO DE ESCRIBIR PAIS
    var campoOtroPais = document.getElementById("campoOtroPais");//SE OBTIENE EL DATO
    campoOtroPais.style.display = "none";//SE OCULTA EL CAMPO
}


//-------------------------------------------------------------------------NACIONALIDAD DATOS ACADEMICOS--------------------------------------------------------------------------------------------------
function mostrarOpciones2() {
    var nacionalidadSeleccionada = document.getElementById("nacionalidad2");
    var opcionEstados = document.getElementById("opcionEstados");
    var opcionPaises = document.getElementById("opcionPaises");

    opcionEstados.style.display = "none";
    opcionPaises.style.display = "none";
    ocultarCampoOtroPais2();

    if (nacionalidadSeleccionada.value === "Mexicana") {
        opcionEstados.style.display = "block";
    } else if (nacionalidadSeleccionada.value === "Extranjera") {
        opcionPaises.style.display = "block";
    }
}

function mostrarOtroPais2() {
    var paisesSeleccionado = document.getElementById("pais2");
    var campoOtroPais2 = document.getElementById("campoOtroPais2");

    if (paisesSeleccionado.value.toLowerCase() === "otro") {
        campoOtroPais2.style.display = "block";
    } else {
        ocultarCampoOtroPais2();
    }
}

function ocultarCampoOtroPais2() {
    var campoOtroPais2 = document.getElementById("campoOtroPais2");
    campoOtroPais2.style.display = "none";
}
//--------------------------------------------------------------------------OBTENCION ULTIMO GRADO DATOS LABORALES-------------------------------------------------------------------------------------------------
function mostrarOtraInst() {
    var instGrado = document.getElementById("instGrado");
    var campoOtraInst = document.getElementById("campoOtraInst"); // Corregido el ID

    if (instGrado.value.toLowerCase() === "otro") {
        campoOtraInst.style.display = "block";
    } else {
        ocultarCampoOtraInst();
    }
}

function ocultarCampoOtraInst() {
    var campoOtraInst = document.getElementById("campoOtraInst"); // Corregido el ID
    campoOtraInst.style.display = "none";
}

//------------------------------------5 nombres---------------------------------------
var contador = 0; // Inicializamos el contador en 0

    function posgrados() {
        var agregarDatos = document.getElementById("agregarDatosSelect");
        var campoOtroDatos = document.getElementById("campoOtroDatos");

        if (agregarDatos.value.toLowerCase() === "si" && contador < 5) {
            campoOtroDatos.style.display = "block";
            contador++;
        } else {
            ocultarCampoOtroDatos();
        }
    }

    function ocultarCampoOtroDatos() {
        var campoOtroDatos = document.getElementById("campoOtroDatos");
        campoOtroDatos.style.display = "none";
        contador = 0; // Reiniciar contador cuando se ocultan los campos
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------


