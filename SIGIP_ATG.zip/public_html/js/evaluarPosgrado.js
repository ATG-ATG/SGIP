function mostrarOtroTrabajo() {
    var paisesSelect = document.getElementById("tipoTrabajo");
    var campoOtroPais = document.getElementById("campoOtroTrabajo");

    if (paisesSelect.value.toLowerCase() === "otro") {
        campoOtroPais.style.display = "block";
    } else {
        ocultarCampoOtroTrabajo();
    }
}

function ocultarCampoOtroTrabajo() {
    var campoOtroPais = document.getElementById("campoOtroTrabajo");
    campoOtroPais.style.display = "none";
}

//------------------------------FUNCION CUANDO SE SELECCIONA OTRO ASISTENTE(ASISTENTE)--------------------------------------------------------------------------------------
function mostrarOtroAsistente() {
    var paisesSelect = document.getElementById("otroAsistente");
    var campoOtroPais = document.getElementById("campoOtroAsistente");

    if (paisesSelect.value.toLowerCase() === "si") {
        campoOtroPais.style.display = "block";
    } else {
        ocultarCampoOtroAsistente();
    }
}

function ocultarCampoOtroAsistente() {
    var campoOtroAsistente = document.getElementById("campoOtroAsistente");
    campoOtroAsistente.style.display = "none";
}
//-----------------------------FUNCION DEL TRABAJO DENTRO DEL SEGUNDO ASISTENTE----------------------------------------------
function mostrarOtroTrabajo2() {
    var paisesSelect = document.getElementById("tipoTrabajo2");
    var campoOtroPais = document.getElementById("campoOtroTrabajo2");

    if (paisesSelect.value.toLowerCase() === "otro") {
        campoOtroPais.style.display = "block";
    } else {
        ocultarCampoOtroTrabajo2();
    }
}

function ocultarCampoOtroTrabajo2() {
    var campoOtroPais = document.getElementById("campoOtroTrabajo2");
    campoOtroPais.style.display = "none";
}
//-----------------------FUNCION DE OTRO POSGRADO--------------------------------------------------------------------------
function mostrarOtroPosgrado() {
    var paisesSelect = document.getElementById("otroAsistente");
    var campoOtroPais = document.getElementById("campoOtroAsistente");

    if (paisesSelect.value.toLowerCase() === "si") {
        campoOtroPais.style.display = "block";
    } else {
        ocultarCampoOtroAsistente();
    }
}

function ocultarCampoOtroAsistente() {
    var campoOtroAsistente = document.getElementById("campoOtroAsistente");
    campoOtroAsistente.style.display = "none";
}

//----------------------FUNCIONES PARA LA INSTANCIA EVALUADORA------------------------------------------------------------
function mostrarOtraInst() {
    var paisesSelect = document.getElementById("instPos");
    var campoSnp = document.getElementById("campoSnp");
    var campoSeip = document.getElementById("campoSeip");
    var campoCifrhs = document.getElementById("campoCifrhs");
    var campoOtraInst = document.getElementById("campoOtraInst");

    ocultarCampos();

    if (paisesSelect.value === "SNP(PNPC)") {
        campoSnp.style.display = "block";
    } else if (paisesSelect.value === "SEIP-UAgro") {
        campoSeip.style.display = "block";
    } else if (paisesSelect.value === "CIFRHS") {
        campoCifrhs.style.display = "block";
    } else if (paisesSelect.value === "otro") {
        campoOtraInst.style.display = "block";
    }
}

function ocultarCampos() {
    var campoSnp = document.getElementById("campoSnp");
    var campoSeip = document.getElementById("campoSeip");
    var campoCifrhs = document.getElementById("campoCifrhs");
    var campoOtraInst = document.getElementById("campoOtraInst");

    campoSnp.style.display = "none";
    campoSeip.style.display = "none";
    campoCifrhs.style.display = "none";
    campoOtraInst.style.display = "none";
}
//------------------------sede medico-------------------------------------------------------------------------------------
function gradoMedico() {
    var gradoSelect = document.getElementById("grado");
    var campoMedico = document.getElementById("campoMedico");

    console.log("Función gradoMedico() ejecutada"); // Agregando un mensaje de registro

    if (gradoSelect.value.trim().toLowerCase() === "especialidad médica") {
        campoMedico.style.display = "block";
        console.log("Campo visible");
    } else {
        ocultarCampoMedico();
        console.log("Campo oculto");
    }
}

function ocultarCampoMedico() {
    var campoMedico = document.getElementById("campoMedico");
    campoMedico.style.display = "none";
    console.log("Función ocultarCampoMedico() ejecutada"); // Agregando un mensaje de registro
}

//--------------------------actualizacion---------------------------------------------------------------------------------
function actualizacionhcu() {
    var actualizacion = document.getElementById("actualizacion");
    var campoOtroHcu = document.getElementById("campoOtroHcu");

    console.log("Función actualizacionhcu() activada"); // Mensaje de comprobación

    if (actualizacion.value.toLowerCase() === "si") {
        campoOtroHcu.style.display = "block";
        console.log("Campo visible"); // Mensaje si el campo se muestra
    } else {
        ocultarCampoOtroActualizacion();
        console.log("Campo oculto"); // Mensaje si el campo se oculta
    }
}

function ocultarCampoOtroActualizacion() {
    var campoOtroHcu = document.getElementById("campoOtroHcu");
    campoOtroHcu.style.display = "none";
}


