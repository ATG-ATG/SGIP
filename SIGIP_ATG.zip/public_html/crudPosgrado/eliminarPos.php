<?php
include('../conexion/conexion.php');
$id = $_REQUEST['id'];

$DeleteRegistro = "DELETE FROM generalposgrados WHERE idPosgrados='" . $id . "'";
mysqli_query($conexion, $DeleteRegistro);

$DeleteRegistro = "DELETE FROM evaluacionposgrado WHERE idPosgrados='" . $id . "'";
mysqli_query($conexion, $DeleteRegistro);

$DeleteRegistro = "DELETE FROM fichatecnicapos WHERE idPosgrados='" . $id . "'";
mysqli_query($conexion, $DeleteRegistro);

$DeleteRegistro = "DELETE FROM asistentepos WHERE idPosgrados='" . $id . "'";
mysqli_query($conexion, $DeleteRegistro);


header("location:../principales/generalesPosgrados.php?msg=3");

?>