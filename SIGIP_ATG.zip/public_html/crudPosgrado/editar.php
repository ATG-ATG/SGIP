
<?php
include('../conexion/conexion.php');
$id = $_POST['id'];
//-----------------------------Datos del Primer Acordeon (Datos Generales)--------------------->
$nombre =  mysqli_real_escape_string($conexion, $_POST['nombre']);//tipo texto
$numSPN =  mysqli_real_escape_string($conexion, $_POST['numSPN']);//tipo numerico
$numREG =  mysqli_real_escape_string($conexion, $_POST['numREG']);//tipo numerico
$grado =  mysqli_real_escape_string($conexion, $_POST['grado']);
$orientacion =  mysqli_real_escape_string($conexion, $_POST['orientacion']);
$areaEstudio =  mysqli_real_escape_string($conexion, $_POST['areaEstudio']);
$region =  mysqli_real_escape_string($conexion, $_POST['region']);
//$direccion = mysqli_real_escape_string($conexion, $_POST['direccion']);
$dependencia = mysqli_real_escape_string($conexion, $_POST['dependencia']);
$nombreCoord = mysqli_real_escape_string($conexion, $_POST['nombreCoord']);//tipo texto
$apellidoPCoord = mysqli_real_escape_string($conexion, $_POST['apellidoPCoord']);//tipo texto
$apellidoMCoord = mysqli_real_escape_string($conexion, $_POST['apellidoMCoord']);//tipo texto
$anioInicio = mysqli_real_escape_string($conexion, $_POST['anioInicio']);//tipo numerico
$inicioposg = mysqli_real_escape_string($conexion, $_POST['inicioposg']);//tipo numerico
$gradoCoord = mysqli_real_escape_string($conexion, $_POST['gradoCoord']);//tipo numerico

$correo = mysqli_real_escape_string($conexion, $_POST['correo']);
$telefono = mysqli_real_escape_string($conexion, $_POST['telefono']);
$estadoposgrado = mysqli_real_escape_string($conexion, $_POST['estadoposgrado']);

$pagWeb = mysqli_real_escape_string($conexion, $_POST['pagWeb']);
//obtencion de dato añadido
$sexo =  mysqli_real_escape_string($conexion, $_POST['sexo']);
//--------------------------Datos del Segundo Acordeon (Evaluacion)----------------------------------------------->

$ultEva =  mysqli_real_escape_string($conexion, $_POST['ultEva']);//tipo numerico
//--------------------------Datos del Tercer Acordeon (Ficha Tecnica)----------------------------------------------->
$periocidad =  mysqli_real_escape_string($conexion, $_POST['periocidad']);
$durPos =  mysqli_real_escape_string($conexion, $_POST['durPos']);
$credito =  mysqli_real_escape_string($conexion, $_POST['credito']);
//--------------------------Datos del Cuarto Acordeon (Asistentes)----------------------------------------------->
$nombreAsis = mysqli_real_escape_string($conexion, $_POST['nombreAsis']);//tipo texto
$apellidoPAsis = mysqli_real_escape_string($conexion, $_POST['apellidoPAsis']);//tipo texto
$apellidoMAsis = mysqli_real_escape_string($conexion, $_POST['apellidoMAsis']);//tipo texto
$correoAsis =  mysqli_real_escape_string($conexion, $_POST['correoAsis']);
$telefonoAsis =  mysqli_real_escape_string($conexion, $_POST['telefonoAsis']);//tipo numerico
/*abajo, dato para poder evaluar si es ese u otro dato, no modificar*/
$tipoTrabajo =  mysqli_real_escape_string($conexion, $_POST['tipoTrabajo']);//tipo de seleccion "otro"
/*arriba, dato para poder evaluar si es ese u otro dato, no modificar*/
$otroAsistente =  mysqli_real_escape_string($conexion, $_POST['otroAsistente']);



$actualizar_datos_generales = "";
$actualizar_evaluacion = "";
$actualizar_ficha_tecnica = "";
$actualizar_asistente = "";


//----------------------------------------------------------VALIDACIONES-----------------------------------------------------------
// Convertir la primera letra de cada palabra a mayúscula
//$nombre = ucwords(strtolower($nombre));

$nombreCoord = ucwords(strtolower($nombreCoord));
$apellidoPCoord = ucwords(strtolower($apellidoPCoord));
$apellidoMCoord = ucwords(strtolower($apellidoMCoord));//ucwords(primera letra en mayusculas), strtolower(las demas letras en minusculas)

// Validar que los datos no esten vacios en el primer acordeon
if (empty($nombre) || empty($nombreCoord) || empty($apellidoPCoord) || empty($apellidoMCoord)) {
        echo "Por favor, ingresa todos la información de los Datos Generales.";
        exit;
}
    
// Validar que la clave de trabajador sea de 6 dígitos
if (strlen($numSPN) !== 6 || !ctype_digit($numSPN)) {
        echo "La clave de trabajador debe tener 6 dígitos.";
        exit;
}
    
// Validar que la clave de trabajador sea de 6 dígitos
if (strlen($numREG) !== 6 || !ctype_digit($numREG)) {
        echo "La clave de trabajador debe tener 6 dígitos.";
        exit;
        
}
    
// Validar que el sexo sea uno de los valores permitidos (Masculino o Femenino)
if ($sexo !== 'Masculino' && $sexo !== 'Femenino') {
        echo "Selecciona una opción válida para el sexo.";
        exit;
}

// Validar que los años sea de 4 dígitos
if (strlen($anioInicio) !== 4 || !ctype_digit($anioInicio)) {
        echo "El año debe tener 4 dígitos.";
        exit;
}

// Validar que los años sea de 4 dígitos
if (strlen($inicioposg) !== 4 || !ctype_digit($inicioposg)) {
        echo "El año debe tener 4 dígitos.";
        exit;
}

$actualizar_datos_generales = "UPDATE generalposgrados SET nombre='" . $nombre . "',
                            numSPN ='" . $numSPN . "',
                            numREG ='" . $numREG . "', 
                            grado ='" . $grado . "', 
                            orientacion ='" . $orientacion . "', 
                            areaEstudio ='" . $areaEstudio . "',
                            region ='" . $region . "', 
                            dependencia ='" . $dependencia . "',
                            nombreCoord ='" . $nombreCoord ."',
                            apellidoPCoord ='" . $apellidoPCoord ."',
                            apellidoMCoord ='" . $apellidoMCoord ."',
                            gradoCoord ='".$gradoCoord . "',
                            sexo ='" . $sexo ."',
                            anioInicio ='" . $anioInicio ."',
                            inicioposg ='" . $inicioposg ."',
                            pagWeb ='" . $pagWeb ."',
                            correo ='" . $correo ."',
                            telefono ='" . $telefono ."',
                            estadoposgrado ='" . $estadoposgrado ."'
                            WHERE idPosgrados='" . $id . "'";

/*----------------------------------------------------------------Insercion del segundo acordeon(Evaluacion)--------------------------------------------*/

/*if (!isset($_FILES['doc']['name']) && !isset($_FILES['nucleoAcademico']['name'])) {
    echo "Los campos de archivo no están definidos en el formulario.";
} */

//Codigo oara validar si la "instancia evaladora del posgrado" es a las selecciadas o se ingreso el nombre de otra instancia
/*abajo, dato para poder evaluar si es ese u otro dato, no modificar*/
$instPos =  mysqli_real_escape_string($conexion, $_POST['instPos']);
/*arriba, dato para poder evaluar si es ese u otro dato, no modificar*/
$actualizacion =  mysqli_real_escape_string($conexion, $_POST['actualizacion']);
$inicioposg =  mysqli_real_escape_string($conexion, $_POST['inicioposg']);
if($instPos === 'otro'){
        $otraInst = mysqli_real_escape_string($conexion, $_POST['otraInst']);
        if($actualizacion == 'si'){
            $actualizar_evaluacion = "UPDATE evaluacionposgrado SET 
            instPos='otro',
            otraInst ='" . $otraInst . "',                
            actualizacion ='si',  
            anioAct =".(int)$anioAct.",  
            inicioposg ='" . $inicioposg . "',                
            ultEva ='" . $ultEva . "'                
            WHERE idPosgrados='" . $id . "'";
        }else{
            $actualizar_evaluacion = "UPDATE evaluacionposgrado SET 
            instPos='otro',
            otraInst ='" . $otraInst . "',                
            actualizacion ='no',  
            anioAct =".(int)$anioAct.",  
            inicioposg ='" . $inicioposg . "',                
            ultEva ='" . $ultEva . "'                
            WHERE idPosgrados='" . $id . "'";
        }
}else{
        if($actualizacion == 'si'){
                $anioAct =  mysqli_real_escape_string($conexion, $_POST['anioAct']);
                $actualizar_evaluacion = "UPDATE evaluacionposgrado SET 
                instPos ='" . $instPos . "',  
                otraInst = null,  
                actualizacion = 'si',  
                anioAct =".(int)$anioAct.",  
                inicioposg ='" . $inicioposg . "',                
                ultEva ='" . $ultEva . "'                
                WHERE idPosgrados='" . $id . "'";
        }else{
                $actualizar_evaluacion = "UPDATE evaluacionposgrado SET 
                instPos ='" . $instPos . "',             
                actualizacion ='no',  
                anioAct =".(int)$anioAct.",  
                inicioposg ='" . $inicioposg . "',                
                ultEva ='" . $ultEva . "'             
                WHERE idPosgrados='" . $id . "'";
        }
}

/*----------------------------------------------------------------FIN insercion del segundo acordeon(Evaluacion)--------------------------------------------*/

/*----------------------------------------------------------------INICIO Insercion del tercer acordeon(ficha tecnica)--------------------------------------------*/
if (empty($periocidad) || empty($durPos)) {
        echo "Por favor, ingresa todos los datos de la Ficha Tecnica.";
        exit;
}


$actualizar_ficha_tecnica = "UPDATE fichatecnicapos SET periocidad='" . $periocidad . "',
                            durPos ='" . $durPos . "', 
                            credito ='" . $credito . "'
                            WHERE idPosgrados='" . $id . "'";
/*----------------------------------------------------------------FIN Insercion del tercer acordeon(ficha tecnica)--------------------------------------------*/

/*----------------------------------------------------------------Insercion del cuarto acordeon(Asistentes)--------------------------------------------*/
if (empty($nombreAsis) || empty($apellidoPAsis) || empty($apellidoMAsis) || empty($apellidoMCoord)) {
        echo "Por favor, ingresa todos los datos de los Asistentes.";
        exit;
}

// Validar que el correo esté bien estructurado
else if (!filter_var($correoAsis, FILTER_VALIDATE_EMAIL)) {
        echo "El formato del correo electrónico es incorrecto.";
        exit;
}

if ($tipoTrabajo === 'otro') {
        $otroTrabajo = mysqli_real_escape_string($conexion, $_POST['otroTrabajo']);
        
        if ($otroAsistente === 'si') {
            $nombreAsis2 = mysqli_real_escape_string($conexion, $_POST['nombreAsis2']);
            $apellidoPAsis2 = mysqli_real_escape_string($conexion, $_POST['apellidoPAsis2']);
            $apellidoMAsis2 = mysqli_real_escape_string($conexion, $_POST['apellidoMAsis2']);
            $correoAsis2 = mysqli_real_escape_string($conexion, $_POST['correoAsis2']);
            $telefonoAsis2 = mysqli_real_escape_string($conexion, $_POST['telefonoAsis2']);
            
            $actualizar_asistente = "UPDATE asistentepos SET 
                nombreAsis='" . $nombreAsis . "',
                apellidoPAsis='" . $apellidoPAsis . "', 
                apellidoMAsis='" . $apellidoMAsis . "', 
                correoAsis='" . $correoAsis . "', 
                telefonoAsis='" . $telefonoAsis . "', 
                tipoTrabajo='" . $otroTrabajo . "',
                otroAsistente2='" . $otroAsistente . "',
                nombreAsis2='" . $nombreAsis2 . "',
                apellidoPAsis2='" . $apellidoPAsis2 . "', 
                apellidoMAsis2='" . $apellidoMAsis2 . "', 
                correoAsis2='" . $correoAsis2 . "', 
                telefonoAsis2='" . $telefonoAsis2 . "'
                WHERE idPosgrados='" . $id . "'";
        } else {
            $actualizar_asistente = "UPDATE asistentepos SET 
                nombreAsis='" . $nombreAsis . "',
                apellidoPAsis='" . $apellidoPAsis . "', 
                apellidoMAsis='" . $apellidoMAsis . "', 
                correoAsis='" . $correoAsis . "', 
                telefonoAsis='" . $telefonoAsis . "', 
                tipoTrabajo='" . $otroTrabajo . "', 
                otroAsistente2='" . $otroAsistente . "'
                WHERE idPosgrados='" . $id . "'";
        }
    } else {
        if ($otroAsistente === 'si') {
            $nombreAsis2 = mysqli_real_escape_string($conexion, $_POST['nombreAsis2']);
            $apellidoPAsis2 = mysqli_real_escape_string($conexion, $_POST['apellidoPAsis2']);
            $apellidoMAsis2 = mysqli_real_escape_string($conexion, $_POST['apellidoMAsis2']);
            $correoAsis2 = mysqli_real_escape_string($conexion, $_POST['correoAsis2']);
            $telefonoAsis2 = mysqli_real_escape_string($conexion, $_POST['telefonoAsis2']);
            
            $actualizar_asistente = "UPDATE asistentepos SET 
                nombreAsis='" . $nombreAsis . "',
                apellidoPAsis='" . $apellidoPAsis . "', 
                apellidoMAsis='" . $apellidoMAsis . "', 
                correoAsis='" . $correoAsis . "', 
                telefonoAsis='" . $telefonoAsis . "', 
                tipoTrabajo='" . $tipoTrabajo . "',
                otroAsistente2='" . $otroAsistente . "',
                nombreAsis2='" . $nombreAsis2 . "',
                apellidoPAsis2='" . $apellidoPAsis2 . "', 
                apellidoMAsis2='" . $apellidoMAsis2 . "', 
                correoAsis2='" . $correoAsis2 . "', 
                telefonoAsis2='" . $telefonoAsis2 . "'
                WHERE idPosgrados='" . $id . "'";
        } else {
            $actualizar_asistente = "UPDATE asistentepos SET 
                nombreAsis='" . $nombreAsis . "',
                apellidoPAsis='" . $apellidoPAsis . "', 
                apellidoMAsis='" . $apellidoMAsis . "', 
                correoAsis='" . $correoAsis . "', 
                telefonoAsis='" . $telefonoAsis . "', 
                tipoTrabajo='" . $tipoTrabajo . "',
                otroAsistente2='" . $otroAsistente . "'
                WHERE idPosgrados='" . $id . "'";
        }
    }
    

/*----------------------------------------------------------------FIN Insercion del cuarto acordeon(Asistentes)--------------------------------------------*/



$inserInmueble = mysqli_query($conexion, $actualizar_datos_generales);
$inserInmueble2 = mysqli_query($conexion, $actualizar_evaluacion);
$inserInmueble3 = mysqli_query($conexion, $actualizar_ficha_tecnica);
$inserInmueble4 = mysqli_query($conexion, $actualizar_asistente);

//-----------------------------Obtencion de Datos Academicos del Profesor--------------------->



header("Location:../principales/generalesPosgrados.php?msg=2");

?>
