<?php
include('../conexion/conexion.php');
//-----------------------------Datos del Primer Acordeon (Datos Generales)--------------------->
$nombre =  mysqli_real_escape_string($conexion, $_POST['nombre']);//tipo texto
$numSPN =  mysqli_real_escape_string($conexion, $_POST['numSPN']);//tipo numerico
$numREG =  mysqli_real_escape_string($conexion, $_POST['numREG']);//tipo numerico
$grado =  mysqli_real_escape_string($conexion, $_POST['grado']);
$orientacion =  mysqli_real_escape_string($conexion, $_POST['orientacion']);
$areaEstudio =  mysqli_real_escape_string($conexion, $_POST['areaEstudio']);
$region =  mysqli_real_escape_string($conexion, $_POST['region']);
//$direccion = mysqli_real_escape_string($conexion, $_POST['direccion']);
$dependencia = mysqli_real_escape_string($conexion, $_POST['dependencia']);
$nombreCoord = mysqli_real_escape_string($conexion, $_POST['nombreCoord']);//tipo texto
$apellidoPCoord = mysqli_real_escape_string($conexion, $_POST['apellidoPCoord']);//tipo texto
$apellidoMCoord = mysqli_real_escape_string($conexion, $_POST['apellidoMCoord']);//tipo texto
$anioInicio = mysqli_real_escape_string($conexion, $_POST['anioInicio']);//tipo numerico
$inicioposg = mysqli_real_escape_string($conexion, $_POST['inicioposg']);//tipo numerico
$gradoCoord = mysqli_real_escape_string($conexion, $_POST['gradoCoord']);//tipo numerico
$correo = mysqli_real_escape_string($conexion, $_POST['correo']);
$telefono = mysqli_real_escape_string($conexion, $_POST['telefono']);
$extension = mysqli_real_escape_string($conexion, $_POST['extension']);
$estadoposgrado = mysqli_real_escape_string($conexion, $_POST['estadoposgrado']);
$pagWeb = mysqli_real_escape_string($conexion, $_POST['pagWeb']);
//obtencion de dato añadido
$sexo =  mysqli_real_escape_string($conexion, $_POST['sexo']);
//--------------------------Datos del Segundo Acordeon (Evaluacion)----------------------------------------------->
//$doc = $_FILES['doc']['name'];
$ultEva =  mysqli_real_escape_string($conexion, $_POST['ultEva']);//tipo numerico
//$nucleoAcademico = $_FILES['nucleoAcademico']['name'];
//--------------------------Datos del Tercer Acordeon (Ficha Tecnica)----------------------------------------------->
$periocidad =  mysqli_real_escape_string($conexion, $_POST['periocidad']);
//$docft = $_FILES['docft']['name'];
$durPos =  mysqli_real_escape_string($conexion, $_POST['durPos']);
$credito =  mysqli_real_escape_string($conexion, $_POST['credito']);
//--------------------------Datos del Cuarto Acordeon (Asistentes)----------------------------------------------->
$nombreAsis = mysqli_real_escape_string($conexion, $_POST['nombreAsis']);//tipo texto
$apellidoPAsis = mysqli_real_escape_string($conexion, $_POST['apellidoPAsis']);//tipo texto
$apellidoMAsis = mysqli_real_escape_string($conexion, $_POST['apellidoMAsis']);//tipo texto
$correoAsis =  mysqli_real_escape_string($conexion, $_POST['correoAsis']);
$telefonoAsis =  mysqli_real_escape_string($conexion, $_POST['telefonoAsis']);//tipo numerico
/*abajo, dato para poder evaluar si es ese u otro dato, no modificar*/
$tipoTrabajo =  mysqli_real_escape_string($conexion, $_POST['tipoTrabajo']);//tipo de seleccion "otro"
/*arriba, dato para poder evaluar si es ese u otro dato, no modificar*/
$otroAsistente =  mysqli_real_escape_string($conexion, $_POST['otroAsistente']);



$agregar = "";
$agregar2 = "";
$agregar3 = "";
$agregar4 = "";


//----------------------------------------------------------VALIDACIONES-----------------------------------------------------------
// Convertir la primera letra de cada palabra a mayúscula

$nombreCoord = ucwords(strtolower($nombreCoord));
$apellidoPCoord = ucwords(strtolower($apellidoPCoord));
$apellidoMCoord = ucwords(strtolower($apellidoMCoord));//ucwords(primera letra en mayusculas), strtolower(las demas letras en minusculas)

if($extension==""){
        $extension = "0000";
}

if($grado === 'especialidad médica'){
        $sedeMedico =  mysqli_real_escape_string($conexion, $_POST['sedeMedico']);
        
        $agregar = "INSERT INTO generalposgrados (nombre, numSPN, numReg, grado, sedeMedico, orientacion, areaEstudio, region, dependencia, nombreCoord, apellidoPCoord, apellidoMCoord, gradoCoord,sexo, anioInicio, inicioposg, pagWeb, correo, telefono, estadoposgrado, extension)
                VALUES ('$nombre', '$numSPN', '$numREG','$grado', '$sedeMedico', '$orientacion', '$areaEstudio', '$region', '$dependencia', '$nombreCoord', '$apellidoPCoord', '$apellidoMCoord','$gradoCoord', '$sexo', '$anioInicio', '$inicioposg','$pagWeb', '$correo', '$telefono', '$estadoposgrado', '$extension')";

}else{
        $agregar = "INSERT INTO generalposgrados (nombre, numSPN, numReg, grado, sedeMedico, orientacion, areaEstudio, region, dependencia, nombreCoord, apellidoPCoord, apellidoMCoord, gradoCoord,sexo, anioInicio, inicioposg, pagWeb, correo, telefono, estadoposgrado, extension)
        VALUES ('$nombre', '$numSPN', '$numREG','$grado', 'sinSede', '$orientacion', '$areaEstudio', '$region', '$dependencia', '$nombreCoord', '$apellidoPCoord', '$apellidoMCoord','$gradoCoord', '$sexo', '$anioInicio', '$inicioposg','$pagWeb', '$correo', '$telefono', '$estadoposgrado', '$extension')";

        
}


/*----------------------------------------------------------------Insercion del segundo acordeon(Evaluacion)--------------------------------------------*/

//Codigo oara validar si la "instancia evaladora del posgrado" es a las selecciadas o se ingreso el nombre de otra instancia
/*abajo, dato para poder evaluar si es ese u otro dato, no modificar*/
$instPos =  mysqli_real_escape_string($conexion, $_POST['instPos']);
/*arriba, dato para poder evaluar si es ese u otro dato, no modificar*/
$actualizacion =  mysqli_real_escape_string($conexion, $_POST['actualizacion']);
$inicioposg =  mysqli_real_escape_string($conexion, $_POST['inicioposg']);
if($instPos === 'otro'){
    $otraInst =  mysqli_real_escape_string($conexion, $_POST['otraInst']);
    
    if($actualizacion == 'si'){
        $anioAct =  mysqli_real_escape_string($conexion, $_POST['anioAct']);
        $agregar2 = "INSERT INTO evaluacionposgrado (instPos, otraInst, actualizacion, anioAct, inicioposg, ultEva)
        VALUES ('otro', '$otraInst','$actualizacion', '$anioAct', '$inicioposg', '$ultEva')";
    }else{
        $agregar2 = "INSERT INTO evaluacionposgrado (instPos, otraInst,actualizacion, anioAct,inicioposg, ultEva)
        VALUES ('otro','$otraInst', '$actualizacion', null, '$inicioposg', '$ultEva')";
    }
}else{
    $anioAct =  mysqli_real_escape_string($conexion, $_POST['anioAct']);
    //$documentoHcu = $_FILES['documentoHcu']['name'];
    if($actualizacion == 'si'){
        $agregar2 = "INSERT INTO evaluacionposgrado (instPos, actualizacion, anioAct,inicioposg, ultEva)
        VALUES ('$instPos', '$actualizacion', '$anioAct', '$inicioposg', '$ultEva')";
    }else{
        $agregar2 = "INSERT INTO evaluacionposgrado (instPos, actualizacion, anioAct, inicioposg, ultEva)
        VALUES ('$instPos', '$actualizacion', null, '$inicioposg', '$ultEva')";
   }
        
}

//agregar los archivos de los seleccionados
//$opcion = $_POST['instPos'];

// Directorio donde se guardarán los archivos
/*$directorio_destino = "../uploads/";

// Guardar archivos según la opción seleccionada
$archivos = [];

if (isset($_FILES['archivo_snp']) && $_FILES['archivo_snp']['error'] === UPLOAD_ERR_OK) {
    $nombre_archivo = $_FILES['archivo_snp']['name'];
    $ruta_archivo = $directorio_destino . $nombre_archivo;
    move_uploaded_file($_FILES['archivo_snp']['tmp_name'], $ruta_archivo);
    $archivos['archivo_snp'] = $ruta_archivo;
}

if (isset($_FILES['archivo_seip']) && $_FILES['archivo_seip']['error'] === UPLOAD_ERR_OK) {
    $nombre_archivo = $_FILES['archivo_seip']['name'];
    $ruta_archivo = $directorio_destino . $nombre_archivo;
    move_uploaded_file($_FILES['archivo_seip']['tmp_name'], $ruta_archivo);
    $archivos['archivo_seip'] = $ruta_archivo;
}

if (isset($_FILES['archivo_cifrhs']) && $_FILES['archivo_cifrhs']['error'] === UPLOAD_ERR_OK) {
    $nombre_archivo = $_FILES['archivo_cifrhs']['name'];
    $ruta_archivo = $directorio_destino . $nombre_archivo;
    move_uploaded_file($_FILES['archivo_cifrhs']['tmp_name'], $ruta_archivo);
    $archivos['archivo_cifrhs'] = $ruta_archivo;
}

if (isset($_FILES['otro_archivo']) && $_FILES['otro_archivo']['error'] === UPLOAD_ERR_OK) {
    $nombre_archivo = $_FILES['otro_archivo']['name'];
    $ruta_archivo = $directorio_destino . $nombre_archivo;
    move_uploaded_file($_FILES['otro_archivo']['tmp_name'], $ruta_archivo);
    $archivos['otro_archivo'] = $ruta_archivo;
}

*/
// Insertar en la base de datos
/*$sql = "INSERT INTO instanciaarchivos (opcion";

//foreach (['archivo_snp', 'archivo_seip', 'archivo_cifrhs', 'otro_archivo'] as $archivo) {
  //  $sql .= ", $archivo";
//}

$sql .= ") VALUES ('$opcion'";

foreach (['archivo_snp', 'archivo_seip', 'archivo_cifrhs', 'otro_archivo'] as $archivo) {
    $valor = isset($archivos[$archivo]) ? "'" . $archivos[$archivo] . "'" : 'NULL';
    $sql .= ", $valor";
}

$sql .= ")";

    */
/*----------------------------------------------------------------FIN insercion del segundo acordeon(Evaluacion)--------------------------------------------*/

/*----------------------------------------------------------------INICIO Insercion del tercer acordeon(ficha tecnica)--------------------------------------------*/
if (empty($periocidad) || empty($durPos)) {
        echo "Por favor, ingresa todos los datos de la Ficha Técnica.";
        exit;
}

$agregar3 = "INSERT INTO fichatecnicapos (periocidad, durPos, credito)
 VALUES ('$periocidad', '$durPos', '$credito')";
/*----------------------------------------------------------------FIN Insercion del tercer acordeon(ficha tecnica)--------------------------------------------*/

/*----------------------------------------------------------------Insercion del cuarto acordeon(Asistentes)--------------------------------------------*/
if (empty($nombreAsis) || empty($apellidoPAsis) || empty($apellidoMAsis) || empty($apellidoMCoord)) {
        echo "Por favor, ingresa todos los datos de los Asistentes.";
        exit;
}

// Validar que el correo esté bien estructurado
else if (!filter_var($correoAsis, FILTER_VALIDATE_EMAIL)) {
        echo "El formato del correo electrónico es incorrecto.";
        exit;
}

else if (strlen($telefonoAsis) !== 10 || !ctype_digit($telefonoAsis)) {//strlen: sirve para que en este caso sean 10 diigitos exactamente
        //ctype_digit: es una función de PHP que se utiliza para verificar si una cadena contiene únicamente caracteres numéricos
        echo "El número de teléfono debe contener 10 dígitos.";
        exit;
}

if($tipoTrabajo === 'otro'){
        $otroTrabajo =  mysqli_real_escape_string($conexion, $_POST['otroTrabajo']);

        if($otroAsistente === 'si'){
                $nombreAsis2 = mysqli_real_escape_string($conexion, $_POST['nombreAsis2']);
                $apellidoPAsis2 = mysqli_real_escape_string($conexion, $_POST['apellidoPAsis2']);
                $apellidoMAsis2 = mysqli_real_escape_string($conexion, $_POST['apellidoMAsis2']);
                $correoAsis2 =  mysqli_real_escape_string($conexion, $_POST['correoAsis2']);
                $telefonoAsis2 =  mysqli_real_escape_string($conexion, $_POST['telefonoAsis2']);
                $tipoTrabajo2 =  mysqli_real_escape_string($conexion, $_POST['tipoTrabajo2']);
                if($tipoTrabajo2 === 'otro'){
                        $otroTrabajo2 =  mysqli_real_escape_string($conexion, $_POST['otroTrabajo2']);

                        $agregar4 = "INSERT INTO asistentepos (nombreAsis, apellidoPAsis, apellidoMAsis, correoAsis, telefonoAsis, otroTrabajo, otroAsistente2, nombreAsis2, apellidoPAsis2, apellidoMAsis2, correoAsis2, telefonoAsis2, tipoTrabajo2)
                        VALUES ('$nombreAsis', '$apellidoPAsis', '$apellidoMAsis', '$correoAsis', '$telefonoAsis', '$otroTrabajo', '$otroAsistente','$nombreAsis2', '$apellidoPAsis2', '$apellidoMAsis2', '$correoAsis2', '$telefonoAsis2', '$otroTrabajo2')";                        
                }else{
                        $agregar4 = "INSERT INTO asistentepos (nombreAsis, apellidoPAsis, apellidoMAsis, correoAsis, telefonoAsis, otroTrabajo, otroAsistente2, nombreAsis2, apellidoPAsis2, apellidoMAsis2, correoAsis2, telefonoAsis2, tipoTrabajo2)
                        VALUES ('$nombreAsis', '$apellidoPAsis', '$apellidoMAsis', '$correoAsis', '$telefonoAsis', '$otroTrabajo', '$otroAsistente', '$nombreAsis2', '$apellidoPAsis2', '$apellidoMAsis2', '$correoAsis2', '$telefonoAsis2', '$tipoTrabajo2')";                        
                }
        }else{
                $agregar4 = "INSERT INTO asistentepos (nombreAsis, apellidoPAsis, apellidoMAsis, correoAsis, telefonoAsis, otroTrabajo, otroAsistente2, nombreAsis2, apellidoPAsis2, apellidoMAsis2, correoAsis2, telefonoAsis2, tipoTrabajo2)
                VALUES ('$nombreAsis', '$apellidoPAsis', '$apellidoMAsis', '$correoAsis', '$telefonoAsis', '$otroTrabajo', '$otroAsistente', null, null, null, null, null, null)";                        
               
        }

}else{

        if($otroAsistente === 'si'){
                $nombreAsis2 = mysqli_real_escape_string($conexion, $_POST['nombreAsis2']);
                $apellidoPAsis2 = mysqli_real_escape_string($conexion, $_POST['apellidoPAsis2']);
                $apellidoMAsis2 = mysqli_real_escape_string($conexion, $_POST['apellidoMAsis2']);
                $correoAsis2 =  mysqli_real_escape_string($conexion, $_POST['correoAsis2']);
                $telefonoAsis2 =  mysqli_real_escape_string($conexion, $_POST['telefonoAsis2']);
                $tipoTrabajo2 =  mysqli_real_escape_string($conexion, $_POST['tipoTrabajo2']);
                if($tipoTrabajo2 === 'otro'){
                        $otroTrabajo2 =  mysqli_real_escape_string($conexion, $_POST['otroTrabajo2']);

                        $agregar4 = "INSERT INTO asistentepos (nombreAsis, apellidoPAsis, apellidoMAsis, correoAsis, telefonoAsis, tipoTrabajo, otroAsistente2, nombreAsis2, apellidoPAsis2, apellidoMAsis2, correoAsis2, telefonoAsis2, tipoTrabajo2)
                        VALUES ('$nombreAsis', '$apellidoPAsis', '$apellidoMAsis', '$correoAsis', '$telefonoAsis', '$tipoTrabajo', '$otroAsistente', '$nombreAsis2' ,'$apellidoPAsis2', '$apellidoMAsis2', '$correoAsis2', '$telefonoAsis2', '$otroTrabajo2')";                        
                }else{
                        $agregar4 = "INSERT INTO asistentepos (nombreAsis, apellidoPAsis, apellidoMAsis, correoAsis, telefonoAsis, tipoTrabajo, otroAsistente2, nombreAsis2, apellidoPAsis2, apellidoMAsis2, correoAsis2, telefonoAsis2, tipoTrabajo2)
                        VALUES ('$nombreAsis', '$apellidoPAsis', '$apellidoMAsis', '$correoAsis', '$telefonoAsis', '$tipoTrabajo', '$otroAsistente', '$nombreAsis2','$apellidoPAsis2', '$apellidoMAsis2', '$correoAsis2', '$telefonoAsis2', '$tipoTrabajo2')";                        
                }
        }else{
                $agregar4 = "INSERT INTO asistentepos (nombreAsis, apellidoPAsis, apellidoMAsis, correoAsis, telefonoAsis, tipoTrabajo, otroAsistente2, nombreAsis2, apellidoPAsis2, apellidoMAsis2, correoAsis2, telefonoAsis2, tipoTrabajo2)
                VALUES ('$nombreAsis', '$apellidoPAsis', '$apellidoMAsis', '$correoAsis', '$telefonoAsis', '$tipoTrabajo', '$otroAsistente', null, null, null, null, null, null)";                        
               
        }
}

/*----------------------------------------------------------------FIN Insercion del cuarto acordeon(Asistentes)--------------------------------------------*/

 // print ('<p> '.$agregar.'</p>');
 // print ('<p> '.$agregar2.'</p>');
 // print ('<p> '.$agregar3.'</p>');
 // print ('<p> '.$agregar4.'</p>');

 // exit();

$inserInmueble = mysqli_query($conexion, $agregar);
$inserInmueble2 = mysqli_query($conexion, $agregar2);
$inserInmueble3 = mysqli_query($conexion, $agregar3);
$inserInmueble4 = mysqli_query($conexion, $agregar4);
//$inserInmueble5 = mysqli_query($conexion, $sql);

//-----------------------------Obtencion de Datos Academicos del Profesor--------------------->



header("Location: ../principales/generalesPosgrados.php?msg=1");
?>
