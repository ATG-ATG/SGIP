<?php 
include('../conexion/conexion.php'); //consulta para los datos obtenidos anteriormente en la base de datos
$id = $_REQUEST['id'];

//vista de seguimiento y edición**********************

/**
 * SELECT * FROM "nombre de la tabla que estara en la bases de datos"
 * Todas las tablas que componene esto, tienen la misma idEstudiante, para identificar, no da errores
 */

//lines de codigo para obtener los valores previos del formulario

//---------------------------------Datos del Primer Acordeon(MOSTRAR UNICAMENTE)-------------------------------------------------->

$sql = "SELECT * FROM ingresoestudiante WHERE idEstudiante='" . $id . "'"; //se traeran el valor guardado en esta tabla 


$res = mysqli_query($conexion, $sql);

$ingreso_estudiante = mysqli_fetch_assoc($res);

$expediente_estudiante_antiguo = $ingreso_estudiante['expediente_estudiante'];
$nombreEst_antiguo =  $ingreso_estudiante['nombreEst'];
$apellidoPEstudiante_antiguo =  $ingreso_estudiante['apellidoPEstudiante'];
$apellidoMEstudiante_antiguo =  $ingreso_estudiante['apellidoMEstudiante'];
$sexo_antiguo = $ingreso_estudiante['sexo'];
$grupoVulnerable_antiguo =  $ingreso_estudiante['grupoVulnerable'];
$nombre_antiguo =  $ingreso_estudiante['nombre'];
$matricula_antiguo = $ingreso_estudiante['matricula'];//tipo num
$numCVU_antiguo = $ingreso_estudiante['numCVU'];//tipo numerico

$generacion_antiguo =   $ingreso_estudiante['generacion'];
#$iniciogen_antiguo =   $iniciogen['iniciogen'];
$nacionalidad_antiguo =   $ingreso_estudiante['nacionalidad'];
//--------------------------Datos del Segundo Acordeon (SEGUIMIENTO)----------------------------------------------->
$sql = "SELECT * FROM seguimientoestudiante WHERE idEstudiante='" . $id . "'"; //se traeran el valor guardado en esta tabla
$res = mysqli_query($conexion, $sql);
$seguimiento_estudiante = mysqli_fetch_assoc($res);
$inicioEstudio_antiguo = $seguimiento_estudiante['inicioEstudio'] ?? '';//tipo numerico
$finEstudio_antiguo =  $seguimiento_estudiante['finEstudio'] ?? '';//tipo numerico
$selecBeca_antiguo =  $seguimiento_estudiante['selecBeca'] ?? '';//tipo numerico
$inicioBeca_antiguo =  $seguimiento_estudiante['inicioBeca'] ?? '';//tipo date
$finBeca_antiguo =  $seguimiento_estudiante['finBeca'] ?? '';//tipo date
$actExtra_antiguo = $seguimiento_estudiante['actExtra'] ?? '';//tipo date
$causaBaja_antiguo = $seguimiento_estudiante['causaBaja'] ?? '';//tipo date
//--------------------------Datos del Tercer Acordeon (EGRESO)----------------------------------------------->
$sql = "SELECT * FROM egeresoestudiante WHERE idEstudiante='" . $id . "'"; //se traeran el valor guardado en esta tabla
$res = mysqli_query($conexion, $sql);
$egreso_estudiante = mysqli_fetch_assoc($res);
$graduacion_antiguo = $egreso_estudiante['graduacion'] ?? '';//tipo numerico
$continuaEstudios_antiguo = $egreso_estudiante['continuaEstudios'] ?? '';//tipo numerico
$sni_antiguo =  $egreso_estudiante['sni'] ?? '';//tipo numerico
$anioIngreso_antiguo =  $egreso_estudiante['anioIngreso'] ?? '';//tipo date
$lugarTrabaja_antiguo =  $egreso_estudiante['lugarTrabaja'] ?? '';//tipo date
$aQueSeDedica_antiguo =  $egreso_estudiante['aQueSeDedica'] ?? '';//tipo date

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">

    <!-- boostraps -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <title>Editar Estudiante</title>


    <style>
        .centrar-texto {
            text-align: center;
        }

        .student-info {
            width: 600px;
            margin: 0 auto;
            background-color: #ffffff;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.2);
        }
        .student-info table {
            width: 100%;
        }
        .student-info th, .student-info td {
            padding: 10px;
            text-align: left;
        }
        .student-info th {
            background-color: #DCE0ED;
            color: #5F5F5C;
        }
    </style>
</head>
<!--  -->

<?php

$id = $_GET['id'];
$sql = "SELECT * FROM `ingresoestudiante` WHERE idEstudiante='" . $id . "'";
$res = mysqli_query($conexion, $sql);
$row = mysqli_fetch_assoc($res);
?>

<?php include_once('../menu.php');?><!--INCLUIR EL MENU-->


<div style="width: 80%; margin: auto;">

    
        <div class="modal-body" id="cont_modal">
        
            <div class="student-info">
                <div class="centrar-texto">
                    <h4>Datos Generales del ingreso del Estudiante:</h4>
                    <h3><?php echo $nombreEst_antiguo. " ". $apellidoPEstudiante_antiguo . " ".$apellidoMEstudiante_antiguo;?></h3>
                </div>
        
                <table>
                    <tr>
                        <th>Nombre:</th>
                        <td><?php echo $nombreEst_antiguo?></td>
                    </tr>
                    <tr>
                        <th>Primer Apellido:</th>
                        <td><?php echo $apellidoPEstudiante_antiguo?></td>
                    </tr>
                    <tr>
                        <th>Segundo Apellido:</th>
                        <td><?php echo $apellidoMEstudiante_antiguo?></td>
                    </tr>
                    <tr>
                        <th>Sexo:</th>
                        <td><?php echo $sexo_antiguo?></td>
                    </tr>

                    <tr>
                        <th>Nacionalidad:</th>
                        <?php echo "<td>". $nacionalidad_antiguo . "</td>";?>                        
                    </tr>

                    <tr>
                        <?php                         
                        if($nacionalidad_antiguo === 'Mexicana'){
                            $estado_antiguo =   $ingreso_estudiante['estado'];
                            echo "<th>Estado:</th>";
                            echo "<td>". $estado_antiguo . "</td>";

                        }else if ($nacionalidad_antiguo === 'Extranjera') {
                            $pais_antiguo =   $ingreso_estudiante['pais'];
                            echo "<th>Pais:</th>";
                            echo "<td>". $pais_antiguo . "</td>";
                        }
                        ?>
                    </tr>

                    <tr>
                        <th>Grupo vulnerable:</th>
                        <td><?php echo $grupoVulnerable_antiguo;?></td>                        
                    </tr>

                    <tr>
                        <th>Matrícula:</th>
                        <td><?php echo $matricula_antiguo;?></td>                               
                    </tr>

                    <tr>
                        <th>CVU:</th>
                        <td><?php echo $numCVU_antiguo;?></td>                           
                    </tr>

                    <tr>
                        <th>Posgrado al que pertenece:</th>
                        <td><?php echo $nombre_antiguo;?></td> 
                    </tr>

                    <tr>
                        <th>Generación:</th>
                        <td><?php echo $generacion_antiguo;?></td>                           
                    </tr>
                    
                    <!--<tr>
                        <th>Inicio de Generación:</th>
                        <td><?php echo $iniciogen_antiguo;?></td>                           
                    </tr>-->
                </table>

                <div style="display: flex; justify-content: center; align-items: center; margin-left: 400px;">
                <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#myModal1">
                    <!-- Icono de agregar--> 
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill-add" viewBox="0 0 16 16">
                        <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path>
                        <path d="M2 13c0 1 1 1 1 1h5.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.544-3.393C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4Z"></path>
                    </svg>
                    <h6>Editar Estudiante</h6>
                </button>
            </div>
            </div>
            <hr>
            
<!-------------------------------------------------------------------SEGUNDO ACORDEON(SEGUIMIENTO DEL ESTUDIANTE)------------------------------------------------------------------------------------------------------>

        <div id="accordion">

            <div class="card">
                <div class="card-header">
                <a class="btn" data-bs-toggle="collapse" href="#collapseOne">
                    Seguimiento del Estudiante 
                </a>
                </div>
                    <div id="collapseOne" class="collapse show" data-bs-parent="#accordion">
                        <div class="card-body">
                            <form method="POST" action="../crudEstudiantes/SeguimientoEst.php" enctype="multipart/form-data">
                                <?php echo "ID Para identificar al estudiante: ". $id;?>
                                <div class="row">                                        
                                <div class="col">                                            
                                        <div class="form-group">
                                            <label for="inicioEstudio" class="col-form-label">Inicio de Estudios</label>
                                            <?php 
                                            if($inicioEstudio_antiguo){
                                                ?>
                                                <input type="date" name="inicioEstudio" id="inicioEstudio" class="form-control" 
                                                title="Selecciona una fecha válida (entre 1970 y 2024)" 
                                                min="1970-01-01" max="<?php echo date('Y-m-d', strtotime('now')); ?>" required 
                                                value="<?php echo $inicioEstudio_antiguo;?>">
                                                <?php
                                            }else{
                                                ?>
                                                <input type="date" name="inicioEstudio" id="inicioEstudio" class="form-control" 
                                                title="Selecciona una fecha válida (entre 1970 y 2024)" 
                                                min="1970-01-01" max="<?php echo date('Y-m-d', strtotime('now')); ?>" required 
                                                placeholder="Selecciona una fecha">
                                                <?php
                                            }
                                            ?>
                                        </div>        
                                    </div>

                                    <div class="col">                                            
                                        <div class="form-group">
                                            <label for="finEstudio" class="col-form-label">Fin de Estudios</label>
                                            <?php 
                                            if($finEstudio_antiguo){
                                                ?>
                                                <input type="date" name="finEstudio" id="finEstudio" class="form-control" 
                                                title="Selecciona una fecha válida" 
                                                min="1970-01-01" max="<?php echo date('Y-m-d', strtotime('+4 years')); ?>" required 
                                                value="<?php echo $finEstudio_antiguo;?>">
                                                <?php
                                            }else{
                                                ?>
                                                <input type="date" name="finEstudio" id="finEstudio" class="form-control" 
                                                title="Selecciona una fecha válida (entre 1970 y 2024)" 
                                                min="1970-01-01" max="<?php echo date('Y-m-d', strtotime('+4 years')); ?>" required 
                                                placeholder="Selecciona una fecha">
                                                <?php
                                            }
                                            ?>
                                        </div>        
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col">                                                     
                                        <div class="form-group">
                                            <label for="selecBeca" class="col-form-label">¿Cuenta con Beca?</label><br>        
                                            <?php
                                            if ($selecBeca_antiguo) {
                                            ?>
                                                <input type="radio" name="selecBeca" id="si" value="si" <?php echo ($seguimiento_estudiante['selecBeca'] === 'si') ? 'checked' : ''; ?>> Si                                  
                                                <input type="radio" name="selecBeca" id="no" value="no" <?php echo ($seguimiento_estudiante['selecBeca'] === 'no') ? 'checked' : ''; ?>> No
                                            <?php
                                            } else {
                                            ?>
                                                <input type="radio" name="selecBeca" id="si" value="si"> Si                                  
                                                <input type="radio" name="selecBeca" id="no" value="no"> No
                                            <?php
                                            }
                                            ?>                
                                            
                                        </div>
                                    </div>

                                    <div class="col">
                                        <div class="form-group">
                                            <label for="inicioBeca" class="col-form-label">Inicio de beca</label>
                                            <?php 
                                            if($inicioBeca_antiguo){
                                                ?>
                                                <input type="date" name="inicioBeca" id="inicioBeca" class="form-control" min="1900-01-01" max="2024-12-31" value="<?php echo $inicioBeca_antiguo;?>">
                                                <?php
                                            }else{
                                                ?>
                                                <input type="date" name="inicioBeca" id="inicioBeca" class="form-control" min="1900-01-01" max="2024-12-31">
                                                <?php
                                            }
                                            ?>
                                        </div>                                            
                                    </div>

                                    <div class="col">
                                        <div class="form-group">
                                            <label for="finBeca" class="col-form-label">Fin de la beca</label>
                                            
                                            <?php 
                                            if($finBeca_antiguo){
                                                ?>
                                                <input type="date" name="finBeca" id="finBeca" class="form-control" min="1900-01-01" max="2100-12-31" value="<?php echo $finBeca_antiguo;?>">
                                                <?php
                                            }else{
                                                ?>
                                                <input type="date" name="finBeca" id="finBeca" class="form-control" min="1900-01-01" max="2100-12-31">
                                                <?php
                                            }
                                            ?>
                                        </div>                                            
                                    </div>
                                </div>

                                <div class="row">                
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="actExtra" class="col-form-label">Generación de actividades extracurriculares</label>
                                            <?php 
                                            if($actExtra_antiguo){
                                                ?>
                                                <input type="text" name="actExtra" id="actExtra" class="form-control" required pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s\,]+" title="Solo se permiten letras" value="<?php echo $actExtra_antiguo;?>">
                                                <?php
                                            }else{
                                                ?>
                                                <input type="text" name="actExtra" id="actExtra" class="form-control" required pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s\,]+" title="Solo se permiten letras" placeholder="texto">
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="col">
                                        <div class="form-group">
                                            <label for="causaBaja" class="col-form-label">Causa de baja</label>
                                            <?php 
                                            if($causaBaja_antiguo){
                                                ?>
                                                <input type="text" name="causaBaja" id="causaBaja" class="form-control" required
                                                pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" value="<?php echo $causaBaja_antiguo;?>">
                                                <?php
                                            }else{
                                                ?>
                                                 <input type="text" name="causaBaja" id="causaBaja" class="form-control" required
                                                pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" placeholder= "Causas de baja">
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>

                                <input type="hidden" name="idEstudiante" value="<?php echo $id; ?>">

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-primary">Guardar</button>
                                </div>
                            </form>
                        </div>
                    </div>
            </div>
        
            <div class="card">
                <div class="card-header">
                <a class="collapsed btn" data-bs-toggle="collapse" href="#collapseTwo">
                    Egreso del Estudiante
                </a>
                </div>
                <div id="collapseTwo" class="collapse" data-bs-parent="#accordion">
                    <div class="card-body">
                        <form method="POST" action="../crudEstudiantes/egresoEst.php" enctype="multipart/form-data">
                        <?php echo "ID Para identificar al estudiante: ". $id;?>
                            <div class="row">
                                <div class="col">
                                    <div class="form-group">
                                        <label for="graduacion" class="col-form-label">Fecha de Graduación</label>
                                        <?php 
                                            if($graduacion_antiguo){
                                                ?>
                                                <input type="date" name="graduacion" id="graduacion" class="form-control" min="1900-01-01" max="2100-12-31" value="<?php echo $graduacion_antiguo;?>">
                                                <?php
                                            }else{
                                                ?>
                                                <input type="date" name="graduacion" id="graduacion" class="form-control" min="1900-01-01" max="2100-12-31">
                                                <?php
                                            }
                                        ?>
                                    </div>                                                                                        
                                </div>

                                <div class="col">                                        
                                    <div class="form-group">                        
                                        <label for="continuaEstudios" class="col-form-label">¿Continua con sus Estudios?</label><br>                        
                                            <?php
                                                if ($continuaEstudios_antiguo) {
                                                ?>
                                                    <input type="radio" name="continuaEstudios" id="si" value="si" <?php echo ($egreso_estudiante['continuaEstudios'] === 'si') ? 'checked' : ''; ?>> Si                                  
                                                    <input type="radio" name="continuaEstudios" id="no" value="no" <?php echo ($egreso_estudiante['continuaEstudios'] === 'no') ? 'checked' : ''; ?>> No
                                                <?php
                                                } else {
                                                ?>
                                                    <input type="radio" name="continuaEstudios" id="si" value="si"> Si                                  
                                                    <input type="radio" name="continuaEstudios" id="no" value="no"> No
                                                <?php
                                                }
                                            ?>   
                                                
                                    </div> 
                                </div>

                                <div class="col">
                                        <?php
                                        $sql = "SELECT * FROM `concentradoacademico`";
                                        $res = mysqli_query($conexion, $sql);
                                        
                                        echo '<div class="form-group">';
                                        echo '<label for="sni" class="col-form-label">SNI</label>';
                                        echo '<select name="sni" id="sni" class="form-select" required>';
                                        echo '<option selected disabled value="">elige una opción...</option>';
                                    
                                        while ($row = mysqli_fetch_array($res)) {
                                            $sni = $row['sni'];
                                            if(!$sni==""){
                                                if($sni_antiguo){
                                                    $selected = ($sni == $sni_antiguo) ? 'selected' : '';
                                                    echo "<option value=\"$sni\" $selected>$sni</option>";
                                                }else{
                                                    ?>
                                                    <option value="<?php echo $sni; ?>"><?php echo $sni; ?></option>
                                                    <?php
                                                }
                                                
                                            }
                                        }
                                        echo '</select>';
                                        echo '</div>';
                                        ?> 
                                </div>
                                
                            </div>

                            <div class="row">            
                                <div class="col">
                                    <div class="form-group">
                                        <label for="anioIngreso" class="col-form-label">Año de Ingreso</label>
                                        <?php 
                                            if($anioIngreso_antiguo){
                                                ?>
                                                <input type="date" name="anioIngreso" id="anioIngreso" class="form-control" min="1900-01-01" max="2100-12-31" value="<?php echo $anioIngreso_antiguo;?>">
                                                <?php
                                            }else{
                                                ?>
                                                <input type="date" name="anioIngreso" id="anioIngreso" class="form-control" min="1900-01-01" max="2100-12-31">
                                                <?php
                                            }
                                        ?>
                                    </div>                                                                                      
                                </div>
                                <div class="col">
                                    <div class="form-group">
                                        <label for="lugarTrabaja" class="col-form-label">Lugar donde Trabaja</label>
                                        <?php 
                                            if($lugarTrabaja_antiguo){
                                                ?>
                                                <input type="text" name="lugarTrabaja" id="lugarTrabaja" class="form-control" required
                                                pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" value="<?php echo $lugarTrabaja_antiguo;?>">
                                                <?php
                                            }else{
                                                ?>
                                                 <input type="text" name="lugarTrabaja" id="lugarTrabaja" class="form-control" required
                                                pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" placeholder= "Lugar de trabajo">
                                                <?php
                                            }
                                        ?>
                                    </div>
                                </div>
                                <div class="col">
                                    <div class="form-group">
                                        <label for="aQueSeDedica" class="col-form-label">A que se dedica</label>
                                        <input type="text" name="aQueSeDedica" id="aQueSeDedica" class="form-control" required 
                                        pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Solo se permiten letras" 
                                        <?php 
                                            if($aQueSeDedica_antiguo){
                                                echo 'value="'. $aQueSeDedica_antiguo . '"' ;    
                                            }else{
                                                echo 'placeholder="Oficio de su trabajo" '; 
                                            }
                                        ?>>
                                    </div>
                                </div>
                            </div>

                            <input type="hidden" name="idEstudiante" value="<?php echo $id; ?>">

                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Guardar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            
    </div>

</div>



<?php include('../modalEstudiantes/agregarEstudiante.php');?>
<!---fin ventana Update --->
