<?php 
include('../conexion/conexion.php');
$id = $_REQUEST['id']??'';

//modal de ingreso de estudiantes
$sql = "SELECT * FROM ingresoestudiante WHERE idEstudiante='" . $id . "'"; //se traeran el valor guardado en esta tabla 
$res = mysqli_query($conexion, $sql);
$ingreso_estudiante = mysqli_fetch_assoc($res);
$expediente_estudiante_antiguo = $ingreso_estudiante['expediente_estudiante'] ?? '';
$nombreEst_antiguo =  $ingreso_estudiante['nombreEst'] ?? '';
$apellidoPEstudiante_antiguo =  $ingreso_estudiante['apellidoPEstudiante'] ?? '';
$apellidoMEstudiante_antiguo =  $ingreso_estudiante['apellidoMEstudiante'] ?? '';
$sexo_antiguo = $ingreso_estudiante['sexo'] ?? '';
$grupoVulnerable_antiguo =  $ingreso_estudiante['grupoVulnerable'] ?? '';


$nombre_antiguo =  $ingreso_estudiante['nombre'] ?? '';


$matricula_antiguo = $ingreso_estudiante['matricula'] ?? '';//tipo num
$numCVU_antiguo = $ingreso_estudiante['numCVU'] ?? '';//tipo numerico

$generacion_antiguo =   $ingreso_estudiante['generacion'] ?? '';
#$iniciogen =   $iniciogen['iniciogen'] ?? '';
$nacionalidad_antiguo =   $ingreso_estudiante['nacionalidad'] ?? '';

?>

<?php
//
$id = $_GET['id']??'';
$sql = "SELECT * FROM `ingresoestudiante` WHERE idEstudiante='" . $id . "'";
$res = mysqli_query($conexion, $sql);
$row = mysqli_fetch_assoc($res);

?>


<!--ventana para Agregar--->
<div class="modal fade" id="myModal1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">
                    Datos del Estudiante
                </h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>

            <form id="miFormulario" method="POST" action="../crudEstudiantes/recibeEst.php" enctype="multipart/form-data" onsubmit="return validarFormulario()"> 
                <div class="accordion accordion-flush" id="accordionFlushExample"><!----ACORDEON---->
                                <!--Acordeon para los datos personales-->
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="headingOne">
                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                            Ingreso
                            </button>
                        </h2>
                        <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                            <div class="accordion-body">   
                                <div class="modal-body" id="cont_modal">

                                    <div class="row">
                                        <div class="col">                                                                                    
                                            <div class="form-group">
                                                <input type="hidden" name="id" value="<?php echo $row['idEstudiante']; ?>">
                                                <label for="nombreEst" class="col-form-label">Nombre del Estudiante</label>
                                                <?php 
                                                if($nombreEst_antiguo){
                                                    ?>
                                                    <input type="text" name="nombreEst" id="nombreEst" class="form-control" required value="<?php echo $nombreEst_antiguo;?>" placeholder="Nombre del Estudiante" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s\.]+" title="Sólo se permiten letras"> 
                                                    <?php
                                                }else{
                                                    ?>
                                                    <input type="text" name="nombreEst" id="nombreEst" class="form-control" required placeholder="Nombre del Estudiante" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s\.]+" title="Sólo se permiten letras">                                                
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>

                                        <div class="col">                                        
                                            <div class="form-group">
                                                <label for="apellidoPEstudiante" class="col-form-label">Primer Apellido</label>
                                                <?php 
                                                if($apellidoPEstudiante_antiguo){
                                                    ?>
                                                    <input type="text" name="apellidoPEstudiante" id="apellidoPEstudiante" class="form-control" required placeholder="Primer Apellido del Estudiante" value="<?php echo $apellidoPEstudiante_antiguo;?>"  pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Sólo se permiten letras">                                                
                                                    <?php
                                                }else{
                                                    ?>
                                                    <input type="text" name="apellidoPEstudiante" id="apellidoPEstudiante" class="form-control" required placeholder="Primer Apellido del Estudiante" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s]+" title="Sólo se permiten letras">                                                
                                                    <?php
                                                }
                                                ?>
                                            </div>
                                        </div>

                                        <div class="col">                                        
                                            <div class="form-group">
                                                <label for="apellidoMEstudiante" class="col-form-label">Segundo Apellido</label>
                                                <?php 
                                                if($apellidoMEstudiante_antiguo){
                                                    ?>
                                                    <input type="text" name="apellidoMEstudiante" id="apellidoMEstudiante" class="form-control" required placeholder="Segundo Apellido" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s\-]+" value="<?php echo $apellidoMEstudiante_antiguo;?>" title="Sólo se permiten letras"> 
                                                    <?php
                                                }else{
                                                    ?>
                                                    <input type="text" name="apellidoMEstudiante" id="apellidoMEstudiante" class="form-control" required placeholder="Segundo Apellido" pattern="[A-Za-zÁÉÍÓÚáéíóúÑñ\s\-]+" title="Sólo se permiten letras">                                                
                                                    <?php
                                                }
                                                ?>
                                                
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col">
                                            <div class="form-group">
                                                <?php 
                                                if($expediente_estudiante_antiguo){
                                                    ?>
                                                    <label for="expediente_estudiante" class="col-form-label">Archivo actual:</label>
                                                    <input type="text" readonly name="archiante" class="col-form-label" id="archiactual" value="<?php echo $expediente_estudiante_antiguo;?>">
                                                    <p><button type="button" class="btn btn-warning" onClick="cambiarArchivo(this)" data-archivo="<?php echo $expediente_estudiante_antiguo?>">Cambiar archivo</button></p>
                                                    <label for="expediente_estudiante" class="col-form-label">Expediente de Estudiante(nuevo)</label>
                                                    <input type="file" name="expediente_estudiante" id="expediente_estudiante" class="form-control" disabled>
                                                    <?php
                                                }else{
                                                    ?>
                                                    <label for="expediente_estudiante" class="col-form-label">Expediente de Estudiante</label>
                                                    <input type="file" name="expediente_estudiante" id="expediente_estudiante" class="form-control" required>
                                                    <div id="msg1" class="text-danger"></div>
                                                    <?php
                                                }
                                                ?>
                                                
                                            </div>
                                        </div>

                                        <div class="col">                                            
                                            <div class="form-group">
                                            <label for="matricula" class="col-form-label">Matrícula</label>
                                            <?php 
                                                if($matricula_antiguo){
                                                    ?>
                                                    <input type="number" name="matricula" id="matricula" class="form-control" title="Ingresa una matrícula válida" value="<?php echo $matricula_antiguo;?>"  placeholder="Ingresa 6 dígitos" required>
                                                    <?php
                                                }else{
                                                    ?>
                                                    <input type="number" name="matricula" id="matricula" class="form-control" title="Ingresa una matrícula válida"  placeholder="Ingresa 6 dígitos" required>
                                                    <?php
                                                }
                                                ?>
                                            </div>        
                                        </div>
                                        <div class="col">                                            
                                            <div class="form-group">
                                            <label for="generacion" class="col-form-label">Generación a la que pertenece</label>
                                                <?php 
                                                    if($generacion_antiguo){
                                                        ?>
                                                        <select id="generacion" name="generacion" class="form-select" required>
                                                            <option selected disabled value="">elige una opción...</option>
                                                            <option value="2020-1" <?php echo ($ingreso_estudiante['generacion'] === '2020-1') ? 'selected' : ''; ?>>2020-1</option>
                                                            <option value="2020-2" <?php echo ($ingreso_estudiante['generacion'] === '2020-2') ? 'selected' : ''; ?>>2020-2</option>
                                                            <option value="2021-1" <?php echo ($ingreso_estudiante['generacion'] === '2021-1') ? 'selected' : ''; ?>>2021-1</option>
                                                            <option value="2021-2" <?php echo ($ingreso_estudiante['generacion'] === '2021-2') ? 'selected' : ''; ?>>2021-2</option>
                                                            <option value="2022-1" <?php echo ($ingreso_estudiante['generacion'] === '2022-1') ? 'selected' : ''; ?>>2022-1</option>
                                                            <option value="2022-2" <?php echo ($ingreso_estudiante['generacion'] === '2022-2') ? 'selected' : ''; ?>>2022-2</option>
                                                            <option value="2023-1" <?php echo ($ingreso_estudiante['generacion'] === '2023-1') ? 'selected' : ''; ?>>2023-1</option>
                                                            <option value="2023-2" <?php echo ($ingreso_estudiante['generacion'] === '2023-2') ? 'selected' : ''; ?>>2023-2</option>
                                                        </select>
                                                        <?php
                                                    }else{
                                                        ?>
                                                        <select id="generacion" name="generacion" class="form-select" required>
                                                            <option selected disabled value="">elige una generación...</option>
                                                            <option value="2020-1">2020-1</option>
                                                            <option value="2020-2">2020-2</option>
                                                            <option value="2021-1">2021-1</option>
                                                            <option value="2021-2">2021-2</option>
                                                            <option value="2022-1">2022-1</option>
                                                            <option value="2022-2">2022-2</option>
                                                            <option value="2023-1">2023-1</option>
                                                            <option value="2023-2">2023-2</option>
                                                        </select>
                                                        <?php
                                                    }
                                                ?>
                                                
                                            </div> 
                                        <!--
                                            <div class="form-group">
                                                <label for="iniciogen" class="col-form-label">Inicio de Generación</label>
                                                <?php 
                                                    if($iniciogen_antiguo){
                                                        ?>
                                                        <input type="int" id="iniciogen" class="form-control" name="iniciogen" pattern="^[a-zA-Z0-9\s]*$" title="Solo se permiten letras, números y espacios." placeholder="Ejemplo: A2" value="<?php echo $generacion_antiguo;?>">
                                                        <?php
                                                    }else{
                                                        ?>
                                                        <input type="int" id="iniciogen" class="form-control" name="iniciogen" pattern="^[a-zA-Z0-9\s]*$" title="Solo se permiten letras, números y espacios." placeholder="Ejemplo: 1">
                                                        <?php
                                                    }
                                                ?> 
                                                
                                            </div> -->
                                        </div>

                                    </div>

                                    <div class="row">
                                        <div class="col">  
                                            <div class="form-group">
                                                <br>
                                                <label for="sexo">Sexo:</label><br>
                                                <?php
                                                if ($sexo_antiguo) {
                                                ?>
                                                
                                                    <label for="masculino">Masculino
                                                    <input type="radio" name="sexo" id="Masculino" value="Masculino" <?php echo ($ingreso_estudiante['sexo'] === 'Masculino') ? 'checked' : ''; ?>>
                                                    </label>
                                        
                                                    <label for="femenino">Femenino
                                                    <input type="radio" name="sexo" id="Femenino" value="Femenino"<?php echo ($ingreso_estudiante['sexo'] === 'Femenino') ? 'checked' : ''; ?>>
                                                    </label>
                                                <?php
                                                } else {
                                                ?>  
                                                    <label for="masculino">Masculino</label>
                                                    <input type="radio" name="sexo" id="Masculino" value="Masculino">
                                        
                                                    <label for="femenino">Femenino</label>
                                                    <input type="radio" name="sexo" id="Femenino" value="Femenino">
                                                <?php
                                                }
                                                ?>      
                                            </div>                                                                                                                     
                                        </div>

                                        <div class="col">
                                            <div class="form-group">
                                            <input type="hidden" name="nacionalidad" value="<?php echo $nacionalidad_antiguo; ?>">
                                                <?php
                                                if($nacionalidad_antiguo){
                                                    if($nacionalidad_antiguo === 'Mexicana'){
                                                        echo "Nacionalidad anterior: ";
                                                        echo "<td>". $nacionalidad_antiguo . "</td><br>";
                                                        $estado_antiguo = $ingreso_estudiante['estado'];
                                                        echo "<th>Estado:</th>";
                                                        echo "<td>". $estado_antiguo . "</td>";
                                                        // Mostrar select de estado con la opción seleccionada según el estado anterior
                                                        echo "<select name='estado'>";
                                                        echo "<option value=''>Seleccione un estado...</option>";
                                                        $estados = array("Aguascalientes", "Baja California", "Baja California Sur", "Campeche", "Chiapas", "Chihuahua", "Coahuila", "Colima", "Ciudad de México", "Durango", "Guanajuato", "Guerrero", "Hidalgo", "Jalisco", "México", "Michoacán", "Morelos", "Nayarit", "Nuevo León", "Oaxaca", "Puebla", "Querétaro", "Quintana Roo", "San Luis Potosí", "Sinaloa", "Sonora", "Tabasco", "Tamaulipas", "Tlaxcala", "Veracruz", "Yucatán", "Zacatecas");
                                                        foreach ($estados as $estado) {
                                                            $selected = ($estado == $estado_antiguo) ? 'selected' : '';
                                                            echo "<option value='$estado' $selected>$estado</option>";
                                                        }
                                                        echo "</select>";
                                                    } else if ($nacionalidad_antiguo === 'Extranjera') {
                                                        echo "Nacionalidad anterior: ";
                                                        echo "<td>". $nacionalidad_antiguo . "</td><br>";
                                                        $pais_antiguo = $ingreso_estudiante['pais'];
                                                        echo "<th>País:</th>";
                                                        echo "<td>". $pais_antiguo . "</td>";
                                                        // Mostrar select de país con la opción seleccionada según el país anterior
                                                        echo "<select name='pais'>";
                                                        echo "<option value=''>Seleccione un país...</option>";
                                                        $paises = array("Alemania", "Argentina", "Belice", "Bolivia", "Brasil", 'Canadá', "Colombia", "Costa Rica", "Cuba", "Chile", "Ecuador", "El Salvador", "España", "Estados Unidos", "Guatemala", "Honduras", "Nicaragua", "Paraguay", "Perú", "Republica Dominicana", "Trinidad y Tobago", "Uruguay", "Venezuela");
                                                        foreach ($paises as $pais) {
                                                            $selected = ($pais == $pais_antiguo) ? 'selected' : '';
                                                            echo "<option value='$pais' $selected>$pais</option>";
                                                        }
                                                        echo "</select>";
                                                    }
                                                } else {?>
                                                    <label for="nacionalidad">Nacionalidad del Estudiante:</label>
                                                    <select name="nacionalidad" id="nacionalidad" onchange="mostrarOpciones()" required>
                                                        <option selected disabled value="">Selecciona una opción</option>
                                                        <?php
                                                        include '../conexion/config.php';
                                                        $sql = "SELECT * FROM `concentradoacademico`";
                                                        $res = mysqli_query($conexion, $sql);

                                                        while ($row = mysqli_fetch_array($res)) {
                                                            $nacionalidad = $row['nacionalidades'];
                                                            if(!$nacionalidad==""){
                                                        ?>
                                                            <option value="<?php echo $nacionalidad; ?>"><?php echo $nacionalidad; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                    </select>

                                                    <div id="opcionesEstados" style="display: none;">
                                                        <label for="estado">Estados de México:</label>
                                                        <select id="estado" name="estado">
                                                        <?php
                                                        include '../conexion/config.php';
                                                        $sql = "SELECT * FROM `concentradoacademico`";
                                                        $res = mysqli_query($conexion, $sql);

                                                        while ($row = mysqli_fetch_array($res)) {
                                                            $estado = $row['estados'];
                                                            if(!$estado==""){
                                                        ?>
                                                            <option value="<?php echo $estado; ?>"><?php echo $estado; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        ?>
                                                        </select>
                                                    </div>

                                                    <div id="opcionesPaises" style="display: none;">
                                                        <label for="pais">Países:</label>
                                                        <select id="pais" name="pais" onchange="mostrarOtroPais()">
                                                        <option selected disabled value="">Selecciona un país</option>
                                                        <?php
                                                            include '../conexion/config.php';
                                                            $sql = "SELECT * FROM `concentradoacademico`";
                                                            $res = mysqli_query($conexion, $sql);

                                                            while ($row = mysqli_fetch_array($res)) {
                                                                $pais = $row['paises'];
                                                                if(!$pais==""){
                                                            ?>
                                                                <option value="<?php echo $pais; ?>"><?php echo $pais; ?></option>
                                                            <?php
                                                                }
                                                            }
                                                            ?>
                                                        <option value="otro">Otro</option>
                                                        </select>
                                                        <br>

                                                        <div id="campoOtroPais" style="display: none;">
                                                        <label for="otroPais">Ingresa el nombre del país:</label>
                                                        <input type="text" id="otroPais" name="otroPais" placeholder="Nombre del país">
                                                        </div>
                                                    </div>
                                                <?php }?>
                                            </div>
                                        </div>


                                        <div class="col">
                                            <div class="form-group"><!--'grado'-->
                                                <label for="grupoVulnerable" class="col-form-label">Grupo Vulnerable</label>

                                                <?php 
                                                    $sql = "SELECT * FROM `estudianteconcentrado`";
                                                    $res = mysqli_query($conexion, $sql);
                                                    echo '<select name="grupoVulnerable" id="grupoVulnerable" class="form-select" required>';
                                                    echo '<option selected disabled value="">elige una opción...</option>';
                                                
                                                    while ($row = mysqli_fetch_array($res)) {
                                                        $grupoVulnerable = $row['grupoVulnerable'];
                                                        if(!$grupoVulnerable==""){
                                                            if($grupoVulnerable_antiguo){
                                                                $selected = ($grupoVulnerable == $grupoVulnerable_antiguo) ? 'selected' : '';
                                                                echo "<option value=\"$grupoVulnerable\" $selected>$grupoVulnerable</option>";
                                                            }else{
                                                                ?>
                                                                <option value="<?php echo $grupoVulnerable; ?>"><?php echo $grupoVulnerable; ?></option>
                                                                <?php
                                                            }
                                                            
                                                        }
                                                    }
                                                    echo '</select>';
                                                    echo '</div>';
                                                ?>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="row">
                                        

                                        <div class="col">                                            
                                            <div class="form-group">
                                                <label for="numCVU" class="col-form-label">Número de CVU CONAHCyT</label>
                                                <?php 
                                                    if($numCVU_antiguo){
                                                        ?>
                                                        <input type="number" name="numCVU" id="numCVU" class="form-control" title="Ingresa un numero válido" placeholder="Ingresa 6 digitos" value="<?php echo $numCVU_antiguo;?>" required>
                                                        <?php
                                                    }else{
                                                        ?>
                                                        <input type="number" name="numCVU" id="numCVU" class="form-control" title="Ingresa un numero válido" placeholder="Ingresa 6 digitos" required>
                                                        <?php
                                                    }
                                                ?>
                                                
                                            </div> 
                                        </div>

                                        <div class="col">
                                            <div class="form-group"><!--'grado'-->  
                                                <label for="nombre" class="col-form-label">Posgrado al que pertenece</label>
                                                <?php 
                                                    $sql = "SELECT * FROM `generalposgrados`";
                                                    $res = mysqli_query($conexion, $sql);
                                                    echo '<select name="nombre" id="nombre" class="form-select" required>';
                                                    echo '<option selected disabled value="">elige una opción...</option>';
                                                    
                                                    while ($row = mysqli_fetch_array($res)) {
                                                        $nombrePosgrado_actual = $row['nombre']; // Nombre actual del posgrado en la iteración
                                                        if ($nombrePosgrado_actual == $nombre_antiguo) {
                                                            // Si el nombre actual coincide con el nombre antiguo, marcamos la opción como seleccionada
                                                            echo "<option value=\"$nombrePosgrado_actual\" selected>$nombrePosgrado_actual</option>";
                                                        } else {
                                                            // Si no coincide, mostramos la opción sin selección
                                                            echo "<option value=\"$nombrePosgrado_actual\">$nombrePosgrado_actual</option>";
                                                        }
                                                    }
                                                    echo '</select>';
                                                    echo '</div>';
                                                ?>
                                                </select>
                                            </div>
                                        </div>

                                    </div>
                                </div><!---------FIN accordionBody-------->
                        </div><!--FIN collapseFour-->
                    </div><!--ACORDEON ITERM-->

                    <input type="hidden" name="idEstudiante" id= "idEstu" value="<?php echo $id; ?>">
                                          
<!-----------------------------------------------------------------------BOTOTONES------------------------------------------------------------------------------------->                      
                            <div class="modal-footer"><!--BOTONES-->
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                            <button type="submit" class="btn btn-primary">Guardar</button>
                            </div><!--FIN BOTONES-->

                           
                </div>
            </form>

        </div>
    </div>
</div>
    <!-- Termina ventana agregar -->

<script>
    function validarFormulario() {
        // Lógica de validación personalizada
        var matricula = document.getElementById("matricula").value;
        var nombreEst = document.getElementById("nombreEst").value;
        var numCVU = document.getElementById("numCVU").value;
        var generacion = document.getElementById("generacion").value;

        if (!matricula === "" || !nombreEst === "" || !numCVU === "" || !generacion === "") {
            return true; // El formulario se enviará si todas las validaciones pasan
            
        }

        if (strlen($claveTrabajador) !== 6 || !ctype_digit($claveTrabajador)) {
            
        }

        // Más validaciones aquí
        alert("Todos los campos deben ser completados");
            return false;
        
    }
</script>

<script src="../js/evaluarProfesor.js"></script>

<script>
   function cambiarArchivo(boton) {
        
                  $(document).ready(function(){
                   
                      //var Accion = "Borrar";
                      //var IdExpe = $(boton).data('idexpe');
                      //var matriEstudiante = $(boton).data('matricula');
                      var EliminaArchi = $(boton).data('archivo');
                      var idEstu = $('#idEstu').val();
                      alert ("cambiar archivo: "+idEstu);
                      var resp = confirm("¿Desea borrar archivo: "+ EliminaArchi + " ?");
                     if (resp == true){
                        //window.location.assign("controarchi.php?eliminaarchi="+ArchiExpe+"&id="+IdExpe+"&accion=Borrar");
                                        
                   //alert (IdExpe);
                        // alert ('Archivo:' + EliminaArchi) ;             
                        $.ajax({
                            type:'POST',
                            url:'../crudEstudiantes/controarchiestu.php',
                            data:{'eliminaarchi': EliminaArchi,'idestu':idEstu},
                           
                            success:function(msg){
                                if(msg === 'OK'){
                                    alert ("el archivo se borro correctamente");
                                    $("#archiactual").attr('value','');
                                    $("#expediente_estudiante").prop("disabled",false);
                                    $('#msg1').html("Debe volver a subir el expediente");
                                    //window.location.assign("expeposgrado.php?idposgdo="+IdPosgrado);
                                }else{
                                    alert ("Error: "+msg);
                                   // $('#eliminaMsg').html('<span style="color:red;">Ocurrio un problema, por favor intente  otra vez.</span>');
                                }
                              }
                        });
                        
                      }
               });
               
           }

</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script><!--LIBRERIA JQUERY-->

