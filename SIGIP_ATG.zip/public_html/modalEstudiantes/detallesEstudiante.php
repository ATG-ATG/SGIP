<?php
include('../conexion/conexion.php'); 
include('../conexion/key.php');

$id = isset($_GET['id']) ? $_GET['id'] : '';
$token = isset($_GET['token']) ? $_GET['token'] : '';

if ($id == '' || $token == '') {
    echo "Error al procesar la petición";
    exit;
} else {
    $token_tmp = hash_hmac('sha256', $id, KEY_TOKEN);//antes se usaba "shal" pero da error, asi que se usa sha256

    if ($token == $token_tmp) {
        // Utilizar una consulta preparada con un marcador de posición (?)
        //para datos de ingreso de estudiante
        $sql_detalle = "SELECT * FROM ingresoestudiante WHERE idEstudiante=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle = mysqli_prepare($conexion, $sql_detalle);//se prepara la consulta antes de hacer la ejecucion
        //para datos  de seguimiento de estudiante
        $sql_detalle2 = "SELECT * FROM seguimientoestudiante WHERE idEstudiante=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle2 = mysqli_prepare($conexion, $sql_detalle2);//se prepara la consulta antes de hacer la ejecucion
        //para datos de egreso de estudiante
        $sql_detalle3 = "SELECT * FROM egeresoestudiante WHERE idEstudiante=?";//se utiliza el signo de pregunta en vez de usar directamente el valor de la variable id
        $detalle3 = mysqli_prepare($conexion, $sql_detalle3);//se prepara la consulta antes de hacer la ejecucion
        //para datos de asistente

        //La función mysqli_stmt_bind_param() se utiliza para vincular valores a los marcadores de posición en una consulta SQL preparada antes de ejecutarla
        //msqli_stm =  representa la consulta preparada, y el segundo valor despues de eso son los valores que se van a vincular.
        mysqli_stmt_bind_param($detalle, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle);
        $res_detalle = mysqli_stmt_get_result($detalle);//La función mysqli_stmt_get_result() se utiliza para obtener un conjunto de resultados desde una consulta 
        //preparada en forma de un objeto mysqli_result. Esta función es útil cuando necesitas obtener y manipular los resultados de una consulta SELECT que ha sido 
        //ejecutada utilizando una consulta preparada.

        mysqli_stmt_bind_param($detalle2, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle2);
        $res_detalle2 = mysqli_stmt_get_result($detalle2);
        
        mysqli_stmt_bind_param($detalle3, "i", $id); // Cambiar 's' por 'i' para indicar entero
        mysqli_stmt_execute($detalle3);
        $res_detalle3 = mysqli_stmt_get_result($detalle3);





        if ($res_detalle && $res_detalle2 && $res_detalle3) {
            $row_detalle = mysqli_fetch_array($res_detalle);//hace un recorrido por todos los valores que contiene la variable $res_detalle(datos generales)
            $row_detalle2 = mysqli_fetch_array($res_detalle2);//hace un recorrido por todos los valores que contiene la variable $res_detalle2(datos evaluacion)
            $row_detalle3 = mysqli_fetch_array($res_detalle3);//hace un recorrido por todos los valores que contiene la variable $res_detalle3(datos ficha tecnica)
            
            //-----------------------------Datos del primer acordeon(ingreso estudiante)------------------
            $expediente_estudiante =  $row_detalle['expediente_estudiante'];//tipo texto
            $nombreEst =  $row_detalle['nombreEst'];//tipo texto
            $apellidoPEstudiante =  $row_detalle['apellidoPEstudiante'];//tipo texto
            $apellidoMEstudiante =  $row_detalle['apellidoMEstudiante'];//tipo texto
            $sexo =  $row_detalle['sexo'];//tipo numerico
            $nacionalidad =  $row_detalle['nacionalidad'];//tipo select
            $grupoVulnerable =  $row_detalle['grupoVulnerable'];
            $matricula =  $row_detalle['matricula'];
            $numCVU =  $row_detalle['numCVU'];
            $posgrado =  $row_detalle['nombre'];
            $generacion = $row_detalle['generacion'];
           # $iniciogen = $row_detalle['iniciogen'];
            
            //--------------------------Datos del Segundo Acordeon (seguimiento estudiante)----------------------------------------------->
            $inicioEstudio = $row_detalle2['inicioEstudio'] ?? '';
            $finEstudio = $row_detalle2['finEstudio'] ?? '';
            $selecBeca = $row_detalle2['selecBeca'] ?? '';
            $actExtra = $row_detalle2['actExtra'] ?? '';
            $causaBaja = $row_detalle2['causaBaja'] ?? '';

            //--------------------------Datos del Tercer Acordeon (egreso estudiante)----------------------------------------------->
            $graduacion = $row_detalle3['graduacion'] ?? '';
            $continuaEstudios =  $row_detalle3['continuaEstudios'] ?? '';
            $sni =  $row_detalle3['sni'] ?? '';
            $anioIngreso = $row_detalle3['anioIngreso'] ?? '';
            $lugarTrabaja =  $row_detalle3['lugarTrabaja'] ?? '';
            $aQueSeDedica =  $row_detalle3['aQueSeDedica'] ?? '';

        } else {
            echo "Error al obtener los detalles del Estudiante: " . mysqli_error($conexion);
        }
    } else {
        echo "Error al procesar la petición";
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles del estudiante</title>
    <!-- boostraps -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../css/detalles.css">
</head>
<?php include_once('../menu.php');?><!--INCLUIR EL MENU-->
<body>
    <div class="row">
    <div class="col-8">
        <div data-bs-spy="scroll" data-bs-target="#list-example" data-bs-smooth-scroll="true" class="scrollspy-example" tabindex="0">
        <h4 id="list-item-1">Ingreso</h4>
            <p><?php 
             //<a href="'.'filesestudiante/'.$regisposgrado['archivo'].'"'. ' class="btn btn-success" target="_blank"';
            echo 'Expediente del estudiante: <a href="../crudEstudiantes/filesestudiantes/'.$expediente_estudiante.'"'.' target="_blank">'.$expediente_estudiante.'</a><br>';
            echo "Posgrado al que pertence: " .$posgrado . "<br>";
            echo "Nombre del estudiante: " . $nombreEst . "<br>";
            echo "Apellidos: " . $apellidoPEstudiante . " , ". $apellidoMEstudiante. "<br>";
            echo "Sexo: " . $sexo . "<br>";
            echo "Su nacionalidad es: " . $nacionalidad . "<br>";
            if($nacionalidad === 'Mexicana'){
                $estado = $row_detalle['estado'];
                echo "Del Estado de: " . $estado . "<br>";
            }
            else if($nacionalidad === 'Extranjera'){
                $pais = $row_detalle['pais'];
                echo "Del pais de: " . $pais . "<br>";
            }
            else{
                echo "No hay nacionalidad". "<br>";
            }
            echo "Grupo Vulnerable: " . $grupoVulnerable . "<br>";
            echo "Matrícula: " . $matricula . "<br>";
            echo "Número CVU: " . $numCVU . "<br>";
            //echo "Del posgrado: " . $posgrado . "<br>";
            echo "Generación: " . $generacion . "<br>";
           # echo "Inicio de generación: " . $iniciogen . "<br>";
            ?></p>
        
        
        <h4 id="list-item-2">Seguimiento</h4>
            <p><?php 
            echo "Inicio sus estudios en : " . $inicioEstudio . "<br>";
            echo "y concluyé en : " . $finEstudio . "<br>";
            if($selecBeca == 'si'){
                $inicioBeca = $row_detalle2['inicioBeca'];
                $finBeca = $row_detalle2['finBeca'];
                echo "Si tiene Beca, ";
                echo "Inicio su beca el : " . $inicioBeca . "<br>";
                echo "Y concluyé el: " . $finBeca . "<br>";
            }else{
                echo "y por el momento no cuenta con Beca ". "<br>";
            }
            echo "Su actividad extracurricular : " . $actExtra . "<br>";
            echo "La causa de su baja es: " . $causaBaja . "<br>";
            ?></p>

        <h4 id="list-item-3">Egreso</h4>
            <p>
                <?php
                    echo "Graduación : " . $graduacion . "<br>";
                    if($continuaEstudios === "si"){
                        echo "Continua con sus estudios ";
                    }else{
                        echo "No continua con sus estudios ";
                    }
                    echo "SNI: " . $sni . "<br>";
                    echo "El lugar donde trabaja es: " . $lugarTrabaja . "<br>";
                    echo "Y se dedica a : " . $aQueSeDedica . "<br>";
                ?>
            </p>
        <h4 id="list-item-4">Somos UAGro</h4>
            <p>
               Somos Orgullosamente UAGro
            </p>
            <a class="btn btn-outline-secondary" href="../principales/generalesEstudiantes.php">Regresar</a>
        </div>
    </div>
    </div>
</body>
</html>
