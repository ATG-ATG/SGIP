<!--Este archivo es el base de edición del estudiante-->
<?php
include('../conexion/conexion.php');//contiene configuraciones relacionadas con la conexión a una base de datos
//lo cual esta en un archivo llamado "config.php" en la carpeta conexion
include('../conexion/key.php');//archivo "key.php" de la carpeta conexion, este archivo contiene claves y/o tokens de autenticación
//para el funcionamiento del boton detalles, esto sirve como un link de youtube o de facebook, que sale al final del url como "?5e88t4e56y84u5" coo metodo de seguridad
?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script><!--LIBRERIA JQUERY-->

<script>
    //funcion para hacer recorrido y busqueda de datos especificos(nombre de estudiantes)
    $(document).ready(function() {
        $('#search').on('input', function() {
            var keyword = $(this).val();
            $.ajax({
                url: '../listas/buscadorEst.php',
                type: 'POST',
                data: {
                    keyword: keyword
                },
                success: function(response) {
                    $('#search-results').html(response);
                }
            });
        });
    });    
</script>


<?php
$sql = "SELECT * FROM `ingresoEstudiante`";//consulta de la tabla generalPosgrados
$res = mysqli_query($conexion, $sql);//guardar consulta
$contador = mysqli_num_rows($res);//guardar en una variable el total de datos guardados en la tabla

?>

<?php include_once('../menu.php');?><!--INCLUIR EL MENU-->

<div style="width: 70%; margin: auto;">
    <div>
        <!-- boton para agregar, el modal esta en el archivo "pruebaAgregar.php" en la carpeta modalEstudiantes -->
        <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#myModal1">
            <!-- Icono de agregar -->
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill-add" viewBox="0 0 16 16">
                <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm.5-5v1h1a.5.5 0 0 1 0 1h-1v1a.5.5 0 0 1-1 0v-1h-1a.5.5 0 0 1 0-1h1v-1a.5.5 0 0 1 1 0Zm-2-6a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"></path>
                <path d="M2 13c0 1 1 1 1 1h5.256A4.493 4.493 0 0 1 8 12.5a4.49 4.49 0 0 1 1.544-3.393C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4Z"></path>
            </svg>
            <h6>Agregar Estudiantggg</h6>
        </button>
    </div>

    <!-- barra de busqueda -->
    <br>
    <div>
        <input type="text" id="search" placeholder="Buscar Estudiante...">
    </div>
    <!--FIN de la barra de busqueda-->

    <br>

    <div id='search-results'>
        <table class="table table-bordered table-striped table-hover">
            <thead>
                <tr>
                    <th scope="col">Id</th>
                    <th scope="col">Matrícula</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Número de CVU CONAHCyT</th>
                    <th scope="col">Generación</th>
                    <th scope="col">Posgrado al que Pertenece</th>
                    <th scope="col">Editar</th>
                    <th>Seguimiento</th>
                    <th scope="col">Eliminar</th>
                    <th scope="col">Detalles</th>

                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($res)) { ?>
                    <tr>
                        <td><?php echo $row['idEstudiante']; ?></td>
                        <td><?php echo $row['matricula']; ?></td>           
                        <td><?php echo $row['nombreEst']; ?></td>           
                        <td><?php echo $row['numCVU']; ?></td>
                        <td><?php echo $row['generacion']; ?></td>
                        <td><?php echo $row['posgrado']; ?></td>

                        <!--BOTON DE EDITAR ESTUDIANTES, el archivo se llama "editar2.php" en la carpeta modalPosgrados-->
                        <td style="text-align: center;">
                            <?php
                                echo '<a href="../modalPosgrados/editar2.php?id=' . $row['idEstudiante'] . '"><button class="btn btn-outline-success">Editar</button></a>';
                            ?><!--FALTA-->
                        </td>

                        <!--BOTON DE SEGUIMIENTO ESTUDIANTES, el archivo se llama "editar2.php" en la carpeta modalPosgrados-->
                        <td style="text-align: center;">
                            <?php
                                echo '<a href="../modalEstudiantes/seguimEstmodal.php?id=' . $row['idEstudiante'] . '"><button class="btn btn-outline-Secondary">Agregar</button></a>';
                            ?><!--FALTA-->
                        </td>

                        <!--BOTON DE ELIMINAR ESTUDIANTES-->
                        <td style="text-align: center;">
                            <?php
                            echo '<a href="../baseDatosPos/eliminarPos.php?id=' . $row['idEstudiante'] . '"><button class="btn btn-outline-danger"  onclick="return eliminar()">Eliminar</button></a>';
                            ?>
                        </td><!--FALTA-->

                    
                        <!--BOTON DE DETALLES ESTUDIANTES-->
                        <td style="text-align: center;">
                            <div class="btn-group">
                                <a href="../modalPosgrados/detalles.php?id=<?php echo $row['idEstudiante']; ?>&token=<?php echo hash_hmac('sha256', $row['idEstudiante'], KEY_TOKEN);?>" class="btn btn-primary">
                                    Detalles
                                </a><!--FALTA-->
                            </div>
                        </td>

                    </tr>
                <?php } ?>

        </table>
    </div>
    
</div>
<?php
include('../modalEstudiantes/agregarEstudiante.php');
?>


